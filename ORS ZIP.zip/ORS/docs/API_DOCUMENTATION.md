# CareerConnect – Online Recruitment System
## RESTful API Documentation

Base URL: `http://localhost:8080/api`

All protected endpoints require the following HTTP Header:
```http
Authorization: Bearer <jwt-token>
```

---

### 1. Authentication Endpoints

#### Health Check
- **Endpoint**: `GET /api/health`
- **Access**: Public
- **Response `200 OK`**:
```json
{
  "status": "UP",
  "service": "CareerConnect Online Recruitment System REST API",
  "version": "1.0.0"
}
```

#### User Login
- **Endpoint**: `POST /api/auth/login`
- **Access**: Public
- **Request Body**:
```json
{
  "email": "candidate@careerconnect.com",
  "password": "pass123",
  "role": "CANDIDATE"
}
```
- **Response `200 OK`**:
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "user": {
    "id": 5,
    "email": "candidate@careerconnect.com",
    "fullName": "Alex Morgan",
    "role": "CANDIDATE",
    "phone": "+1 (555) 234-5678",
    "avatarUrl": "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150",
    "candidateId": 1,
    "recruiterId": null,
    "companyId": null
  }
}
```

#### User Registration
- **Endpoint**: `POST /api/auth/register`
- **Access**: Public
- **Request Body (Candidate)**:
```json
{
  "email": "newuser@example.com",
  "password": "pass123",
  "role": "CANDIDATE",
  "fullName": "John Doe",
  "phone": "+1 555-1234",
  "headline": "Junior Java Developer",
  "skills": "Java, Spring, MySQL"
}
```
- **Request Body (Recruiter)**:
```json
{
  "email": "hr@acme.com",
  "password": "pass123",
  "role": "RECRUITER",
  "fullName": "Jane Smith",
  "phone": "+1 555-5678",
  "companyName": "Acme Technologies",
  "industry": "Software Services",
  "designation": "Talent Acquisition Lead"
}
```

---

### 2. Jobs Endpoints

#### Browse & Filter Jobs
- **Endpoint**: `GET /api/jobs`
- **Access**: Public
- **Query Parameters**:
  - `search`: Keyword for title, company, or skills (e.g. `Java`)
  - `location`: Location string (e.g. `Bangalore` or `Remote`)
  - `jobType`: `Full-time`, `Remote`, `Hybrid`, `Contract`, `Internship`
  - `recruiterId`: Filter by specific recruiter
  - `companyId`: Filter by company ID
- **Response `200 OK`**: Array of Job objects.

#### Get Job Details by ID
- **Endpoint**: `GET /api/jobs/{id}`
- **Access**: Public
- **Response `200 OK`**: Single Job object with company and recruiter details.

#### Post New Job Vacancy
- **Endpoint**: `POST /api/jobs`
- **Access**: Recruiter or Admin (`ROLE_RECRUITER`, `ROLE_ADMIN`)
- **Request Body**:
```json
{
  "recruiterId": 1,
  "title": "Senior Backend Java Engineer",
  "description": "Design and build microservices...",
  "skillsRequired": ["Java", "Spring Boot", "MySQL", "AWS"],
  "qualification": "B.Tech in Computer Science",
  "experienceLevel": "Senior (3-5 yrs)",
  "salaryMin": 120000,
  "salaryMax": 160000,
  "location": "Bangalore, India (Hybrid)",
  "jobType": "Hybrid",
  "vacancies": 3,
  "deadline": "2026-12-31"
}
```

#### Update Job Vacancy
- **Endpoint**: `PUT /api/jobs/{id}`
- **Access**: Recruiter or Admin

#### Delete Job Vacancy
- **Endpoint**: `DELETE /api/jobs/{id}`
- **Access**: Recruiter or Admin

---

### 3. Applications Endpoints

#### Get Applications
- **Endpoint**: `GET /api/applications`
- **Access**: Candidate, Recruiter, Admin
- **Query Parameters**:
  - `candidateId`: Get applications submitted by candidate
  - `recruiterId`: Get applicants for recruiter's posted jobs
  - `jobId`: Get applicants for a specific job

#### Submit Job Application
- **Endpoint**: `POST /api/applications`
- **Access**: Candidate (`ROLE_CANDIDATE`)
- **Request Body**:
```json
{
  "candidateId": 1,
  "jobId": 3,
  "coverNote": "I am deeply interested in this position and have relevant background in Java Spring Boot."
}
```

#### Update Application Status & Interview
- **Endpoint**: `PUT /api/applications/{id}/status`
- **Access**: Recruiter or Admin
- **Request Body**:
```json
{
  "status": "Interview Scheduled",
  "recruiterFeedback": "Selected for live technical coding round.",
  "interviewDate": "2026-11-15T14:00:00"
}
```

---

### 4. Candidate Profile Endpoints

#### Get Candidate Profile
- **Endpoint**: `GET /api/candidates/{id}`
- **Access**: Authenticated

#### Update Candidate Profile
- **Endpoint**: `PUT /api/candidates/{id}`
- **Access**: Candidate Owner or Admin

---

### 5. Admin Endpoints

#### Get Platform Metrics
- **Endpoint**: `GET /api/admin/stats`
- **Access**: Admin (`ROLE_ADMIN`)
- **Response `200 OK`**:
```json
{
  "totalCandidates": 4,
  "totalRecruiters": 3,
  "totalCompanies": 5,
  "totalJobs": 8,
  "totalApplications": 6,
  "activeJobs": 8
}
```

#### Manage Users
- **Endpoint**: `GET /api/admin/users`
- **Access**: Admin (`ROLE_ADMIN`)

#### Update User Account Status
- **Endpoint**: `PUT /api/admin/users/{id}/status`
- **Access**: Admin (`ROLE_ADMIN`)
- **Request Body**: `{"status": "SUSPENDED"}` or `{"status": "ACTIVE"}`

