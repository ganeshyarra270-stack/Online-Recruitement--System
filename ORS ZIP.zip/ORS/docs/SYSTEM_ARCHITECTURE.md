# CareerConnect – Online Recruitment System
## System Architecture & Security Design

### Architectural Overview

```
                      ┌────────────────────────────────────────┐
                      │    CareerConnect Web Application       │
                      │  (HTML5 / CSS3 / ES6 Modular JS / UI)  │
                      └──────────────────┬─────────────────────┘
                                         │
                         Dual-Mode Unified API Client
                         (frontend/js/api.js)
                                         │
                   ┌─────────────────────┴─────────────────────┐
                   │                                           │
         [Mode A: Online API]                        [Mode B: Standalone Demo]
                   │                                           │
                   ▼                                           ▼
┌──────────────────────────────────────┐     ┌───────────────────────────────────┐
│     Spring Boot 3.2.x REST API       │     │     Client-side Mock Engine       │
│        (Port 8080)                   │     │  (localStorage DB & Schema Mock)  │
├──────────────────────────────────────┤     └───────────────────────────────────┘
│ - Spring Web MVC Controllers         │
│ - Spring Security (BCrypt + JWT)     │
│ - Service Layer Business Rules       │
│ - Spring Data JPA (Hibernate ORM)    │
└──────────────────┬───────────────────┘
                   │
                   ▼
┌──────────────────────────────────────┐
│     MySQL 8.0+ Relational Database   │
│       (online_recruitment)           │
│ - 10 Relational Tables               │
│ - Primary/Foreign Key Constraints    │
│ - Unique Indexes & JSON fields       │
└──────────────────────────────────────┘
```

---

### Role-Based Access Control (RBAC) Matrix

| Resource / Action | Public / Guest | Candidate | Recruiter | Super Admin |
|:---|:---:|:---:|:---:|:---:|
| Browse & Search Vacancies | Yes | Yes | Yes | Yes |
| View Company Profiles | Yes | Yes | Yes | Yes |
| Apply to Jobs | No | **Yes** | No | No |
| Upload PDF Resume | No | **Yes** | No | No |
| Track Application Status | No | **Yes** | No | No |
| Bookmark / Save Jobs | No | **Yes** | No | No |
| Post New Job Vacancy | No | No | **Yes** | **Yes** |
| Edit / Delete Own Jobs | No | No | **Yes** | **Yes** |
| View Applicants & Resumes | No | No | **Yes** | **Yes** |
| Shortlist / Reject Candidates | No | No | **Yes** | **Yes** |
| Schedule Interviews | No | No | **Yes** | **Yes** |
| Moderate Any Job Postings | No | No | No | **Yes** |
| Manage User Accounts | No | No | No | **Yes** |
| View Platform Analytics | No | No | No | **Yes** |

---

### Duplicate Prevention & Data Integrity
1. **Application Constraint**: The relational database enforces `UNIQUE KEY uk_candidate_job (candidate_id, job_id)`. The API layer validates this before submission, ensuring candidates cannot spam multiple applications for the exact same opening.
2. **Password Security**: Passwords are saved as one-way salted BCrypt hashes.
3. **Audit Tracking**: Timestamp triggers (`created_at`, `updated_at`) automatically preserve audit trails across candidate profiles and application statuses.

