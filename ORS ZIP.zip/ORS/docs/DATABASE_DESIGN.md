# CareerConnect – Online Recruitment System
## Database Architecture & Relational Design

Database Name: `online_recruitment`  
Engine: `InnoDB`  
Default Charset: `utf8mb4`  
Collation: `utf8mb4_unicode_ci`

---

### Entity-Relationship Overview

```mermaid
erDiagram
    USERS ||--o| CANDIDATES : "has profile"
    USERS ||--o| RECRUITERS : "has identity"
    USERS ||--o| ADMIN : "has super privileges"
    USERS ||--o{ NOTIFICATIONS : "receives"
    COMPANIES ||--o{ RECRUITERS : "employs"
    COMPANIES ||--o{ JOBS : "offers"
    RECRUITERS ||--o{ JOBS : "posts & manages"
    CANDIDATES ||--o{ RESUMES : "uploads PDF"
    CANDIDATES ||--o{ APPLICATIONS : "submits"
    JOBS ||--o{ APPLICATIONS : "receives"
    RESUMES ||--o{ APPLICATIONS : "attaches"
    CANDIDATES ||--o{ SAVED_JOBS : "bookmarks"
    JOBS ||--o{ SAVED_JOBS : "bookmarked in"
```

---

### Table Specifications

#### 1. `users`
Central table managing authentication credentials, role assignments, and account status.
- `id` (BIGINT, PK, AUTO_INCREMENT)
- `email` (VARCHAR(150), UNIQUE, NOT NULL, Indexed)
- `password_hash` (VARCHAR(255), NOT NULL) – Stored as BCrypt hash
- `role` (ENUM('CANDIDATE', 'RECRUITER', 'ADMIN'), NOT NULL)
- `full_name` (VARCHAR(120), NOT NULL)
- `phone` (VARCHAR(25))
- `avatar_url` (VARCHAR(500))
- `status` (ENUM('ACTIVE', 'INACTIVE', 'SUSPENDED'), DEFAULT 'ACTIVE')
- `created_at` (TIMESTAMP, CURRENT_TIMESTAMP)
- `updated_at` (TIMESTAMP, ON UPDATE CURRENT_TIMESTAMP)

#### 2. `companies`
Stores verified company profiles and organizational metadata.
- `id` (BIGINT, PK, AUTO_INCREMENT)
- `name` (VARCHAR(180), NOT NULL, Indexed)
- `logo_url` (VARCHAR(500))
- `website` (VARCHAR(255))
- `industry` (VARCHAR(100), NOT NULL)
- `description` (TEXT)
- `location` (VARCHAR(150), NOT NULL)
- `founded_year` (INT)
- `employee_count` (VARCHAR(50))
- `verified` (BOOLEAN, DEFAULT TRUE)

#### 3. `candidates`
Profiles, education, technical skills, and experience for job seekers.
- `id` (BIGINT, PK, AUTO_INCREMENT)
- `user_id` (BIGINT, FK -> users(id) ON DELETE CASCADE, UNIQUE)
- `headline` (VARCHAR(255))
- `bio` (TEXT)
- `address` (VARCHAR(255))
- `education_json` (JSON)
- `experience_json` (JSON)
- `skills_json` (JSON)
- `profile_completion` (INT, DEFAULT 75)

#### 4. `recruiters`
Corporate recruiters affiliated with companies.
- `id` (BIGINT, PK, AUTO_INCREMENT)
- `user_id` (BIGINT, FK -> users(id) ON DELETE CASCADE, UNIQUE)
- `company_id` (BIGINT, FK -> companies(id) ON DELETE RESTRICT)
- `designation` (VARCHAR(120), NOT NULL)
- `department` (VARCHAR(100))
- `contact_number` (VARCHAR(30))
- `verified` (BOOLEAN, DEFAULT TRUE)

#### 5. `jobs`
Job vacancies posted by recruiters.
- `id` (BIGINT, PK, AUTO_INCREMENT)
- `recruiter_id` (BIGINT, FK -> recruiters(id) ON DELETE CASCADE)
- `company_id` (BIGINT, FK -> companies(id) ON DELETE CASCADE)
- `title` (VARCHAR(200), NOT NULL, Indexed)
- `description` (LONGTEXT, NOT NULL)
- `skills_required` (VARCHAR(500), NOT NULL)
- `qualification` (VARCHAR(150), NOT NULL)
- `experience_level` (ENUM, NOT NULL)
- `salary_min` (DECIMAL(12,2), NOT NULL)
- `salary_max` (DECIMAL(12,2), NOT NULL)
- `location` (VARCHAR(150), NOT NULL, Indexed)
- `job_type` (ENUM('Full-time', 'Part-time', 'Remote', 'Hybrid', 'Contract', 'Internship'))
- `vacancies` (INT, DEFAULT 1)
- `deadline` (DATE, NOT NULL)
- `status` (ENUM('ACTIVE', 'PENDING_APPROVAL', 'REJECTED', 'CLOSED'), Indexed)
- `is_featured` (BOOLEAN, DEFAULT FALSE)
- `views_count` (INT, DEFAULT 0)

#### 6. `applications`
Submissions by candidates with state machine status tracking.
- `id` (BIGINT, PK, AUTO_INCREMENT)
- `job_id` (BIGINT, FK -> jobs(id) ON DELETE CASCADE)
- `candidate_id` (BIGINT, FK -> candidates(id) ON DELETE CASCADE)
- `resume_id` (BIGINT, FK -> resumes(id) ON DELETE SET NULL)
- `cover_note` (TEXT)
- `status` (ENUM('Pending', 'Reviewed', 'Shortlisted', 'Interview Scheduled', 'Rejected', 'Hired'))
- `recruiter_feedback` (TEXT)
- `interview_date` (DATETIME)
- `applied_at` (TIMESTAMP, CURRENT_TIMESTAMP)
- **Constraint**: `UNIQUE KEY uk_candidate_job (candidate_id, job_id)` prevents duplicate applications!

#### 7. `resumes`
PDF resume records uploaded by candidates.
- `id` (BIGINT, PK, AUTO_INCREMENT)
- `candidate_id` (BIGINT, FK -> candidates(id) ON DELETE CASCADE)
- `file_name` (VARCHAR(255), NOT NULL)
- `file_size_kb` (INT, NOT NULL)
- `file_type` (VARCHAR(50), DEFAULT 'application/pdf')
- `file_url` (VARCHAR(500), NOT NULL)
- `is_default` (BOOLEAN, DEFAULT TRUE)
- `uploaded_at` (TIMESTAMP, CURRENT_TIMESTAMP)

#### 8. `saved_jobs`
Bookmarking relationship.
- `id` (BIGINT, PK, AUTO_INCREMENT)
- `candidate_id` (BIGINT, FK -> candidates(id) ON DELETE CASCADE)
- `job_id` (BIGINT, FK -> jobs(id) ON DELETE CASCADE)
- `saved_at` (TIMESTAMP, CURRENT_TIMESTAMP)
- **Constraint**: `UNIQUE KEY uk_saved_candidate_job (candidate_id, job_id)`

#### 9. `notifications`
In-app notification messages.
- `id` (BIGINT, PK, AUTO_INCREMENT)
- `user_id` (BIGINT, FK -> users(id) ON DELETE CASCADE)
- `title` (VARCHAR(200), NOT NULL)
- `message` (TEXT, NOT NULL)
- `type` (ENUM('APPLICATION_STATUS', 'JOB_ALERT', 'SYSTEM', 'INTERVIEW'))
- `is_read` (BOOLEAN, DEFAULT FALSE)
- `link_url` (VARCHAR(255))
- `created_at` (TIMESTAMP, CURRENT_TIMESTAMP)

#### 10. `admin`
Super administrative credentials & audit details.
- `id` (BIGINT, PK, AUTO_INCREMENT)
- `user_id` (BIGINT, FK -> users(id) ON DELETE CASCADE, UNIQUE)
- `permission_level` (VARCHAR(50), DEFAULT 'SUPER_ADMIN')
- `last_login` (TIMESTAMP)

