/**
 * CareerConnect - Online Recruitment System
 * Authentication & Session Management Module
 */

const AUTH_USER_KEY = 'careerconnect_user';
const AUTH_TOKEN_KEY = 'careerconnect_token';

const Auth = {
  getCurrentUser() {
    const raw = localStorage.getItem(AUTH_USER_KEY);
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch (e) {
      return null;
    }
  },

  getToken() {
    return localStorage.getItem(AUTH_TOKEN_KEY);
  },

  isAuthenticated() {
    return !!this.getCurrentUser();
  },

  async login(email, password, role) {
    try {
      const res = await API.login(email, password, role);
      if (res && res.success) {
        localStorage.setItem(AUTH_TOKEN_KEY, res.token);
        localStorage.setItem(AUTH_USER_KEY, JSON.stringify(res.user));
        return { success: true, user: res.user };
      }
      throw new Error('Authentication failed');
    } catch (error) {
      return { success: false, message: error.message };
    }
  },

  async register(formData) {
    try {
      const res = await API.register(formData);
      if (res && res.success) {
        localStorage.setItem(AUTH_TOKEN_KEY, res.token);
        localStorage.setItem(AUTH_USER_KEY, JSON.stringify(res.user));
        return { success: true, user: res.user };
      }
      throw new Error('Registration failed');
    } catch (error) {
      return { success: false, message: error.message };
    }
  },

  logout() {
    localStorage.removeItem(AUTH_USER_KEY);
    localStorage.removeItem(AUTH_TOKEN_KEY);
    window.location.href = 'index.html';
  },

  // Role Guard for dashboards
  requireAuth(allowedRoles = []) {
    const user = this.getCurrentUser();
    if (!user) {
      window.location.href = `auth.html?redirect=${encodeURIComponent(window.location.pathname)}`;
      return false;
    }

    if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
      alert(`Access Restricted: This dashboard requires role ${allowedRoles.join(' or ')}. Your role is ${user.role}.`);
      this.redirectUserByRole(user.role);
      return false;
    }
    return true;
  },

  redirectUserByRole(role) {
    if (role === 'CANDIDATE') window.location.href = 'candidate-dashboard.html';
    else if (role === 'RECRUITER') window.location.href = 'recruiter-dashboard.html';
    else if (role === 'ADMIN') window.location.href = 'admin-dashboard.html';
    else window.location.href = 'index.html';
  },

  // Render navigation user state across all pages
  setupNavbar() {
    const navActions = document.getElementById('nav-auth-actions');
    if (!navActions) return;

    const user = this.getCurrentUser();

    if (user) {
      let dashboardUrl = 'candidate-dashboard.html';
      if (user.role === 'RECRUITER') dashboardUrl = 'recruiter-dashboard.html';
      else if (user.role === 'ADMIN') dashboardUrl = 'admin-dashboard.html';

      navActions.innerHTML = `
        <div class="backend-status-pill offline" title="Toggle Backend / Demo Mode" onclick="API.updateStatusPill(!API.isBackendOnline)">
          <span class="dot"></span> Demo Mode
        </div>

        <div class="user-menu">
          <button class="user-profile-btn" id="user-menu-trigger">
            <img src="${user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}" alt="${user.fullName}" class="user-avatar" />
            <span class="user-name">${user.fullName.split(' ')[0]}</span>
            <i class="fa-solid fa-angle-down" style="font-size: 0.75rem; color: var(--navy-muted);"></i>
          </button>
          
          <div class="user-dropdown" id="user-menu-dropdown">
            <div class="user-dropdown-header">
              <div class="user-dropdown-name">${user.fullName}</div>
              <div class="user-dropdown-role">${user.role} ACCOUNT</div>
            </div>
            <a href="${dashboardUrl}" class="user-dropdown-item">
              <i class="fa-solid fa-gauge-high"></i> Dashboard
            </a>
            <a href="${dashboardUrl}#profile" class="user-dropdown-item">
              <i class="fa-regular fa-user"></i> My Profile
            </a>
            ${user.role === 'CANDIDATE' ? `
              <a href="candidate-dashboard.html#applications" class="user-dropdown-item">
                <i class="fa-regular fa-file-lines"></i> Applied Jobs
              </a>
              <a href="candidate-dashboard.html#saved" class="user-dropdown-item">
                <i class="fa-regular fa-bookmark"></i> Saved Jobs
              </a>
            ` : ''}
            ${user.role === 'RECRUITER' ? `
              <a href="recruiter-dashboard.html#post-job" class="user-dropdown-item">
                <i class="fa-solid fa-plus-circle"></i> Post New Job
              </a>
              <a href="recruiter-dashboard.html#applicants" class="user-dropdown-item">
                <i class="fa-solid fa-users"></i> Applicants
              </a>
            ` : ''}
            <div style="height: 1px; background: var(--border-light); margin: 0.35rem 0;"></div>
            <a href="javascript:void(0)" onclick="Auth.logout()" class="user-dropdown-item danger">
              <i class="fa-solid fa-right-from-bracket"></i> Logout
            </a>
          </div>
        </div>
      `;

      // Dropdown toggle
      const trigger = document.getElementById('user-menu-trigger');
      const dropdown = document.getElementById('user-menu-dropdown');
      if (trigger && dropdown) {
        trigger.addEventListener('click', (e) => {
          e.stopPropagation();
          dropdown.classList.toggle('show');
        });
        document.addEventListener('click', () => {
          dropdown.classList.remove('show');
        });
      }
    } else {
      navActions.innerHTML = `
        <div class="backend-status-pill offline" title="Toggle Backend / Demo Mode">
          <span class="dot"></span> Demo Mode
        </div>
        <a href="auth.html?mode=login" class="btn btn-outline btn-sm">
          <i class="fa-solid fa-arrow-right-to-bracket"></i> Login
        </a>
        <a href="auth.html?mode=register" class="btn btn-primary btn-sm">
          <i class="fa-solid fa-user-plus"></i> Register
        </a>
      `;
    }

    // Refresh status pill
    API.updateStatusPill(API.isBackendOnline);
  }
};

// Auto-run navbar setup when DOM loads
window.addEventListener('DOMContentLoaded', () => {
  Auth.setupNavbar();
});

