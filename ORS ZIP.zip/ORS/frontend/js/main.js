/**
 * CareerConnect - Online Recruitment System
 * Homepage Main Controller
 */

let currentSelectedJob = null;

document.addEventListener('DOMContentLoaded', async () => {
  await loadFeaturedJobs();
  await loadTopCompanies();
});

// Load featured jobs into homepage grid
async function loadFeaturedJobs() {
  const container = document.getElementById('featured-jobs-grid');
  if (!container) return;

  try {
    const jobs = await API.getJobs();
    const featured = jobs.filter(j => j.isFeatured).slice(0, 6);

    if (featured.length === 0) {
      container.innerHTML = '<p class="text-muted text-center" style="grid-column: 1/-1;">No featured jobs available.</p>';
      return;
    }

    const user = Auth.getCurrentUser();
    let savedJobIds = [];
    if (user && user.candidateId) {
      const saved = await API.getSavedJobs(user.candidateId);
      savedJobIds = saved.map(s => s.id);
    }

    container.innerHTML = featured.map(job => renderJobCard(job, savedJobIds.includes(job.id))).join('');
  } catch (err) {
    console.error('Error loading featured jobs:', err);
    container.innerHTML = '<p class="text-muted text-center" style="grid-column: 1/-1;">Unable to load featured jobs.</p>';
  }
}

// Render individual Job Card
function renderJobCard(job, isSaved = false) {
  const salaryText = `$${(job.salaryMin / 1000).toFixed(0)}k - $${(job.salaryMax / 1000).toFixed(0)}k`;
  const skillsArray = Array.isArray(job.skillsRequired) ? job.skillsRequired : (job.skillsRequired || '').split(',');

  return `
    <div class="job-card">
      <div class="job-card-header">
        <div class="company-logo-wrap">
          <img src="${job.companyLogo || 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=120'}" alt="${job.companyName}" />
        </div>
        <button class="btn-bookmark ${isSaved ? 'bookmarked' : ''}" title="${isSaved ? 'Remove from Saved' : 'Save Job'}" onclick="handleBookmarkToggle(event, ${job.id})">
          <i class="${isSaved ? 'fa-solid' : 'fa-regular'} fa-bookmark"></i>
        </button>
      </div>

      <div class="job-card-body">
        <h3 class="job-title" onclick="openJobDetailsModal(${job.id})">${job.title}</h3>
        <div class="job-company-name">
          <i class="fa-regular fa-building"></i> ${job.companyName}
          ${job.isFeatured ? '<span class="badge badge-primary" style="margin-left: 6px; font-size: 0.7rem;">Featured</span>' : ''}
        </div>

        <div class="job-meta-row">
          <span class="job-meta-item"><i class="fa-solid fa-location-dot"></i> ${job.location}</span>
          <span class="job-meta-item"><i class="fa-regular fa-clock"></i> ${job.jobType}</span>
          <span class="job-meta-item"><i class="fa-solid fa-briefcase"></i> ${job.experienceLevel}</span>
        </div>

        <div class="job-tags-row">
          ${skillsArray.slice(0, 3).map(skill => `<span class="badge badge-neutral">${skill.trim()}</span>`).join('')}
          ${skillsArray.length > 3 ? `<span class="badge badge-neutral">+${skillsArray.length - 3}</span>` : ''}
        </div>
      </div>

      <div class="job-card-footer">
        <div class="job-salary">
          ${salaryText} <span class="period">/ year</span>
        </div>
        <div class="flex items-center gap-2">
          <button class="btn btn-outline btn-sm" onclick="openJobDetailsModal(${job.id})">Details</button>
          <button class="btn btn-primary btn-sm" onclick="triggerApplyModal(${job.id}, '${job.title.replace(/'/g, "\\'")}')">Apply</button>
        </div>
      </div>
    </div>
  `;
}

// Load Top Companies
async function loadTopCompanies() {
  const container = document.getElementById('top-companies-grid');
  if (!container) return;

  try {
    const companies = await API.getCompanies();
    container.innerHTML = companies.slice(0, 4).map(c => `
      <div class="company-card" onclick="window.location.href='jobs.html?companyId=${c.id}'" style="cursor: pointer;">
        <div class="company-card-avatar">
          <img src="${c.logoUrl}" alt="${c.name}" />
        </div>
        <h4 class="company-card-title">${c.name}</h4>
        <div class="company-card-industry">${c.industry}</div>
        <span class="badge badge-primary">
          <i class="fa-solid fa-briefcase"></i> ${c.openPositions || 2} Open Jobs
        </span>
      </div>
    `).join('');
  } catch (err) {
    console.error('Error loading top companies:', err);
  }
}

// Hero Search Box
function handleHeroSearch(e) {
  e.preventDefault();
  const keyword = document.getElementById('hero-keyword').value.trim();
  const location = document.getElementById('hero-location').value.trim();

  const params = new URLSearchParams();
  if (keyword) params.append('search', keyword);
  if (location) params.append('location', location);

  window.location.href = `jobs.html?${params.toString()}`;
}

function quickSearch(tag) {
  window.location.href = `jobs.html?search=${encodeURIComponent(tag)}`;
}

// Job Details Modal
async function openJobDetailsModal(jobId) {
  try {
    const job = await API.getJobById(jobId);
    if (!job) return;

    currentSelectedJob = job;

    document.getElementById('modal-job-title').innerText = job.title;
    const body = document.getElementById('modal-job-body');

    const salaryText = `$${(job.salaryMin).toLocaleString()} - $${(job.salaryMax).toLocaleString()} / year`;
    const skills = Array.isArray(job.skillsRequired) ? job.skillsRequired : (job.skillsRequired || '').split(',');

    body.innerHTML = `
      <div class="flex items-center gap-4 mb-6">
        <img src="${job.company ? job.company.logoUrl : ''}" style="width: 64px; height: 64px; border-radius: 12px; object-fit: cover; border: 1px solid var(--border-light);" />
        <div>
          <h3 style="font-size: 1.25rem; font-weight: 700; color: var(--navy-dark);">${job.title}</h3>
          <div style="font-size: 0.95rem; color: var(--navy-muted);">${job.company ? job.company.name : ''} • ${job.location}</div>
        </div>
      </div>

      <div class="grid grid-2 mb-6" style="background: var(--bg-alt); padding: 1rem; border-radius: 12px;">
        <div><strong>Salary:</strong> ${salaryText}</div>
        <div><strong>Job Type:</strong> ${job.jobType}</div>
        <div><strong>Experience:</strong> ${job.experienceLevel}</div>
        <div><strong>Vacancies:</strong> ${job.vacancies} open position(s)</div>
        <div><strong>Deadline:</strong> ${job.deadline}</div>
        <div><strong>Qualification:</strong> ${job.qualification}</div>
      </div>

      <h4 style="font-size: 1rem; margin-bottom: 0.5rem; color: var(--navy-dark);">Job Description</h4>
      <div style="font-size: 0.925rem; line-height: 1.7; color: var(--navy-surface); margin-bottom: 1.5rem; white-space: pre-line;">
        ${job.description}
      </div>

      <h4 style="font-size: 1rem; margin-bottom: 0.5rem; color: var(--navy-dark);">Required Skills & Technologies</h4>
      <div class="flex items-center gap-2 flex-wrap mb-4">
        ${skills.map(s => `<span class="badge badge-primary">${s.trim()}</span>`).join('')}
      </div>
    `;

    document.getElementById('job-details-modal').classList.add('active');
  } catch (e) {
    showToast('Failed to load job details', 'error');
  }
}

function closeJobModal() {
  document.getElementById('job-details-modal').classList.remove('active');
}

function openApplyModalFromDetails() {
  if (currentSelectedJob) {
    closeJobModal();
    triggerApplyModal(currentSelectedJob.id, currentSelectedJob.title);
  }
}

// Apply Modal Flow
function triggerApplyModal(jobId, jobTitle) {
  const user = Auth.getCurrentUser();
  if (!user) {
    showToast('Please login as a Candidate to apply for jobs.', 'warning');
    setTimeout(() => {
      window.location.href = `auth.html?role=CANDIDATE&mode=login&redirect=jobs.html`;
    }, 1200);
    return;
  }

  if (user.role !== 'CANDIDATE') {
    showToast(`Your current role is ${user.role}. Only Candidates can apply for vacancies.`, 'warning');
    return;
  }

  document.getElementById('apply-job-id').value = jobId;
  document.getElementById('apply-modal-job-title').innerText = jobTitle;
  document.getElementById('job-apply-modal').classList.add('active');
}

function closeApplyModal() {
  document.getElementById('job-apply-modal').classList.remove('active');
}

async function handleApplySubmit(e) {
  e.preventDefault();
  const user = Auth.getCurrentUser();
  if (!user || !user.candidateId) return;

  const jobId = document.getElementById('apply-job-id').value;
  const coverNote = document.getElementById('apply-cover-note').value.trim();
  const btn = document.getElementById('btn-submit-application');

  try {
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Submitting...';

    await API.applyToJob(user.candidateId, jobId, coverNote);
    closeApplyModal();
    showToast('Application submitted successfully! Track status in your Candidate Dashboard.', 'success');
  } catch (err) {
    showToast(err.message || 'Application failed to submit.', 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Submit Application';
  }
}

// Bookmark / Save Job Flow
async function handleBookmarkToggle(e, jobId) {
  e.stopPropagation();
  const user = Auth.getCurrentUser();
  if (!user || user.role !== 'CANDIDATE') {
    showToast('Please login as a Candidate to bookmark jobs.', 'warning');
    return;
  }

  try {
    const res = await API.toggleSaveJob(user.candidateId, jobId);
    const btn = e.currentTarget;
    if (res.saved) {
      btn.classList.add('bookmarked');
      btn.innerHTML = '<i class="fa-solid fa-bookmark"></i>';
      showToast('Job saved to your bookmarks!', 'success');
    } else {
      btn.classList.remove('bookmarked');
      btn.innerHTML = '<i class="fa-regular fa-bookmark"></i>';
      showToast('Job removed from saved list.', 'info');
    }
  } catch (err) {
    showToast('Failed to update bookmark.', 'error');
  }
}

