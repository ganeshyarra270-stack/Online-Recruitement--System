/**
 * CareerConnect - Online Recruitment System
 * Mock Database & In-Memory / LocalStorage Persistence Engine
 * Enables fully-functional standalone demonstrations even when MySQL/Spring Boot is offline.
 */

const DB_KEY = 'careerconnect_db_v1';

const INITIAL_MOCK_DATA = {
  users: [
    {
      id: 1,
      email: 'admin@careerconnect.com',
      password: 'admin123',
      role: 'ADMIN',
      fullName: 'Master Admin',
      phone: '+1 (555) 019-2834',
      avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
      status: 'ACTIVE',
      createdAt: '2026-10-01'
    },
    {
      id: 2,
      email: 'recruiter@techcorp.com',
      password: 'pass123',
      role: 'RECRUITER',
      fullName: 'Marcus Vance',
      phone: '+1 (555) 432-8765',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
      status: 'ACTIVE',
      createdAt: '2026-10-05'
    },
    {
      id: 3,
      email: 'sarah@innovatech.io',
      password: 'pass123',
      role: 'RECRUITER',
      fullName: 'Sarah Jenkins',
      phone: '+1 (555) 876-5432',
      avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150',
      status: 'ACTIVE',
      createdAt: '2026-10-08'
    },
    {
      id: 4,
      email: 'rajesh@cloudscale.net',
      password: 'pass123',
      role: 'RECRUITER',
      fullName: 'Rajesh Kothari',
      phone: '+91 98765 43210',
      avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
      status: 'ACTIVE',
      createdAt: '2026-10-10'
    },
    {
      id: 5,
      email: 'candidate@careerconnect.com',
      password: 'pass123',
      role: 'CANDIDATE',
      fullName: 'Alex Morgan',
      phone: '+1 (555) 234-5678',
      avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
      status: 'ACTIVE',
      createdAt: '2026-10-12'
    },
    {
      id: 6,
      email: 'priya.sharma@example.com',
      password: 'pass123',
      role: 'CANDIDATE',
      fullName: 'Priya Sharma',
      phone: '+91 98112 34567',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      status: 'ACTIVE',
      createdAt: '2026-10-15'
    },
    {
      id: 7,
      email: 'david.miller@example.com',
      password: 'pass123',
      role: 'CANDIDATE',
      fullName: 'David Miller',
      phone: '+1 (555) 987-6543',
      avatarUrl: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150',
      status: 'ACTIVE',
      createdAt: '2026-10-18'
    }
  ],
  companies: [
    {
      id: 1,
      name: 'TechCorp Global',
      logoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120',
      website: 'https://techcorp-example.com',
      industry: 'Information Technology',
      description: 'TechCorp is a leading enterprise cloud software provider creating scalable distributed solutions for Fortune 500 corporations worldwide.',
      location: 'Bangalore, India & San Francisco, USA',
      foundedYear: 2012,
      employeeCount: '1000-5000',
      verified: true
    },
    {
      id: 2,
      name: 'InnovaTech Labs',
      logoUrl: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=120',
      website: 'https://innovatech-example.io',
      industry: 'Artificial Intelligence',
      description: 'Pioneering frontier deep learning architectures, intelligent analytics, and generative AI copilot automation engines for enterprise clients.',
      location: 'Hyderabad, India & New York, USA',
      foundedYear: 2018,
      employeeCount: '200-500',
      verified: true
    },
    {
      id: 3,
      name: 'CloudScale Solutions',
      logoUrl: 'https://images.unsplash.com/photo-1572021335469-31706a17aaef?w=120',
      website: 'https://cloudscale-example.net',
      industry: 'Fintech & Cloud Systems',
      description: 'Building high-throughput, low-latency transaction processing and resilient multi-cloud infrastructure across 14 international data zones.',
      location: 'Pune, India & London, UK',
      foundedYear: 2015,
      employeeCount: '500-1000',
      verified: true
    },
    {
      id: 4,
      name: 'NexGen Media Studio',
      logoUrl: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=120',
      website: 'https://nexgenmedia-example.com',
      industry: 'Digital Design & Media',
      description: 'Design agency crafting award-winning responsive design systems, 3D interactive graphics, and seamless mobile consumer applications.',
      location: 'Mumbai, India',
      foundedYear: 2020,
      employeeCount: '50-150',
      verified: true
    },
    {
      id: 5,
      name: 'CyberShield Defense',
      logoUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=120',
      website: 'https://cybershield-example.org',
      industry: 'Cybersecurity',
      description: 'Next-generation automated threat mitigation, identity access management, and cloud security governance software.',
      location: 'Austin, Texas & Singapore',
      foundedYear: 2016,
      employeeCount: '500-1000',
      verified: true
    }
  ],
  candidates: [
    {
      id: 1,
      userId: 5,
      headline: 'Senior Full Stack Java & Cloud Engineer',
      bio: 'Passionate software engineer with 4+ years of hands-on experience building scalable microservices with Java Spring Boot, React, AWS, and MySQL.',
      address: 'Seattle, WA / Remote',
      education: [
        { degree: 'B.Tech in Computer Science & Engineering', institution: 'National Institute of Technology', year: '2021', score: '8.9 CGPA' },
        { degree: 'Higher Secondary Certificate (Science)', institution: 'St. Xavier High School', year: '2017', score: '92.4%' }
      ],
      experience: [
        { title: 'Full Stack Developer', company: 'CloudVertex Technologies', duration: '2022 - Present', description: 'Architected microservices using Spring Boot & Redis, cutting latency by 35%. Built responsive React dashboards for analytics.' },
        { title: 'Junior Java Developer', company: 'AlphaTech Systems', duration: '2021 - 2022', description: 'Developed RESTful web services, implemented Hibernate ORM queries, and managed unit test coverage.' }
      ],
      skills: ['Java', 'Spring Boot', 'MySQL', 'Hibernate', 'React', 'JavaScript', 'Docker', 'AWS', 'REST APIs', 'Git'],
      profileCompletion: 90
    },
    {
      id: 2,
      userId: 6,
      headline: 'Frontend Specialist & UI/UX Developer',
      bio: 'Frontend engineer dedicated to building pixel-perfect, accessible, and high-performance web applications using modern JavaScript and React.',
      address: 'Bengaluru, Karnataka, India',
      education: [
        { degree: 'B.E. in Information Technology', institution: 'Visvesvaraya Technological University', year: '2022', score: '8.6 CGPA' }
      ],
      experience: [
        { title: 'Frontend Software Engineer', company: 'PixelForge Digital', duration: '2022 - Present', description: 'Led frontend redesign in React 18, achieved 98 Lighthouse score.' }
      ],
      skills: ['React', 'JavaScript', 'TypeScript', 'Tailwind CSS', 'HTML5/CSS3', 'Next.js', 'Redux', 'Figma'],
      profileCompletion: 85
    },
    {
      id: 3,
      userId: 7,
      headline: 'Machine Learning & Data Infrastructure Engineer',
      bio: 'AI researcher and ML engineer specializing in NLP models, LLM fine-tuning, and Python backend systems with FastAPI and PyTorch.',
      address: 'Chicago, IL, USA',
      education: [
        { degree: 'M.S. in Data Science', institution: 'University of Illinois Urbana-Champaign', year: '2023', score: '3.9 GPA' }
      ],
      experience: [
        { title: 'ML Engineer Intern', company: 'DeepMind Collaborators', duration: '2023 - 2024', description: 'Trained BERT and transformer classifiers for automated document parsing.' }
      ],
      skills: ['Python', 'PyTorch', 'TensorFlow', 'FastAPI', 'PostgreSQL', 'Docker', 'NLP'],
      profileCompletion: 80
    }
  ],
  recruiters: [
    {
      id: 1,
      userId: 2,
      companyId: 1,
      designation: 'Senior Technical Recruiter',
      department: 'Talent Acquisition',
      contactNumber: '+1 (555) 432-8765',
      verified: true
    },
    {
      id: 2,
      userId: 3,
      companyId: 2,
      designation: 'Head of People & Culture',
      department: 'Human Resources',
      contactNumber: '+1 (555) 876-5432',
      verified: true
    },
    {
      id: 3,
      userId: 4,
      companyId: 3,
      designation: 'Lead Technical Talent Partner',
      department: 'Engineering Hiring',
      contactNumber: '+91 98765 43210',
      verified: true
    }
  ],
  resumes: [
    {
      id: 1,
      candidateId: 1,
      fileName: 'Alex_Morgan_FullStack_Resume.pdf',
      fileSizeKb: 380,
      fileType: 'application/pdf',
      fileUrl: '#mock-resume-download',
      uploadedAt: '2026-11-01'
    },
    {
      id: 2,
      candidateId: 2,
      fileName: 'Priya_Sharma_Frontend_Resume.pdf',
      fileSizeKb: 412,
      fileType: 'application/pdf',
      fileUrl: '#mock-resume-download',
      uploadedAt: '2026-11-02'
    }
  ],
  jobs: [
    {
      id: 1,
      recruiterId: 1,
      companyId: 1,
      title: 'Senior Full Stack Java Engineer',
      description: 'TechCorp Global is searching for an experienced Senior Full Stack Java Engineer to architect and scale our cloud enterprise applications.\n\nKey Responsibilities:\n• Design robust, secure RESTful APIs using Java 17+, Spring Boot, Spring Security, and Hibernate.\n• Develop reactive, high-performance user interfaces with React, TypeScript, and modern state management.\n• Optimize MySQL database schemas, complex queries, indexing strategies, and connection pooling.\n• Collaborate with DevOps teams to deploy microservices on AWS (ECS, RDS, S3).\n• Mentor junior developers and participate in code reviews.',
      skillsRequired: ['Java', 'Spring Boot', 'React', 'MySQL', 'Hibernate', 'AWS', 'Docker'],
      qualification: 'Bachelor or Master degree in Computer Science, Software Engineering or equivalent',
      experienceLevel: 'Senior (3-5 yrs)',
      salaryMin: 120000,
      salaryMax: 160000,
      location: 'Bangalore, India (Hybrid)',
      jobType: 'Hybrid',
      vacancies: 3,
      deadline: '2026-12-31',
      status: 'ACTIVE',
      isFeatured: true,
      viewsCount: 428,
      createdAt: '2026-10-20'
    },
    {
      id: 2,
      recruiterId: 1,
      companyId: 1,
      title: 'Cloud DevOps Architect',
      description: 'We are seeking a seasoned Cloud DevOps Architect to champion our container orchestration, CI/CD automation, and infrastructure resilience.\n\nKey Responsibilities:\n• Manage multi-region Kubernetes clusters on AWS EKS.\n• Write maintainable Infrastructure as Code (IaC) utilizing Terraform.\n• Construct automated continuous delivery pipelines with GitHub Actions.\n• Implement observability using Prometheus, Grafana, and ELK stack.',
      skillsRequired: ['AWS', 'Kubernetes', 'Docker', 'Terraform', 'CI/CD', 'Linux', 'Python'],
      qualification: 'B.Tech / B.E. in Computer Science or IT',
      experienceLevel: 'Lead / Principal (5+ yrs)',
      salaryMin: 140000,
      salaryMax: 190000,
      location: 'Remote / Global',
      jobType: 'Remote',
      vacancies: 2,
      deadline: '2026-11-30',
      status: 'ACTIVE',
      isFeatured: true,
      viewsCount: 310,
      createdAt: '2026-10-22'
    },
    {
      id: 3,
      recruiterId: 2,
      companyId: 2,
      title: 'Machine Learning Engineer (NLP & LLMs)',
      description: 'Join InnovaTech Labs at the cutting edge of generative AI and enterprise NLP systems.\n\nKey Responsibilities:\n• Fine-tune large language models and build retrieval-augmented generation (RAG) pipelines.\n• Deploy scalable ML inference microservices using FastAPI, Triton, and Docker.\n• Evaluate model latency, accuracy, hallucination rates, and drift in production environments.',
      skillsRequired: ['Python', 'PyTorch', 'LLMs', 'NLP', 'FastAPI', 'Docker'],
      qualification: 'M.S. or B.Tech in Artificial Intelligence or CS',
      experienceLevel: 'Mid-Level (1-3 yrs)',
      salaryMin: 95000,
      salaryMax: 135000,
      location: 'Hyderabad, India',
      jobType: 'Full-time',
      vacancies: 4,
      deadline: '2026-12-15',
      status: 'ACTIVE',
      isFeatured: true,
      viewsCount: 512,
      createdAt: '2026-10-25'
    },
    {
      id: 4,
      recruiterId: 2,
      companyId: 2,
      title: 'Senior Frontend Engineer (React & TypeScript)',
      description: 'InnovaTech Labs is looking for a talented Senior Frontend Engineer to build world-class user interfaces for our AI copilots.\n\nKey Responsibilities:\n• Develop responsive, modular web applications in React 18, TypeScript, and Next.js.\n• Implement real-time WebSocket interfaces for streaming AI output.\n• Ensure cross-browser compatibility, WCAG 2.1 AA accessibility, and lightning-fast load times.',
      skillsRequired: ['React', 'TypeScript', 'Next.js', 'Tailwind CSS', 'WebSockets', 'HTML5'],
      qualification: 'Bachelor Degree in Computer Science or related field',
      experienceLevel: 'Senior (3-5 yrs)',
      salaryMin: 105000,
      salaryMax: 145000,
      location: 'Hyderabad, India (Hybrid)',
      jobType: 'Hybrid',
      vacancies: 2,
      deadline: '2026-12-20',
      status: 'ACTIVE',
      isFeatured: false,
      viewsCount: 240,
      createdAt: '2026-10-28'
    },
    {
      id: 5,
      recruiterId: 3,
      companyId: 3,
      title: 'Backend Java Developer (Fintech Platform)',
      description: 'CloudScale Solutions is seeking an enthusiastic Backend Java Developer to join our core transactions settlement team.\n\nKey Responsibilities:\n• Build distributed, ACID-compliant ledger services handling thousands of transactions per second.\n• Implement event-driven architectures with Apache Kafka, Spring Boot, and Redis.\n• Ensure rigorous security standards conforming to PCI-DSS regulations.',
      skillsRequired: ['Java', 'Spring Boot', 'Kafka', 'MySQL', 'Redis', 'Microservices'],
      qualification: 'Bachelor Degree in CS / IT / Engineering',
      experienceLevel: 'Mid-Level (1-3 yrs)',
      salaryMin: 85000,
      salaryMax: 115000,
      location: 'Pune, India',
      jobType: 'Full-time',
      vacancies: 5,
      deadline: '2026-12-28',
      status: 'ACTIVE',
      isFeatured: true,
      viewsCount: 380,
      createdAt: '2026-10-29'
    },
    {
      id: 6,
      recruiterId: 3,
      companyId: 3,
      title: 'Junior Cloud & Database Administrator',
      description: 'Great opportunity for a passionate engineer to launch their career in enterprise database operations and cloud reliability engineering.\n\nKey Responsibilities:\n• Monitor MySQL and PostgreSQL database performance, replication lags, and backups.\n• Assist with schema migrations, queries optimization, and index health checks.',
      skillsRequired: ['MySQL', 'Linux', 'AWS', 'SQL', 'Bash Scripting'],
      qualification: 'Bachelor Degree in Computer Science, MCA, or BCA',
      experienceLevel: 'Fresher / Entry',
      salaryMin: 50000,
      salaryMax: 75000,
      location: 'Pune, India',
      jobType: 'Full-time',
      vacancies: 2,
      deadline: '2026-11-25',
      status: 'ACTIVE',
      isFeatured: false,
      viewsCount: 195,
      createdAt: '2026-10-30'
    },
    {
      id: 7,
      recruiterId: 1,
      companyId: 1,
      title: 'UI/UX Product Designer',
      description: 'TechCorp Global is looking for a visionary Product Designer to shape the next era of enterprise developer tooling.\n\nKey Responsibilities:\n• Conduct user interviews, build journey maps, and wireframe innovative interaction models.\n• Design high-fidelity responsive component libraries in Figma.',
      skillsRequired: ['Figma', 'UI/UX Design', 'Prototyping', 'Wireframing', 'User Research'],
      qualification: 'Degree in Design, HCI, or equivalent portfolio',
      experienceLevel: 'Mid-Level (1-3 yrs)',
      salaryMin: 80000,
      salaryMax: 110000,
      location: 'Remote / Global',
      jobType: 'Remote',
      vacancies: 1,
      deadline: '2026-12-10',
      status: 'ACTIVE',
      isFeatured: false,
      viewsCount: 280,
      createdAt: '2026-10-31'
    },
    {
      id: 8,
      recruiterId: 2,
      companyId: 2,
      title: 'Cybersecurity Operations Analyst',
      description: 'Defend critical cloud infrastructure against evolving cyber threats and ensure enterprise compliance.\n\nKey Responsibilities:\n• Analyze SIEM telemetry, investigate alerts, and execute incident containment procedures.\n• Conduct periodic vulnerability assessments and penetration testing reviews.',
      skillsRequired: ['Cybersecurity', 'SIEM', 'Network Security', 'Linux', 'Incident Response'],
      qualification: 'B.Tech in Cyber Security or Computer Science',
      experienceLevel: 'Mid-Level (1-3 yrs)',
      salaryMin: 90000,
      salaryMax: 125000,
      location: 'Hyderabad, India',
      jobType: 'Full-time',
      vacancies: 2,
      deadline: '2026-12-05',
      status: 'ACTIVE',
      isFeatured: false,
      viewsCount: 175,
      createdAt: '2026-11-01'
    }
  ],
  applications: [
    {
      id: 1,
      jobId: 1,
      candidateId: 1,
      resumeId: 1,
      coverNote: 'Dear Hiring Manager, I have over 4 years of hands-on experience building distributed enterprise applications with Spring Boot, MySQL, and React.',
      status: 'Shortlisted',
      recruiterFeedback: 'Strong technical background with Spring Boot and AWS. Scheduled for Round 1 technical interview.',
      interviewDate: '2026-11-12T14:00:00',
      appliedAt: '2026-11-01T10:30:00'
    },
    {
      id: 2,
      jobId: 2,
      candidateId: 1,
      resumeId: 1,
      coverNote: 'Hello Team, I am deeply passionate about Kubernetes orchestration and automated IaC. I look forward to contributing to your cloud resilience.',
      status: 'Pending',
      recruiterFeedback: null,
      interviewDate: null,
      appliedAt: '2026-11-03T15:45:00'
    },
    {
      id: 3,
      jobId: 7,
      candidateId: 1,
      resumeId: 1,
      coverNote: 'I have designed multiple B2B dashboards and have a strong foundation in modern design systems.',
      status: 'Reviewed',
      recruiterFeedback: 'Resume and portfolio under internal review with Lead Designer.',
      interviewDate: null,
      appliedAt: '2026-11-02T09:15:00'
    },
    {
      id: 4,
      jobId: 4,
      candidateId: 2,
      resumeId: 2,
      coverNote: 'Hi InnovaTech Team, I specialize in React 18, TypeScript, and micro-frontend development.',
      status: 'Interview Scheduled',
      recruiterFeedback: 'Selected for Live Technical Screen & System Design.',
      interviewDate: '2026-11-14T11:30:00',
      appliedAt: '2026-11-02T11:20:00'
    },
    {
      id: 5,
      jobId: 3,
      candidateId: 3,
      resumeId: 3,
      coverNote: 'Dear Recruiter, My recent master thesis focused on fine-tuning LLMs with PEFT/LoRA.',
      status: 'Shortlisted',
      recruiterFeedback: 'Impressive academic background and PyTorch skills.',
      interviewDate: '2026-11-15T16:00:00',
      appliedAt: '2026-11-03T14:00:00'
    }
  ],
  savedJobs: [
    { id: 1, candidateId: 1, jobId: 3, savedAt: '2026-11-02T12:00:00' },
    { id: 2, candidateId: 1, jobId: 5, savedAt: '2026-11-03T08:30:00' },
    { id: 3, candidateId: 1, jobId: 8, savedAt: '2026-11-04T19:20:00' }
  ],
  notifications: [
    {
      id: 1,
      userId: 5,
      title: 'Application Shortlisted!',
      message: 'TechCorp Global shortlisted your application for Senior Full Stack Java Engineer.',
      type: 'APPLICATION_STATUS',
      isRead: false,
      linkUrl: 'candidate-dashboard.html#applications',
      createdAt: '2026-11-04T11:00:00'
    },
    {
      id: 2,
      userId: 5,
      title: 'Technical Interview Scheduled',
      message: 'Your interview for Senior Full Stack Java Engineer is scheduled for Nov 12, 2026 at 02:00 PM.',
      type: 'INTERVIEW',
      isRead: false,
      linkUrl: 'candidate-dashboard.html#applications',
      createdAt: '2026-11-04T11:15:00'
    },
    {
      id: 3,
      userId: 2,
      title: 'New Candidate Application',
      message: 'Alex Morgan has submitted an application for Senior Full Stack Java Engineer.',
      type: 'APPLICATION_STATUS',
      isRead: false,
      linkUrl: 'recruiter-dashboard.html#applicants',
      createdAt: '2026-11-01T10:30:00'
    }
  ]
};

// Database Storage Controller
const MockDB = {
  load() {
    const raw = localStorage.getItem(DB_KEY);
    if (!raw) {
      this.reset();
      return INITIAL_MOCK_DATA;
    }
    try {
      return JSON.parse(raw);
    } catch (e) {
      console.error('Failed to parse local DB, resetting to defaults', e);
      this.reset();
      return INITIAL_MOCK_DATA;
    }
  },

  save(data) {
    localStorage.setItem(DB_KEY, JSON.stringify(data));
  },

  reset() {
    localStorage.setItem(DB_KEY, JSON.stringify(INITIAL_MOCK_DATA));
    return INITIAL_MOCK_DATA;
  },

  get(table) {
    const db = this.load();
    return db[table] || [];
  },

  findById(table, id) {
    const items = this.get(table);
    return items.find(item => item.id === Number(id));
  },

  insert(table, item) {
    const db = this.load();
    if (!db[table]) db[table] = [];
    const maxId = db[table].reduce((max, obj) => Math.max(max, obj.id || 0), 0);
    item.id = maxId + 1;
    item.createdAt = item.createdAt || new Date().toISOString();
    db[table].push(item);
    this.save(db);
    return item;
  },

  update(table, id, updates) {
    const db = this.load();
    if (!db[table]) return null;
    const index = db[table].findIndex(item => item.id === Number(id));
    if (index === -1) return null;
    db[table][index] = { ...db[table][index], ...updates, updatedAt: new Date().toISOString() };
    this.save(db);
    return db[table][index];
  },

  delete(table, id) {
    const db = this.load();
    if (!db[table]) return false;
    const initialLen = db[table].length;
    db[table] = db[table].filter(item => item.id !== Number(id));
    this.save(db);
    return db[table].length < initialLen;
  }
};

// Ensure database is initialized
if (!localStorage.getItem(DB_KEY)) {
  MockDB.reset();
}

