/**
 * CareerConnect - Online Recruitment System
 * Super Administrator Dashboard Controller
 */

let adminStats = {};
let allUsers = [];
let allJobs = [];
let allCompanies = [];

document.addEventListener('DOMContentLoaded', async () => {
  // Enforce ADMIN role
  if (!Auth.requireAuth(['ADMIN'])) return;

  const user = Auth.getCurrentUser();
  document.getElementById('admin-sidebar-name').innerText = user.fullName;
  if (user.avatarUrl) {
    document.getElementById('admin-sidebar-avatar').src = user.avatarUrl;
  }

  const hash = window.location.hash.replace('#', '') || 'overview';
  switchAdminTab(hash);

  await loadAdminData();
});

function switchAdminTab(tabId) {
  const tabs = ['overview', 'candidates', 'recruiters', 'jobs', 'companies'];
  tabs.forEach(t => {
    const el = document.getElementById(`tab-admin-${t}`);
    if (el) el.style.display = (t === tabId) ? 'block' : 'none';
  });

  document.querySelectorAll('.sidebar-item').forEach(item => {
    item.classList.remove('active');
    if (item.getAttribute('href') === `#${tabId}`) {
      item.classList.add('active');
    }
  });

  window.location.hash = `#${tabId}`;
}

async function loadAdminData() {
  try {
    adminStats = await API.getAdminStats();
    allUsers = await API.getAdminUsers();
    allJobs = await API.getJobs();
    allCompanies = await API.getCompanies();

    renderAdminMetrics();
    renderOverviewJobs();
    renderCandidatesTable();
    renderRecruitersTable();
    renderAllJobsModerationTable();
    renderCompaniesTable();
  } catch (err) {
    console.error('Failed to load admin metrics:', err);
    showToast('Failed to load admin records', 'error');
  }
}

function renderAdminMetrics() {
  document.getElementById('admin-stat-candidates').innerText = adminStats.totalCandidates || 0;
  document.getElementById('admin-stat-recruiters').innerText = adminStats.totalRecruiters || 0;
  document.getElementById('admin-stat-companies').innerText = adminStats.totalCompanies || 0;
  document.getElementById('admin-stat-jobs').innerText = adminStats.totalJobs || 0;
  document.getElementById('admin-stat-applications').innerText = adminStats.totalApplications || 0;

  document.getElementById('admin-cand-badge').innerText = adminStats.totalCandidates || 0;
  document.getElementById('admin-rec-badge').innerText = adminStats.totalRecruiters || 0;
  document.getElementById('admin-jobs-badge').innerText = adminStats.totalJobs || 0;
}

function renderOverviewJobs() {
  const tbody = document.getElementById('admin-overview-jobs-body');
  tbody.innerHTML = allJobs.slice(0, 4).map(job => `
    <tr>
      <td>
        <div style="font-weight: 700; color: var(--navy-dark);">${job.title}</div>
        <div style="font-size: 0.8rem; color: var(--navy-muted);">${job.jobType} • ${job.experienceLevel}</div>
      </td>
      <td>${job.companyName}</td>
      <td>${job.location}</td>
      <td>
        <span class="status-pill ${job.status === 'ACTIVE' ? 'status-active' : 'status-closed'}">${job.status}</span>
      </td>
      <td>
        <div class="flex items-center gap-2">
          ${job.status !== 'ACTIVE' ? `
            <button class="btn btn-success btn-sm" onclick="setJobStatus(${job.id}, 'ACTIVE')">Approve</button>
          ` : `
            <button class="btn btn-warning btn-sm" onclick="setJobStatus(${job.id}, 'CLOSED')">Close</button>
          `}
          <button class="btn btn-danger btn-sm" onclick="removeJob(${job.id})"><i class="fa-solid fa-trash"></i></button>
        </div>
      </td>
    </tr>
  `).join('');
}

function renderCandidatesTable() {
  const tbody = document.getElementById('admin-candidates-body');
  const candidates = allUsers.filter(u => u.role === 'CANDIDATE');

  tbody.innerHTML = candidates.map(user => `
    <tr>
      <td>
        <div class="flex items-center gap-3">
          <img src="${user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}" style="width: 38px; height: 38px; border-radius: 50%; object-fit: cover;" />
          <div>
            <div style="font-weight: 700; color: var(--navy-dark);">${user.fullName}</div>
            <div style="font-size: 0.775rem; color: var(--navy-muted);">ID: #${user.id}</div>
          </div>
        </div>
      </td>
      <td>${user.email}</td>
      <td>${user.phone || 'N/A'}</td>
      <td>${user.createdAt ? new Date(user.createdAt).toLocaleDateString() : '2026-10-15'}</td>
      <td>
        <span class="status-pill ${user.status === 'ACTIVE' ? 'status-active' : 'status-rejected'}">${user.status}</span>
      </td>
      <td>
        <button class="btn btn-outline btn-sm" onclick="toggleUserStatus(${user.id}, '${user.status}')">
          ${user.status === 'ACTIVE' ? '<i class="fa-solid fa-ban text-danger"></i> Suspend' : '<i class="fa-solid fa-check text-success"></i> Activate'}
        </button>
      </td>
    </tr>
  `).join('');
}

function renderRecruitersTable() {
  const tbody = document.getElementById('admin-recruiters-body');
  const recruiters = allUsers.filter(u => u.role === 'RECRUITER');
  const recDetails = MockDB.get('recruiters');

  tbody.innerHTML = recruiters.map(user => {
    const r = recDetails.find(rd => rd.userId === user.id) || {};
    const comp = allCompanies.find(c => c.id === r.companyId) || { name: 'Enterprise' };

    return `
      <tr>
        <td>
          <div class="flex items-center gap-3">
            <img src="${user.avatarUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150'}" style="width: 38px; height: 38px; border-radius: 50%; object-fit: cover;" />
            <div style="font-weight: 700; color: var(--navy-dark);">${user.fullName}</div>
          </div>
        </td>
        <td>${user.email}</td>
        <td><strong>${comp.name}</strong></td>
        <td>${r.designation || 'Hiring Manager'}</td>
        <td>
          <span class="status-pill ${user.status === 'ACTIVE' ? 'status-active' : 'status-rejected'}">${user.status}</span>
        </td>
        <td>
          <button class="btn btn-outline btn-sm" onclick="toggleUserStatus(${user.id}, '${user.status}')">
            ${user.status === 'ACTIVE' ? '<i class="fa-solid fa-ban text-danger"></i> Suspend' : '<i class="fa-solid fa-check text-success"></i> Activate'}
          </button>
        </td>
      </tr>
    `;
  }).join('');
}

function renderAllJobsModerationTable() {
  const tbody = document.getElementById('admin-all-jobs-body');
  tbody.innerHTML = allJobs.map(job => `
    <tr>
      <td>
        <div style="font-weight: 700; color: var(--navy-dark); font-size: 0.95rem;">${job.title}</div>
        <div style="font-size: 0.8rem; color: var(--navy-muted);">${job.location} • ${job.jobType}</div>
      </td>
      <td><strong>${job.companyName}</strong></td>
      <td>$${(job.salaryMin).toLocaleString()} - $${(job.salaryMax).toLocaleString()}</td>
      <td>
        <span class="status-pill ${job.status === 'ACTIVE' ? 'status-active' : 'status-closed'}">${job.status}</span>
      </td>
      <td>
        <div class="flex items-center gap-2">
          ${job.status === 'ACTIVE' ? `
            <button class="btn btn-warning btn-sm" onclick="setJobStatus(${job.id}, 'CLOSED')">Close</button>
          ` : `
            <button class="btn btn-success btn-sm" onclick="setJobStatus(${job.id}, 'ACTIVE')">Approve</button>
          `}
          <button class="btn btn-danger btn-sm" onclick="removeJob(${job.id})" title="Delete Posting">
            <i class="fa-solid fa-trash"></i>
          </button>
        </div>
      </td>
    </tr>
  `).join('');
}

function renderCompaniesTable() {
  const tbody = document.getElementById('admin-companies-body');
  tbody.innerHTML = allCompanies.map(c => `
    <tr>
      <td>
        <div class="flex items-center gap-3">
          <img src="${c.logoUrl}" style="width: 40px; height: 40px; border-radius: 8px; object-fit: cover; border: 1px solid var(--border-light);" />
          <div style="font-weight: 700; color: var(--navy-dark);">${c.name}</div>
        </div>
      </td>
      <td>${c.industry}</td>
      <td>${c.location}</td>
      <td>${c.employeeCount || '200-500'}</td>
      <td>
        <span class="badge badge-success"><i class="fa-solid fa-check"></i> Verified</span>
      </td>
      <td>
        <a href="jobs.html?company=${encodeURIComponent(c.name)}" class="btn btn-outline btn-sm">
          View Jobs (${c.openPositions || 0})
        </a>
      </td>
    </tr>
  `).join('');
}

async function toggleUserStatus(userId, currentStatus) {
  const newStatus = (currentStatus === 'ACTIVE') ? 'SUSPENDED' : 'ACTIVE';
  await API.updateUserStatus(userId, newStatus);
  showToast(`User status updated to ${newStatus}.`, 'info');
  await loadAdminData();
}

async function setJobStatus(jobId, newStatus) {
  await API.updateJob(jobId, { status: newStatus });
  showToast(`Job status set to ${newStatus}.`, 'success');
  await loadAdminData();
}

async function removeJob(jobId) {
  if (!confirm('Remove this job listing from the platform?')) return;
  await API.deleteJob(jobId);
  showToast('Job listing removed by admin.', 'info');
  await loadAdminData();
}

