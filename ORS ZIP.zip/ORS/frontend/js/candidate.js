/**
 * CareerConnect - Online Recruitment System
 * Candidate Dashboard Controller
 */

let candidateProfile = null;
let candidateApps = [];

document.addEventListener('DOMContentLoaded', async () => {
  // Enforce CANDIDATE role
  if (!Auth.requireAuth(['CANDIDATE'])) return;

  const user = Auth.getCurrentUser();
  document.getElementById('sidebar-name').innerText = user.fullName;
  document.getElementById('dash-greeting-name').innerText = user.fullName.split(' ')[0];
  if (user.avatarUrl) {
    document.getElementById('sidebar-avatar').src = user.avatarUrl;
  }

  // Handle URL hash tab switching
  const hash = window.location.hash.replace('#', '') || 'overview';
  switchTab(hash);

  await loadDashboardData();
});

function switchTab(tabId) {
  const tabs = ['overview', 'profile', 'education', 'experience', 'skills', 'resume', 'applications', 'saved'];
  tabs.forEach(t => {
    const el = document.getElementById(`tab-content-${t}`);
    if (el) el.style.display = (t === tabId) ? 'block' : 'none';
  });

  // Update sidebar active state
  document.querySelectorAll('.sidebar-item').forEach(item => {
    item.classList.remove('active');
    if (item.getAttribute('href') === `#${tabId}`) {
      item.classList.add('active');
    }
  });

  window.location.hash = `#${tabId}`;
}

async function loadDashboardData() {
  const user = Auth.getCurrentUser();
  if (!user || !user.candidateId) return;

  try {
    candidateProfile = await API.getCandidateProfile(user.candidateId);
    candidateApps = await API.getApplications({ candidateId: user.candidateId });

    renderOverviewMetrics();
    renderProfileDetails();
    renderEducationList();
    renderExperienceList();
    renderSkillsChips();
    renderResumeSection();
    renderApplicationsTable();
    await renderSavedJobs();
    await renderRecommendedJobs();
  } catch (err) {
    console.error('Failed to load candidate dashboard:', err);
    showToast('Failed to load profile details', 'error');
  }
}

function renderOverviewMetrics() {
  const total = candidateApps.length;
  const pending = candidateApps.filter(a => a.status === 'Pending').length;
  const shortlisted = candidateApps.filter(a => a.status === 'Shortlisted' || a.status === 'Interview Scheduled').length;
  const rejected = candidateApps.filter(a => a.status === 'Rejected').length;

  document.getElementById('metric-total-applied').innerText = total;
  document.getElementById('metric-pending').innerText = pending;
  document.getElementById('metric-shortlisted').innerText = shortlisted;
  document.getElementById('metric-rejected').innerText = rejected;
  document.getElementById('sidebar-app-count').innerText = total;

  // Profile completion score
  const score = candidateProfile.profileCompletion || 75;
  document.getElementById('completion-badge').innerText = `${score}%`;
  document.getElementById('completion-bar').style.width = `${score}%`;

  // Render recent 3 applications on overview
  const recentTbody = document.getElementById('overview-recent-apps');
  if (candidateApps.length === 0) {
    recentTbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted">No applications submitted yet. Browse jobs to apply!</td></tr>`;
  } else {
    recentTbody.innerHTML = candidateApps.slice(0, 3).map(app => renderApplicationRow(app)).join('');
  }
}

function renderApplicationRow(app) {
  let statusClass = 'status-pending';
  if (app.status === 'Reviewed') statusClass = 'status-reviewed';
  else if (app.status === 'Shortlisted') statusClass = 'status-shortlisted';
  else if (app.status === 'Interview Scheduled') statusClass = 'status-interview';
  else if (app.status === 'Rejected') statusClass = 'status-rejected';
  else if (app.status === 'Hired') statusClass = 'status-hired';

  const dateStr = app.appliedAt ? new Date(app.appliedAt).toLocaleDateString() : 'Recent';

  return `
    <tr>
      <td>
        <div class="flex items-center gap-3">
          <img src="${app.companyLogo || 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=120'}" style="width: 40px; height: 40px; border-radius: 8px; object-fit: cover; border: 1px solid var(--border-light);" />
          <div>
            <div style="font-weight: 700; color: var(--navy-dark);">${app.jobTitle}</div>
            <div style="font-size: 0.8rem; color: var(--navy-muted);">${app.companyName}</div>
          </div>
        </div>
      </td>
      <td>
        <div>${app.jobLocation || 'Remote'}</div>
        <div style="font-size: 0.775rem; color: var(--navy-muted);">${app.jobType || 'Full-time'}</div>
      </td>
      <td>${app.salaryRange || 'Competitive'}</td>
      <td>${dateStr}</td>
      <td>
        <span class="status-pill ${statusClass}">${app.status}</span>
      </td>
      <td>
        <button class="btn btn-outline btn-sm" onclick="openTimelineModal(${app.id})">
          <i class="fa-solid fa-timeline"></i> Track
        </button>
      </td>
    </tr>
  `;
}

function renderProfileDetails() {
  if (!candidateProfile) return;
  document.getElementById('prof-name').value = candidateProfile.fullName || '';
  document.getElementById('prof-email').value = candidateProfile.email || '';
  document.getElementById('prof-phone').value = candidateProfile.phone || '';
  document.getElementById('prof-headline').value = candidateProfile.headline || '';
  document.getElementById('prof-address').value = candidateProfile.address || '';
  document.getElementById('prof-bio').value = candidateProfile.bio || '';
}

async function saveProfileDetails(e) {
  e.preventDefault();
  const btn = document.getElementById('btn-save-profile');
  btn.disabled = true;
  btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Saving...';

  const updates = {
    fullName: document.getElementById('prof-name').value.trim(),
    phone: document.getElementById('prof-phone').value.trim(),
    headline: document.getElementById('prof-headline').value.trim(),
    address: document.getElementById('prof-address').value.trim(),
    bio: document.getElementById('prof-bio').value.trim()
  };

  try {
    const updated = await API.updateCandidateProfile(candidateProfile.id, updates);
    candidateProfile = { ...candidateProfile, ...updated };
    document.getElementById('sidebar-name').innerText = updates.fullName;
    showToast('Profile information updated successfully!', 'success');
  } catch (err) {
    showToast('Failed to update profile details', 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Save Profile Details';
  }
}

// Education List
function renderEducationList() {
  const container = document.getElementById('education-list-container');
  const edu = candidateProfile.education || [];

  if (edu.length === 0) {
    container.innerHTML = `<p class="text-muted text-center" style="padding: 1.5rem;">No qualifications added yet.</p>`;
    return;
  }

  container.innerHTML = edu.map((item, idx) => `
    <div style="padding: 1rem 0; border-bottom: 1px solid var(--border-light); display: flex; justify-content: space-between; align-items: center;">
      <div>
        <h4 style="font-size: 1.05rem; color: var(--navy-dark);">${item.degree}</h4>
        <div style="font-size: 0.9rem; color: var(--navy-muted);">${item.institution} • Year: ${item.year}</div>
        ${item.score ? `<div style="font-size: 0.8rem; color: var(--primary); font-weight: 600;">Grade: ${item.score}</div>` : ''}
      </div>
      <button class="btn btn-outline btn-sm" onclick="removeEducation(${idx})" title="Remove Qualification">
        <i class="fa-solid fa-trash text-danger"></i>
      </button>
    </div>
  `).join('');
}

function openAddEducationModal() {
  document.getElementById('education-modal').classList.add('active');
}
function closeEduModal() {
  document.getElementById('education-modal').classList.remove('active');
}

async function handleSaveEducation(e) {
  e.preventDefault();
  const degree = document.getElementById('edu-degree').value.trim();
  const institution = document.getElementById('edu-inst').value.trim();
  const year = document.getElementById('edu-year').value.trim();
  const score = document.getElementById('edu-score').value.trim();

  const newEdu = [...(candidateProfile.education || []), { degree, institution, year, score }];
  await API.updateCandidateProfile(candidateProfile.id, { education: newEdu });
  candidateProfile.education = newEdu;
  renderEducationList();
  closeEduModal();
  e.target.reset();
  showToast('Educational qualification added!', 'success');
}

async function removeEducation(idx) {
  if (!confirm('Remove this qualification?')) return;
  const newEdu = candidateProfile.education.filter((_, i) => i !== idx);
  await API.updateCandidateProfile(candidateProfile.id, { education: newEdu });
  candidateProfile.education = newEdu;
  renderEducationList();
  showToast('Qualification removed.', 'info');
}

// Experience List
function renderExperienceList() {
  const container = document.getElementById('experience-list-container');
  const exp = candidateProfile.experience || [];

  if (exp.length === 0) {
    container.innerHTML = `<p class="text-muted text-center" style="padding: 1.5rem;">No work experience entries recorded yet.</p>`;
    return;
  }

  container.innerHTML = exp.map((item, idx) => `
    <div style="padding: 1rem 0; border-bottom: 1px solid var(--border-light); display: flex; justify-content: space-between; align-items: flex-start;">
      <div>
        <h4 style="font-size: 1.05rem; color: var(--navy-dark);">${item.title}</h4>
        <div style="font-size: 0.9rem; color: var(--navy-muted); margin-bottom: 0.35rem;">
          <i class="fa-regular fa-building"></i> ${item.company} • ${item.duration}
        </div>
        <p style="font-size: 0.875rem; color: var(--navy-surface); line-height: 1.6;">${item.description || ''}</p>
      </div>
      <button class="btn btn-outline btn-sm" onclick="removeExperience(${idx})" title="Remove Experience">
        <i class="fa-solid fa-trash text-danger"></i>
      </button>
    </div>
  `).join('');
}

function openAddExperienceModal() {
  document.getElementById('experience-modal').classList.add('active');
}
function closeExpModal() {
  document.getElementById('experience-modal').classList.remove('active');
}

async function handleSaveExperience(e) {
  e.preventDefault();
  const title = document.getElementById('exp-title').value.trim();
  const company = document.getElementById('exp-company').value.trim();
  const duration = document.getElementById('exp-duration').value.trim();
  const description = document.getElementById('exp-desc').value.trim();

  const newExp = [...(candidateProfile.experience || []), { title, company, duration, description }];
  await API.updateCandidateProfile(candidateProfile.id, { experience: newExp });
  candidateProfile.experience = newExp;
  renderExperienceList();
  closeExpModal();
  e.target.reset();
  showToast('Experience added successfully!', 'success');
}

async function removeExperience(idx) {
  if (!confirm('Remove this experience record?')) return;
  const newExp = candidateProfile.experience.filter((_, i) => i !== idx);
  await API.updateCandidateProfile(candidateProfile.id, { experience: newExp });
  candidateProfile.experience = newExp;
  renderExperienceList();
  showToast('Experience entry removed.', 'info');
}

// Skills Management
function renderSkillsChips() {
  const container = document.getElementById('candidate-skills-chips');
  const skills = candidateProfile.skills || [];

  if (skills.length === 0) {
    container.innerHTML = '<span class="text-muted" style="font-size: 0.85rem; padding: 0.5rem;">No technical skills listed yet.</span>';
    return;
  }

  container.innerHTML = skills.map((s, idx) => `
    <span class="tag-item">
      ${s}
      <i class="fa-solid fa-xmark tag-remove" onclick="removeSkill(${idx})"></i>
    </span>
  `).join('');
}

async function handleAddSkill() {
  const input = document.getElementById('skill-new-input');
  const skill = input.value.trim();
  if (!skill) return;

  const skills = candidateProfile.skills || [];
  if (skills.map(s => s.toLowerCase()).includes(skill.toLowerCase())) {
    showToast('This skill has already been added.', 'warning');
    return;
  }

  const updatedSkills = [...skills, skill];
  await API.updateCandidateProfile(candidateProfile.id, { skills: updatedSkills });
  candidateProfile.skills = updatedSkills;
  renderSkillsChips();
  input.value = '';
  showToast(`Added skill: ${skill}`, 'success');
}

async function removeSkill(idx) {
  const updatedSkills = candidateProfile.skills.filter((_, i) => i !== idx);
  await API.updateCandidateProfile(candidateProfile.id, { skills: updatedSkills });
  candidateProfile.skills = updatedSkills;
  renderSkillsChips();
}

// Resume Section
function renderResumeSection() {
  const container = document.getElementById('current-resume-display');
  const resumes = candidateProfile.resumes || [];

  if (resumes.length === 0) {
    container.innerHTML = `
      <div style="background: var(--bg-alt); padding: 1.25rem; border-radius: 10px; text-align: center;">
        <i class="fa-solid fa-file-circle-exclamation text-muted" style="font-size: 1.8rem; margin-bottom: 0.5rem;"></i>
        <div style="font-weight: 600; color: var(--navy-dark);">No PDF Resume Uploaded</div>
        <div class="text-muted" style="font-size: 0.85rem;">Upload a resume above to enable 1-click recruiter applications.</div>
      </div>
    `;
    return;
  }

  const resume = resumes[0];
  container.innerHTML = `
    <div style="display: flex; align-items: center; justify-content: space-between; padding: 1.25rem; background: var(--bg-alt); border-radius: 12px; border: 1px solid var(--border-light);">
      <div class="flex items-center gap-3">
        <div style="width: 48px; height: 48px; border-radius: 10px; background: #fee2e2; color: #dc2626; display: flex; align-items: center; justify-content: center; font-size: 1.5rem;">
          <i class="fa-solid fa-file-pdf"></i>
        </div>
        <div>
          <div style="font-weight: 700; color: var(--navy-dark); font-size: 1rem;">${resume.fileName}</div>
          <div style="font-size: 0.8rem; color: var(--navy-muted);">Size: ${resume.fileSizeKb} KB • Uploaded: ${resume.uploadedAt || 'Recent'}</div>
        </div>
      </div>
      <div class="flex items-center gap-2">
        <button class="btn btn-outline btn-sm" onclick="downloadSampleResume('${resume.fileName}')">
          <i class="fa-solid fa-download"></i> Download
        </button>
      </div>
    </div>
  `;
}

async function handleResumeFileSelected(e) {
  const file = e.target.files[0];
  if (!file) return;

  if (file.type !== 'application/pdf' && !file.name.endsWith('.pdf')) {
    showToast('Only PDF files are supported.', 'error');
    return;
  }

  if (file.size > 5 * 1024 * 1024) {
    showToast('File size exceeds the 5MB limit.', 'error');
    return;
  }

  showToast('Uploading PDF resume...', 'info');
  try {
    const newResume = await API.uploadResume(candidateProfile.id, file);
    candidateProfile.resumes = [newResume];
    renderResumeSection();
    showToast('Resume uploaded successfully!', 'success');
  } catch (err) {
    showToast('Failed to upload resume.', 'error');
  }
}

function downloadSampleResume(fileName) {
  // Generate a clean dummy PDF document download for evaluation demonstration
  const dummyContent = `CareerConnect Verified Candidate Profile\n\nName: ${candidateProfile.fullName}\nEmail: ${candidateProfile.email}\nHeadline: ${candidateProfile.headline}\nSkills: ${(candidateProfile.skills || []).join(', ')}`;
  const blob = new Blob([dummyContent], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  showToast(`Downloading ${fileName}...`, 'success');
}

// Applications Tab
function renderApplicationsTable() {
  const tbody = document.getElementById('candidate-all-apps-body');
  if (candidateApps.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted" style="padding: 2rem;">No applications submitted yet.</td></tr>`;
    return;
  }

  tbody.innerHTML = candidateApps.map(app => renderApplicationRow(app)).join('');
}

function filterApplicationsTable() {
  const q = document.getElementById('app-search').value.toLowerCase();
  const filtered = candidateApps.filter(a => 
    a.jobTitle.toLowerCase().includes(q) || 
    a.companyName.toLowerCase().includes(q) ||
    a.status.toLowerCase().includes(q)
  );
  const tbody = document.getElementById('candidate-all-apps-body');
  tbody.innerHTML = filtered.map(app => renderApplicationRow(app)).join('');
}

// Status Timeline Stepper Modal
function openTimelineModal(appId) {
  const app = candidateApps.find(a => a.id === appId);
  if (!app) return;

  const body = document.getElementById('timeline-modal-body');

  const steps = [
    { key: 'Pending', label: 'Application Submitted' },
    { key: 'Reviewed', label: 'Under Review' },
    { key: 'Shortlisted', label: 'Candidate Shortlisted' },
    { key: 'Interview Scheduled', label: 'Interview Scheduled' },
    { key: 'Hired', label: 'Hiring Decision' }
  ];

  let currentIdx = 0;
  if (app.status === 'Reviewed') currentIdx = 1;
  else if (app.status === 'Shortlisted') currentIdx = 2;
  else if (app.status === 'Interview Scheduled') currentIdx = 3;
  else if (app.status === 'Hired') currentIdx = 4;
  else if (app.status === 'Rejected') currentIdx = -1;

  body.innerHTML = `
    <div class="mb-4">
      <h4 style="font-size: 1.15rem; color: var(--navy-dark);">${app.jobTitle}</h4>
      <div style="font-size: 0.9rem; color: var(--navy-muted);">${app.companyName}</div>
    </div>

    ${app.status === 'Rejected' ? `
      <div class="card" style="background: var(--danger-bg); border-color: #fecaca; margin-bottom: 1.5rem;">
        <div class="flex items-center gap-2" style="color: var(--danger); font-weight: 700; margin-bottom: 0.25rem;">
          <i class="fa-solid fa-circle-xmark"></i> Application Not Selected
        </div>
        <p style="font-size: 0.875rem; color: var(--danger-text);">
          ${app.recruiterFeedback || 'Thank you for your interest. While your profile was strong, the hiring team has moved forward with another candidate for this role.'}
        </p>
      </div>
    ` : `
      <div class="status-stepper">
        ${steps.map((st, i) => {
          let nodeClass = '';
          if (i < currentIdx) nodeClass = 'completed';
          else if (i === currentIdx) nodeClass = 'current';

          return `
            <div class="step-node ${nodeClass}">
              <div class="step-circle">
                ${i < currentIdx ? '<i class="fa-solid fa-check"></i>' : (i + 1)}
              </div>
              <div class="step-label">${st.label}</div>
            </div>
          `;
        }).join('')}
      </div>
    `}

    <div class="card" style="background: var(--bg-alt); margin-top: 1.5rem;">
      <h5 style="font-size: 0.9rem; color: var(--navy-dark); margin-bottom: 0.35rem;">Recruiter Feedback & Updates:</h5>
      <p style="font-size: 0.875rem; color: var(--navy-surface);">
        ${app.recruiterFeedback || 'No additional comments provided yet. Check back soon!'}
      </p>
      ${app.interviewDate ? `
        <div class="mt-2" style="font-weight: 700; color: var(--primary); font-size: 0.875rem;">
          <i class="fa-regular fa-calendar-check"></i> Scheduled Interview: ${new Date(app.interviewDate).toLocaleString()}
        </div>
      ` : ''}
    </div>
  `;

  document.getElementById('status-timeline-modal').classList.add('active');
}

function closeTimelineModal() {
  document.getElementById('status-timeline-modal').classList.remove('active');
}

// Saved Jobs Tab
async function renderSavedJobs() {
  const container = document.getElementById('candidate-saved-jobs-grid');
  const user = Auth.getCurrentUser();
  if (!user || !user.candidateId) return;

  const savedJobs = await API.getSavedJobs(user.candidateId);
  document.getElementById('sidebar-saved-count').innerText = savedJobs.length;

  if (savedJobs.length === 0) {
    container.innerHTML = `
      <p class="text-muted text-center" style="grid-column: 1/-1; padding: 2rem;">
        You haven't bookmarked any jobs yet. Browse vacancies and click the bookmark icon to save them here!
      </p>
    `;
    return;
  }

  container.innerHTML = savedJobs.map(job => `
    <div class="job-card">
      <div class="job-card-header">
        <div class="company-logo-wrap">
          <img src="${job.companyLogo || 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=120'}" />
        </div>
        <button class="btn-bookmark bookmarked" onclick="handleRemoveBookmark(${job.id})">
          <i class="fa-solid fa-bookmark"></i>
        </button>
      </div>
      <div class="job-card-body">
        <h3 class="job-title">${job.title}</h3>
        <div class="job-company-name">${job.companyName}</div>
        <div class="job-meta-row">
          <span><i class="fa-solid fa-location-dot"></i> ${job.location}</span>
          <span><i class="fa-regular fa-clock"></i> ${job.jobType}</span>
        </div>
      </div>
      <div class="job-card-footer">
        <div class="job-salary">$${(job.salaryMin).toLocaleString()} - $${(job.salaryMax).toLocaleString()}</div>
        <a href="jobs.html?search=${encodeURIComponent(job.title)}" class="btn btn-primary btn-sm">Apply Now</a>
      </div>
    </div>
  `).join('');
}

async function handleRemoveBookmark(jobId) {
  const user = Auth.getCurrentUser();
  await API.toggleSaveJob(user.candidateId, jobId);
  showToast('Removed from saved jobs', 'info');
  await renderSavedJobs();
}

// Recommended Jobs for Candidate
async function renderRecommendedJobs() {
  const container = document.getElementById('candidate-recommended-jobs');
  const allJobs = await API.getJobs();
  const candidateSkills = (candidateProfile.skills || []).map(s => s.toLowerCase());

  // Match jobs with candidate skills
  const rec = allJobs.filter(j => {
    const jobSkills = Array.isArray(j.skillsRequired) ? j.skillsRequired : (j.skillsRequired || '').split(',');
    return jobSkills.some(s => candidateSkills.includes(s.trim().toLowerCase()));
  }).slice(0, 3);

  if (rec.length === 0) {
    container.innerHTML = `<p class="text-muted text-center" style="grid-column: 1/-1;">Add more technical skills to your profile to get personalized recommendations.</p>`;
    return;
  }

  container.innerHTML = rec.map(j => `
    <div class="card card-hover" style="display: flex; flex-direction: column; justify-content: space-between;">
      <div>
        <div class="flex items-center gap-3 mb-3">
          <img src="${j.companyLogo || 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=120'}" style="width: 44px; height: 44px; border-radius: 8px; object-fit: cover;" />
          <div>
            <h4 style="font-size: 1.05rem; color: var(--navy-dark);">${j.title}</h4>
            <div style="font-size: 0.8rem; color: var(--navy-muted);">${j.companyName}</div>
          </div>
        </div>
        <div style="font-size: 0.85rem; color: var(--navy-surface); margin-bottom: 1rem;">
          <div><i class="fa-solid fa-location-dot text-muted"></i> ${j.location}</div>
          <div><i class="fa-solid fa-dollar-sign text-muted"></i> $${(j.salaryMin).toLocaleString()} - $${(j.salaryMax).toLocaleString()}</div>
        </div>
      </div>
      <a href="jobs.html?search=${encodeURIComponent(j.title)}" class="btn btn-outline-primary btn-sm" style="width: 100%;">
        View & Apply <i class="fa-solid fa-arrow-right"></i>
      </a>
    </div>
  `).join('');
}

