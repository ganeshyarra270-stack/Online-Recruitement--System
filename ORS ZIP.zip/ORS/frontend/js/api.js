/**
 * CareerConnect - Online Recruitment System
 * Unified API Client Layer (Dual Mode: Live Spring Boot REST API + Local DB Fallback)
 */

const API_CONFIG = {
  BASE_URL: 'http://localhost:8080/api',
  TIMEOUT_MS: 1500,
  PREFER_MOCK: false // Can be toggled manually
};

const API = {
  isBackendOnline: false,

  // Helper to fetch with timeout
  async request(endpoint, options = {}) {
    const token = localStorage.getItem('careerconnect_token');
    const headers = {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
      ...(options.headers || {})
    };

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), API_CONFIG.TIMEOUT_MS);

    try {
      if (API_CONFIG.PREFER_MOCK) {
        throw new Error('Prefer mock mode active');
      }

      const response = await fetch(`${API_CONFIG.BASE_URL}${endpoint}`, {
        ...options,
        headers,
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: 'Request failed' }));
        throw new Error(errorData.message || `HTTP error ${response.status}`);
      }

      this.isBackendOnline = true;
      this.updateStatusPill(true);
      return await response.json();
    } catch (err) {
      clearTimeout(timeoutId);
      // Fallback silently to mock DB mode
      this.isBackendOnline = false;
      this.updateStatusPill(false);
      return null;
    }
  },

  updateStatusPill(isOnline) {
    const pills = document.querySelectorAll('.backend-status-pill');
    pills.forEach(pill => {
      if (isOnline) {
        pill.classList.remove('offline');
        pill.innerHTML = '<span class="dot"></span> Live Backend (Spring Boot)';
        pill.title = 'Connected to Spring Boot REST API at localhost:8080';
      } else {
        pill.classList.add('offline');
        pill.innerHTML = '<span class="dot"></span> Standalone Demo Mode (Active)';
        pill.title = 'Spring Boot backend is offline. Running with in-browser LocalStorage database engine.';
      }
    });
  },

  // --- Auth APIs ---
  async login(email, password, role) {
    // 1. Try real backend
    const apiRes = await this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password, role })
    });
    if (apiRes) return apiRes;

    // 2. Mock fallback
    const users = MockDB.get('users');
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());

    if (!user) {
      throw new Error('User not found with this email.');
    }
    if (user.password !== password) {
      throw new Error('Invalid password. Try "pass123" or "admin123".');
    }
    if (role && user.role !== role) {
      throw new Error(`This account is registered as ${user.role}, not ${role}.`);
    }

    const token = 'mock_jwt_token_' + btoa(JSON.stringify({ id: user.id, role: user.role }));
    let candidate = null;
    let recruiter = null;

    if (user.role === 'CANDIDATE') {
      candidate = MockDB.get('candidates').find(c => c.userId === user.id);
    } else if (user.role === 'RECRUITER') {
      recruiter = MockDB.get('recruiters').find(r => r.userId === user.id);
    }

    return {
      success: true,
      token,
      user: {
        id: user.id,
        email: user.email,
        fullName: user.fullName,
        role: user.role,
        phone: user.phone,
        avatarUrl: user.avatarUrl,
        candidateId: candidate ? candidate.id : null,
        recruiterId: recruiter ? recruiter.id : null,
        companyId: recruiter ? recruiter.companyId : null
      }
    };
  },

  async register(data) {
    const apiRes = await this.request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(data)
    });
    if (apiRes) return apiRes;

    // Check existing email
    const users = MockDB.get('users');
    if (users.find(u => u.email.toLowerCase() === data.email.toLowerCase())) {
      throw new Error('An account with this email already exists.');
    }

    const newUser = MockDB.insert('users', {
      email: data.email,
      password: data.password,
      role: data.role,
      fullName: data.fullName,
      phone: data.phone || '',
      avatarUrl: data.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      status: 'ACTIVE'
    });

    let candidateId = null;
    let recruiterId = null;
    let companyId = null;

    if (data.role === 'CANDIDATE') {
      const newCandidate = MockDB.insert('candidates', {
        userId: newUser.id,
        headline: data.headline || 'Job Seeker',
        bio: 'Welcome to my profile.',
        address: data.address || '',
        education: [],
        experience: [],
        skills: data.skills ? data.skills.split(',').map(s => s.trim()) : [],
        profileCompletion: 50
      });
      candidateId = newCandidate.id;
    } else if (data.role === 'RECRUITER') {
      // Find or create company
      let company = MockDB.get('companies').find(c => c.name.toLowerCase() === (data.companyName || '').toLowerCase());
      if (!company) {
        company = MockDB.insert('companies', {
          name: data.companyName || 'Company Inc',
          logoUrl: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=120',
          industry: data.industry || 'Technology',
          location: data.location || 'Remote',
          verified: true
        });
      }
      companyId = company.id;

      const newRecruiter = MockDB.insert('recruiters', {
        userId: newUser.id,
        companyId: company.id,
        designation: data.designation || 'Talent Recruiter',
        department: 'HR',
        contactNumber: data.phone || '',
        verified: true
      });
      recruiterId = newRecruiter.id;
    }

    const token = 'mock_jwt_token_' + btoa(JSON.stringify({ id: newUser.id, role: newUser.role }));
    return {
      success: true,
      token,
      user: {
        id: newUser.id,
        email: newUser.email,
        fullName: newUser.fullName,
        role: newUser.role,
        phone: newUser.phone,
        avatarUrl: newUser.avatarUrl,
        candidateId,
        recruiterId,
        companyId
      }
    };
  },

  // --- Jobs APIs ---
  async getJobs(filters = {}) {
    const params = new URLSearchParams();
    if (filters.search) params.append('search', filters.search);
    if (filters.location) params.append('location', filters.location);
    if (filters.jobType) params.append('jobType', filters.jobType);
    if (filters.experience) params.append('experience', filters.experience);
    if (filters.companyId) params.append('companyId', filters.companyId);

    const apiRes = await this.request(`/jobs?${params.toString()}`);
    if (apiRes) return apiRes;

    let jobs = MockDB.get('jobs');
    const companies = MockDB.get('companies');

    // Enrich jobs with company details
    let enriched = jobs.map(job => {
      const comp = companies.find(c => c.id === job.companyId) || { name: 'Tech Enterprise', logoUrl: '' };
      return {
        ...job,
        companyName: comp.name,
        companyLogo: comp.logoUrl,
        companyIndustry: comp.industry
      };
    });

    // Apply filters
    if (filters.search) {
      const q = filters.search.toLowerCase();
      enriched = enriched.filter(j => 
        j.title.toLowerCase().includes(q) || 
        j.companyName.toLowerCase().includes(q) ||
        (Array.isArray(j.skillsRequired) && j.skillsRequired.some(s => s.toLowerCase().includes(q)))
      );
    }

    if (filters.location) {
      const loc = filters.location.toLowerCase();
      enriched = enriched.filter(j => j.location.toLowerCase().includes(loc));
    }

    if (filters.jobType && filters.jobType !== 'all') {
      enriched = enriched.filter(j => j.jobType.toLowerCase() === filters.jobType.toLowerCase());
    }

    if (filters.experience && filters.experience !== 'all') {
      enriched = enriched.filter(j => j.experienceLevel.toLowerCase().includes(filters.experience.toLowerCase()));
    }

    if (filters.minSalary) {
      enriched = enriched.filter(j => j.salaryMax >= Number(filters.minSalary));
    }

    if (filters.companyId) {
      enriched = enriched.filter(j => j.companyId === Number(filters.companyId));
    }

    if (filters.recruiterId) {
      enriched = enriched.filter(j => j.recruiterId === Number(filters.recruiterId));
    }

    return enriched;
  },

  async getJobById(id) {
    const apiRes = await this.request(`/jobs/${id}`);
    if (apiRes) return apiRes;

    const job = MockDB.findById('jobs', id);
    if (!job) return null;

    const company = MockDB.findById('companies', job.companyId) || {};
    const recruiter = MockDB.findById('recruiters', job.recruiterId) || {};
    const recruiterUser = MockDB.findById('users', recruiter.userId) || {};

    return {
      ...job,
      company,
      recruiter: {
        ...recruiter,
        name: recruiterUser.fullName,
        email: recruiterUser.email
      }
    };
  },

  async postJob(jobData) {
    const apiRes = await this.request('/jobs', {
      method: 'POST',
      body: JSON.stringify(jobData)
    });
    if (apiRes) return apiRes;

    return MockDB.insert('jobs', {
      ...jobData,
      skillsRequired: Array.isArray(jobData.skillsRequired) 
        ? jobData.skillsRequired 
        : (jobData.skillsRequired || '').split(',').map(s => s.trim()).filter(Boolean),
      status: 'ACTIVE',
      viewsCount: 0,
      createdAt: new Date().toISOString()
    });
  },

  async updateJob(id, updates) {
    const apiRes = await this.request(`/jobs/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates)
    });
    if (apiRes) return apiRes;

    if (updates.skillsRequired && typeof updates.skillsRequired === 'string') {
      updates.skillsRequired = updates.skillsRequired.split(',').map(s => s.trim()).filter(Boolean);
    }
    return MockDB.update('jobs', id, updates);
  },

  async deleteJob(id) {
    const apiRes = await this.request(`/jobs/${id}`, { method: 'DELETE' });
    if (apiRes) return apiRes;

    return MockDB.delete('jobs', id);
  },

  // --- Companies APIs ---
  async getCompanies() {
    const apiRes = await this.request('/companies');
    if (apiRes) return apiRes;

    const companies = MockDB.get('companies');
    const jobs = MockDB.get('jobs');

    return companies.map(c => {
      const activeJobs = jobs.filter(j => j.companyId === c.id && j.status === 'ACTIVE').length;
      return {
        ...c,
        openPositions: activeJobs
      };
    });
  },

  // --- Applications APIs ---
  async getApplications(params = {}) {
    const apiRes = await this.request(`/applications?${new URLSearchParams(params).toString()}`);
    if (apiRes) return apiRes;

    let apps = MockDB.get('applications');
    const jobs = MockDB.get('jobs');
    const companies = MockDB.get('companies');
    const candidates = MockDB.get('candidates');
    const users = MockDB.get('users');
    const resumes = MockDB.get('resumes');

    if (params.candidateId) {
      apps = apps.filter(a => a.candidateId === Number(params.candidateId));
    }

    if (params.recruiterId) {
      const myJobs = jobs.filter(j => j.recruiterId === Number(params.recruiterId)).map(j => j.id);
      apps = apps.filter(a => myJobs.includes(a.jobId));
    }

    if (params.jobId) {
      apps = apps.filter(a => a.jobId === Number(params.jobId));
    }

    return apps.map(app => {
      const job = jobs.find(j => j.id === app.jobId) || {};
      const company = companies.find(c => c.id === job.companyId) || {};
      const candidate = candidates.find(c => c.id === app.candidateId) || {};
      const user = users.find(u => u.id === candidate.userId) || {};
      const resume = resumes.find(r => r.candidateId === candidate.id) || null;

      return {
        ...app,
        jobTitle: job.title || 'Unknown Role',
        jobLocation: job.location || '',
        jobType: job.jobType || '',
        salaryRange: `$${(job.salaryMin||0).toLocaleString()} - $${(job.salaryMax||0).toLocaleString()}`,
        companyName: company.name || 'Company',
        companyLogo: company.logoUrl || '',
        candidateName: user.fullName || 'Candidate',
        candidateEmail: user.email || '',
        candidatePhone: user.phone || '',
        candidateHeadline: candidate.headline || '',
        candidateSkills: candidate.skills || [],
        candidateEducation: candidate.education || [],
        candidateExperience: candidate.experience || [],
        resume: resume ? { fileName: resume.fileName, fileUrl: resume.fileUrl, sizeKb: resume.fileSizeKb } : null
      };
    });
  },

  async applyToJob(candidateId, jobId, coverNote) {
    const apiRes = await this.request('/applications', {
      method: 'POST',
      body: JSON.stringify({ candidateId, jobId, coverNote })
    });
    if (apiRes) return apiRes;

    // Check if already applied
    const existing = MockDB.get('applications').find(a => 
      a.candidateId === Number(candidateId) && a.jobId === Number(jobId)
    );
    if (existing) {
      throw new Error('You have already applied for this job vacancy.');
    }

    const resumes = MockDB.get('resumes').filter(r => r.candidateId === Number(candidateId));
    const resumeId = resumes.length ? resumes[0].id : null;

    const newApp = MockDB.insert('applications', {
      candidateId: Number(candidateId),
      jobId: Number(jobId),
      resumeId,
      coverNote: coverNote || 'I am excited to apply for this position.',
      status: 'Pending',
      recruiterFeedback: null,
      interviewDate: null,
      appliedAt: new Date().toISOString()
    });

    // Notify Recruiter
    const job = MockDB.findById('jobs', jobId);
    if (job) {
      const recruiter = MockDB.findById('recruiters', job.recruiterId);
      if (recruiter) {
        MockDB.insert('notifications', {
          userId: recruiter.userId,
          title: 'New Application Received',
          message: `A candidate has just applied for ${job.title}.`,
          type: 'APPLICATION_STATUS',
          isRead: false,
          linkUrl: 'recruiter-dashboard.html#applicants'
        });
      }
    }

    return newApp;
  },

  async updateApplicationStatus(appId, status, recruiterFeedback = '', interviewDate = null) {
    const apiRes = await this.request(`/applications/${appId}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status, recruiterFeedback, interviewDate })
    });
    if (apiRes) return apiRes;

    const updated = MockDB.update('applications', appId, {
      status,
      recruiterFeedback,
      interviewDate
    });

    // Notify candidate
    if (updated) {
      const candidate = MockDB.findById('candidates', updated.candidateId);
      const job = MockDB.findById('jobs', updated.jobId);
      if (candidate && job) {
        MockDB.insert('notifications', {
          userId: candidate.userId,
          title: `Application ${status}!`,
          message: `Your application for ${job.title} has been updated to "${status}".`,
          type: status === 'Interview Scheduled' ? 'INTERVIEW' : 'APPLICATION_STATUS',
          isRead: false,
          linkUrl: 'candidate-dashboard.html#applications'
        });
      }
    }

    return updated;
  },

  // --- Saved Jobs APIs ---
  async toggleSaveJob(candidateId, jobId) {
    const apiRes = await this.request(`/saved-jobs/toggle`, {
      method: 'POST',
      body: JSON.stringify({ candidateId, jobId })
    });
    if (apiRes) return apiRes;

    const saved = MockDB.get('savedJobs');
    const existing = saved.find(s => s.candidateId === Number(candidateId) && s.jobId === Number(jobId));

    if (existing) {
      MockDB.delete('savedJobs', existing.id);
      return { saved: false };
    } else {
      MockDB.insert('savedJobs', {
        candidateId: Number(candidateId),
        jobId: Number(jobId),
        savedAt: new Date().toISOString()
      });
      return { saved: true };
    }
  },

  async getSavedJobs(candidateId) {
    const saved = MockDB.get('savedJobs').filter(s => s.candidateId === Number(candidateId));
    const allJobs = await this.getJobs();
    const savedJobIds = saved.map(s => s.jobId);
    return allJobs.filter(j => savedJobIds.includes(j.id));
  },

  // --- Candidate Profile APIs ---
  async getCandidateProfile(candidateId) {
    const apiRes = await this.request(`/candidates/${candidateId}`);
    if (apiRes) return apiRes;

    const candidate = MockDB.findById('candidates', candidateId);
    if (!candidate) return null;
    const user = MockDB.findById('users', candidate.userId) || {};
    const resumes = MockDB.get('resumes').filter(r => r.candidateId === Number(candidateId));

    return {
      ...candidate,
      fullName: user.fullName,
      email: user.email,
      phone: user.phone,
      avatarUrl: user.avatarUrl,
      resumes
    };
  },

  async updateCandidateProfile(candidateId, profileData) {
    const apiRes = await this.request(`/candidates/${candidateId}`, {
      method: 'PUT',
      body: JSON.stringify(profileData)
    });
    if (apiRes) return apiRes;

    const candidate = MockDB.findById('candidates', candidateId);
    if (!candidate) return null;

    // Update user table fields if provided
    if (profileData.fullName || profileData.phone || profileData.avatarUrl) {
      MockDB.update('users', candidate.userId, {
        ...(profileData.fullName ? { fullName: profileData.fullName } : {}),
        ...(profileData.phone ? { phone: profileData.phone } : {}),
        ...(profileData.avatarUrl ? { avatarUrl: profileData.avatarUrl } : {})
      });
    }

    // Calculate dynamic completion score
    let score = 30;
    if (profileData.headline) score += 15;
    if (profileData.bio) score += 15;
    if (profileData.skills && profileData.skills.length > 0) score += 15;
    if (profileData.education && profileData.education.length > 0) score += 15;
    if (profileData.experience && profileData.experience.length > 0) score += 10;

    return MockDB.update('candidates', candidateId, {
      ...profileData,
      profileCompletion: Math.min(100, score)
    });
  },

  // --- Resume Upload ---
  async uploadResume(candidateId, file) {
    // Generate synthetic file record for demonstration
    const newResume = MockDB.insert('resumes', {
      candidateId: Number(candidateId),
      fileName: file.name || 'Resume_Document.pdf',
      fileSizeKb: Math.round((file.size || 250000) / 1024),
      fileType: file.type || 'application/pdf',
      fileUrl: '#download-resume',
      uploadedAt: new Date().toISOString().split('T')[0]
    });
    return newResume;
  },

  // --- Admin APIs ---
  async getAdminStats() {
    const apiRes = await this.request('/admin/stats');
    if (apiRes) return apiRes;

    const users = MockDB.get('users');
    const jobs = MockDB.get('jobs');
    const companies = MockDB.get('companies');
    const applications = MockDB.get('applications');

    return {
      totalCandidates: users.filter(u => u.role === 'CANDIDATE').length,
      totalRecruiters: users.filter(u => u.role === 'RECRUITER').length,
      totalCompanies: companies.length,
      totalJobs: jobs.length,
      totalApplications: applications.length,
      activeJobs: jobs.filter(j => j.status === 'ACTIVE').length
    };
  },

  async getAdminUsers() {
    const apiRes = await this.request('/admin/users');
    if (apiRes) return apiRes;

    return MockDB.get('users');
  },

  async updateUserStatus(userId, status) {
    const apiRes = await this.request(`/admin/users/${userId}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status })
    });
    if (apiRes) return apiRes;

    return MockDB.update('users', userId, { status });
  },

  // --- Notifications ---
  async getNotifications(userId) {
    const notifs = MockDB.get('notifications');
    return notifs.filter(n => n.userId === Number(userId));
  },

  async markNotificationRead(id) {
    return MockDB.update('notifications', id, { isRead: true });
  }
};

// Check backend health on startup
window.addEventListener('DOMContentLoaded', () => {
  API.request('/health').catch(() => {});
});

