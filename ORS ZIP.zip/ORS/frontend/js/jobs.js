/**
 * CareerConnect - Online Recruitment System
 * Job Search & Filtering Controller
 */

let allJobsList = [];
let currentSelectedJob = null;

document.addEventListener('DOMContentLoaded', async () => {
  parseUrlParams();
  await fetchAndDisplayJobs();
});

function parseUrlParams() {
  const params = new URLSearchParams(window.location.search);
  const search = params.get('search');
  const location = params.get('location');
  const company = params.get('company');

  if (search) document.getElementById('search-input').value = search;
  if (location) document.getElementById('location-input').value = location;
  if (company) document.getElementById('company-input').value = company;
}

async function fetchAndDisplayJobs() {
  try {
    allJobsList = await API.getJobs();
    applyFilters();
  } catch (err) {
    console.error('Failed to fetch jobs:', err);
    document.getElementById('jobs-results-container').innerHTML = `
      <p class="text-muted text-center" style="grid-column: 1/-1;">Unable to load job vacancies.</p>
    `;
  }
}

function updateSalaryLabel(val) {
  document.getElementById('salary-val').innerText = `$${Number(val).toLocaleString()}`;
}

function handleJobSearchSubmit(e) {
  e.preventDefault();
  applyFilters();
}

function resetFilters() {
  document.getElementById('search-input').value = '';
  document.getElementById('location-input').value = '';
  document.getElementById('company-input').value = '';
  document.getElementById('salary-slider').value = 0;
  updateSalaryLabel(0);
  document.getElementById('qualification-filter').value = '';

  document.querySelectorAll('input[name="jobType"]').forEach(cb => cb.checked = false);
  document.querySelectorAll('input[name="experience"]').forEach(cb => cb.checked = false);
  document.getElementById('sort-select').value = 'latest';

  applyFilters();
}

async function applyFilters() {
  const searchQ = document.getElementById('search-input').value.trim().toLowerCase();
  const locQ = document.getElementById('location-input').value.trim().toLowerCase();
  const compQ = document.getElementById('company-input').value.trim().toLowerCase();
  const minSalary = Number(document.getElementById('salary-slider').value);
  const qualQ = document.getElementById('qualification-filter').value.toLowerCase();
  const sortOption = document.getElementById('sort-select').value;

  // Selected Checkboxes
  const selectedJobTypes = Array.from(document.querySelectorAll('input[name="jobType"]:checked')).map(cb => cb.value.toLowerCase());
  const selectedExp = Array.from(document.querySelectorAll('input[name="experience"]:checked')).map(cb => cb.value.toLowerCase());

  let filtered = allJobsList.filter(job => {
    // Search keyword
    if (searchQ) {
      const titleMatch = job.title.toLowerCase().includes(searchQ);
      const compMatch = job.companyName && job.companyName.toLowerCase().includes(searchQ);
      const skillsMatch = Array.isArray(job.skillsRequired) 
        ? job.skillsRequired.some(s => s.toLowerCase().includes(searchQ))
        : (job.skillsRequired || '').toLowerCase().includes(searchQ);
      if (!titleMatch && !compMatch && !skillsMatch) return false;
    }

    // Location
    if (locQ && !job.location.toLowerCase().includes(locQ)) return false;

    // Company
    if (compQ && !job.companyName.toLowerCase().includes(compQ)) return false;

    // Job Types
    if (selectedJobTypes.length > 0) {
      if (!selectedJobTypes.includes(job.jobType.toLowerCase())) return false;
    }

    // Experience
    if (selectedExp.length > 0) {
      const hasExp = selectedExp.some(exp => job.experienceLevel.toLowerCase().includes(exp));
      if (!hasExp) return false;
    }

    // Min Salary
    if (minSalary > 0 && job.salaryMax < minSalary) return false;

    // Qualification
    if (qualQ && !job.qualification.toLowerCase().includes(qualQ)) return false;

    return true;
  });

  // Sorting
  if (sortOption === 'salary-high') {
    filtered.sort((a, b) => b.salaryMax - a.salaryMax);
  } else if (sortOption === 'salary-low') {
    filtered.sort((a, b) => a.salaryMin - b.salaryMin);
  } else {
    // Latest by ID
    filtered.sort((a, b) => b.id - a.id);
  }

  // Update UI count
  document.getElementById('jobs-count-text').innerText = `Showing ${filtered.length} Job${filtered.length === 1 ? '' : 's'} Available`;

  const container = document.getElementById('jobs-results-container');
  if (filtered.length === 0) {
    container.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 3rem 1rem; background: var(--bg-surface); border-radius: 12px; border: 1px dashed var(--border-light);">
        <i class="fa-solid fa-magnifying-glass" style="font-size: 2.5rem; color: var(--navy-muted); margin-bottom: 1rem;"></i>
        <h3 style="font-size: 1.25rem; color: var(--navy-dark); margin-bottom: 0.5rem;">No matching jobs found</h3>
        <p class="text-muted" style="margin-bottom: 1.5rem;">Try relaxing your filters or searching for different keywords.</p>
        <button class="btn btn-outline" onclick="resetFilters()">Reset All Filters</button>
      </div>
    `;
    return;
  }

  const user = Auth.getCurrentUser();
  let savedJobIds = [];
  if (user && user.candidateId) {
    const saved = await API.getSavedJobs(user.candidateId);
    savedJobIds = saved.map(s => s.id);
  }

  container.innerHTML = filtered.map(job => renderJobCard(job, savedJobIds.includes(job.id))).join('');
}

// Render Job Card
function renderJobCard(job, isSaved = false) {
  const salaryText = `$${(job.salaryMin).toLocaleString()} - $${(job.salaryMax).toLocaleString()}`;
  const skillsArray = Array.isArray(job.skillsRequired) ? job.skillsRequired : (job.skillsRequired || '').split(',');

  return `
    <div class="job-card">
      <div class="job-card-header">
        <div class="company-logo-wrap">
          <img src="${job.companyLogo || 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=120'}" alt="${job.companyName}" />
        </div>
        <button class="btn-bookmark ${isSaved ? 'bookmarked' : ''}" title="${isSaved ? 'Remove from Saved' : 'Save Job'}" onclick="handleBookmarkToggle(event, ${job.id})">
          <i class="${isSaved ? 'fa-solid' : 'fa-regular'} fa-bookmark"></i>
        </button>
      </div>

      <div class="job-card-body">
        <h3 class="job-title" onclick="openJobDetailsModal(${job.id})">${job.title}</h3>
        <div class="job-company-name">
          <i class="fa-regular fa-building"></i> ${job.companyName}
          ${job.isFeatured ? '<span class="badge badge-primary" style="margin-left: 6px; font-size: 0.7rem;">Featured</span>' : ''}
        </div>

        <div class="job-meta-row">
          <span class="job-meta-item"><i class="fa-solid fa-location-dot"></i> ${job.location}</span>
          <span class="job-meta-item"><i class="fa-regular fa-clock"></i> ${job.jobType}</span>
          <span class="job-meta-item"><i class="fa-solid fa-briefcase"></i> ${job.experienceLevel}</span>
        </div>

        <div class="job-tags-row">
          ${skillsArray.slice(0, 3).map(skill => `<span class="badge badge-neutral">${skill.trim()}</span>`).join('')}
          ${skillsArray.length > 3 ? `<span class="badge badge-neutral">+${skillsArray.length - 3}</span>` : ''}
        </div>
      </div>

      <div class="job-card-footer">
        <div class="job-salary">
          ${salaryText} <span class="period">/ yr</span>
        </div>
        <div class="flex items-center gap-2">
          <button class="btn btn-outline btn-sm" onclick="openJobDetailsModal(${job.id})">Details</button>
          <button class="btn btn-primary btn-sm" onclick="triggerApplyModal(${job.id}, '${job.title.replace(/'/g, "\\'")}')">Apply</button>
        </div>
      </div>
    </div>
  `;
}

// Modal and Application Handlers
async function openJobDetailsModal(jobId) {
  try {
    const job = await API.getJobById(jobId);
    if (!job) return;

    currentSelectedJob = job;
    document.getElementById('modal-job-title').innerText = job.title;
    const body = document.getElementById('modal-job-body');

    const salaryText = `$${(job.salaryMin).toLocaleString()} - $${(job.salaryMax).toLocaleString()} / year`;
    const skills = Array.isArray(job.skillsRequired) ? job.skillsRequired : (job.skillsRequired || '').split(',');

    body.innerHTML = `
      <div class="flex items-center gap-4 mb-6">
        <img src="${job.company ? job.company.logoUrl : ''}" style="width: 64px; height: 64px; border-radius: 12px; object-fit: cover; border: 1px solid var(--border-light);" />
        <div>
          <h3 style="font-size: 1.25rem; font-weight: 700; color: var(--navy-dark);">${job.title}</h3>
          <div style="font-size: 0.95rem; color: var(--navy-muted);">${job.company ? job.company.name : ''} • ${job.location}</div>
        </div>
      </div>

      <div class="grid grid-2 mb-6" style="background: var(--bg-alt); padding: 1rem; border-radius: 12px;">
        <div><strong>Salary:</strong> ${salaryText}</div>
        <div><strong>Job Type:</strong> ${job.jobType}</div>
        <div><strong>Experience:</strong> ${job.experienceLevel}</div>
        <div><strong>Vacancies:</strong> ${job.vacancies} open position(s)</div>
        <div><strong>Deadline:</strong> ${job.deadline}</div>
        <div><strong>Qualification:</strong> ${job.qualification}</div>
      </div>

      <h4 style="font-size: 1rem; margin-bottom: 0.5rem; color: var(--navy-dark);">Job Description</h4>
      <div style="font-size: 0.925rem; line-height: 1.7; color: var(--navy-surface); margin-bottom: 1.5rem; white-space: pre-line;">
        ${job.description}
      </div>

      <h4 style="font-size: 1rem; margin-bottom: 0.5rem; color: var(--navy-dark);">Required Skills & Technologies</h4>
      <div class="flex items-center gap-2 flex-wrap mb-4">
        ${skills.map(s => `<span class="badge badge-primary">${s.trim()}</span>`).join('')}
      </div>
    `;

    document.getElementById('job-details-modal').classList.add('active');
  } catch (e) {
    showToast('Failed to load job details', 'error');
  }
}

function closeJobModal() {
  document.getElementById('job-details-modal').classList.remove('active');
}

function openApplyModalFromDetails() {
  if (currentSelectedJob) {
    closeJobModal();
    triggerApplyModal(currentSelectedJob.id, currentSelectedJob.title);
  }
}

function triggerApplyModal(jobId, jobTitle) {
  const user = Auth.getCurrentUser();
  if (!user) {
    showToast('Please login as a Candidate to apply.', 'warning');
    setTimeout(() => {
      window.location.href = `auth.html?role=CANDIDATE&mode=login&redirect=jobs.html`;
    }, 1200);
    return;
  }

  if (user.role !== 'CANDIDATE') {
    showToast(`Current role is ${user.role}. Only Candidates can apply for jobs.`, 'warning');
    return;
  }

  document.getElementById('apply-job-id').value = jobId;
  document.getElementById('apply-modal-job-title').innerText = jobTitle;
  document.getElementById('job-apply-modal').classList.add('active');
}

function closeApplyModal() {
  document.getElementById('job-apply-modal').classList.remove('active');
}

async function handleApplySubmit(e) {
  e.preventDefault();
  const user = Auth.getCurrentUser();
  if (!user || !user.candidateId) return;

  const jobId = document.getElementById('apply-job-id').value;
  const coverNote = document.getElementById('apply-cover-note').value.trim();
  const btn = document.getElementById('btn-submit-application');

  try {
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Submitting...';

    await API.applyToJob(user.candidateId, jobId, coverNote);
    closeApplyModal();
    showToast('Application submitted successfully! Track status in Candidate Dashboard.', 'success');
  } catch (err) {
    showToast(err.message || 'Application failed to submit.', 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Submit Application';
  }
}

async function handleBookmarkToggle(e, jobId) {
  e.stopPropagation();
  const user = Auth.getCurrentUser();
  if (!user || user.role !== 'CANDIDATE') {
    showToast('Please login as a Candidate to bookmark jobs.', 'warning');
    return;
  }

  try {
    const res = await API.toggleSaveJob(user.candidateId, jobId);
    const btn = e.currentTarget;
    if (res.saved) {
      btn.classList.add('bookmarked');
      btn.innerHTML = '<i class="fa-solid fa-bookmark"></i>';
      showToast('Job added to your bookmarks!', 'success');
    } else {
      btn.classList.remove('bookmarked');
      btn.innerHTML = '<i class="fa-regular fa-bookmark"></i>';
      showToast('Job removed from bookmarks.', 'info');
    }
  } catch (err) {
    showToast('Failed to update bookmark.', 'error');
  }
}

