/**
 * CareerConnect - Online Recruitment System
 * Recruiter Dashboard Controller
 */

let recruiterCompany = null;
let recruiterJobs = [];
let recruiterApplicants = [];

document.addEventListener('DOMContentLoaded', async () => {
  // Enforce RECRUITER role
  if (!Auth.requireAuth(['RECRUITER'])) return;

  const user = Auth.getCurrentUser();
  document.getElementById('recruiter-sidebar-name').innerText = user.fullName;
  if (user.avatarUrl) {
    document.getElementById('recruiter-sidebar-avatar').src = user.avatarUrl;
  }

  // Hash Tab navigation
  const hash = window.location.hash.replace('#', '') || 'overview';
  switchRecruiterTab(hash);

  await loadRecruiterDashboardData();
});

function switchRecruiterTab(tabId) {
  const tabs = ['overview', 'post-job', 'my-jobs', 'applicants', 'company'];
  tabs.forEach(t => {
    const el = document.getElementById(`tab-recruiter-${t}`);
    if (el) el.style.display = (t === tabId) ? 'block' : 'none';
  });

  document.querySelectorAll('.sidebar-item').forEach(item => {
    item.classList.remove('active');
    if (item.getAttribute('href') === `#${tabId}`) {
      item.classList.add('active');
    }
  });

  window.location.hash = `#${tabId}`;
}

async function loadRecruiterDashboardData() {
  const user = Auth.getCurrentUser();
  if (!user || !user.recruiterId) return;

  try {
    const companies = await API.getCompanies();
    recruiterCompany = companies.find(c => c.id === user.companyId) || companies[0] || {};
    
    document.getElementById('company-greeting-title').innerText = recruiterCompany.name || 'Company Portal';
    document.getElementById('form-job-company').value = recruiterCompany.name || '';

    // Populate company edit tab
    document.getElementById('comp-name').value = recruiterCompany.name || '';
    document.getElementById('comp-industry').value = recruiterCompany.industry || '';
    document.getElementById('comp-website').value = recruiterCompany.website || '';
    document.getElementById('comp-location').value = recruiterCompany.location || '';
    document.getElementById('comp-logo').value = recruiterCompany.logoUrl || '';
    document.getElementById('comp-desc').value = recruiterCompany.description || '';

    // Load jobs & applicants
    recruiterJobs = await API.getJobs({ recruiterId: user.recruiterId });
    recruiterApplicants = await API.getApplications({ recruiterId: user.recruiterId });

    renderRecruiterMetrics();
    renderRecruiterRecentApplicants();
    renderMyJobsTable();
    renderAllApplicantsTable();
    populateJobFilterDropdown();
  } catch (err) {
    console.error('Failed to load recruiter data:', err);
    showToast('Failed to load dashboard data', 'error');
  }
}

function renderRecruiterMetrics() {
  const totalJobs = recruiterJobs.length;
  const activeJobs = recruiterJobs.filter(j => j.status === 'ACTIVE').length;
  const totalApps = recruiterApplicants.length;
  const shortlisted = recruiterApplicants.filter(a => a.status === 'Shortlisted' || a.status === 'Interview Scheduled').length;

  document.getElementById('rec-metric-total-jobs').innerText = totalJobs;
  document.getElementById('rec-metric-active-jobs').innerText = activeJobs;
  document.getElementById('rec-metric-applicants').innerText = totalApps;
  document.getElementById('rec-metric-shortlisted').innerText = shortlisted;

  document.getElementById('sidebar-job-count').innerText = totalJobs;
  document.getElementById('sidebar-applicant-count').innerText = totalApps;
}

function renderRecruiterRecentApplicants() {
  const tbody = document.getElementById('rec-recent-applicants-body');
  if (recruiterApplicants.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted" style="padding: 1.5rem;">No candidate applications received yet.</td></tr>`;
    return;
  }

  tbody.innerHTML = recruiterApplicants.slice(0, 4).map(app => renderApplicantRow(app)).join('');
}

function renderApplicantRow(app) {
  let statusClass = 'status-pending';
  if (app.status === 'Reviewed') statusClass = 'status-reviewed';
  else if (app.status === 'Shortlisted') statusClass = 'status-shortlisted';
  else if (app.status === 'Interview Scheduled') statusClass = 'status-interview';
  else if (app.status === 'Rejected') statusClass = 'status-rejected';
  else if (app.status === 'Hired') statusClass = 'status-hired';

  const skills = (app.candidateSkills || []).slice(0, 3).map(s => `<span class="badge badge-neutral" style="font-size: 0.725rem;">${s}</span>`).join(' ');

  return `
    <tr>
      <td>
        <div>
          <div style="font-weight: 700; color: var(--navy-dark); cursor: pointer;" onclick="openCandidateModal(${app.candidateId})">
            ${app.candidateName} <i class="fa-solid fa-arrow-up-right-from-square text-muted" style="font-size: 0.75rem;"></i>
          </div>
          <div style="font-size: 0.785rem; color: var(--navy-muted);">${app.candidateEmail}</div>
        </div>
      </td>
      <td>
        <div style="font-weight: 600; color: var(--navy-dark);">${app.jobTitle}</div>
        <div style="font-size: 0.775rem; color: var(--navy-muted);">${app.jobLocation || 'Remote'}</div>
      </td>
      <td>${skills || '<span class="text-muted">Not specified</span>'}</td>
      <td>${app.appliedAt ? new Date(app.appliedAt).toLocaleDateString() : 'Recent'}</td>
      <td>
        <span class="status-pill ${statusClass}">${app.status}</span>
      </td>
      <td>
        <div class="flex items-center gap-2">
          <button class="btn btn-outline btn-sm" onclick="openCandidateModal(${app.candidateId})" title="View Candidate Profile">
            <i class="fa-regular fa-user"></i> Profile
          </button>
          <button class="btn btn-primary btn-sm" onclick="openStatusModal(${app.id}, '${app.status}')" title="Change Status">
            Decision
          </button>
        </div>
      </td>
    </tr>
  `;
}

// Manage Jobs Table
function renderMyJobsTable() {
  const tbody = document.getElementById('rec-jobs-table-body');
  if (recruiterJobs.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted" style="padding: 1.5rem;">No jobs posted yet. Click "Post New Job" to begin.</td></tr>`;
    return;
  }

  tbody.innerHTML = recruiterJobs.map(job => `
    <tr>
      <td>
        <div style="font-weight: 700; color: var(--navy-dark); font-size: 0.95rem;">${job.title}</div>
        <div style="font-size: 0.8rem; color: var(--navy-muted);">${job.vacancies} vacancy(s) • ${job.viewsCount || 0} views</div>
      </td>
      <td>
        <div>${job.location}</div>
        <span class="badge badge-neutral" style="font-size: 0.725rem;">${job.jobType}</span>
      </td>
      <td>$${(job.salaryMin).toLocaleString()} - $${(job.salaryMax).toLocaleString()}</td>
      <td>${job.deadline}</td>
      <td>
        <span class="status-pill ${job.status === 'ACTIVE' ? 'status-active' : 'status-closed'}">${job.status}</span>
      </td>
      <td>
        <div class="flex items-center gap-2">
          <button class="btn btn-outline btn-sm" onclick="editJob(${job.id})" title="Edit Job">
            <i class="fa-regular fa-pen-to-square"></i>
          </button>
          <button class="btn btn-outline btn-sm" onclick="deleteJob(${job.id})" title="Delete Job" style="color: var(--danger);">
            <i class="fa-regular fa-trash-can"></i>
          </button>
        </div>
      </td>
    </tr>
  `).join('');
}

// All Applicants Table
function renderAllApplicantsTable(filterJobId = 'all') {
  const tbody = document.getElementById('rec-all-applicants-body');
  let list = recruiterApplicants;

  if (filterJobId !== 'all') {
    list = list.filter(a => a.jobId === Number(filterJobId));
  }

  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted" style="padding: 2rem;">No applicants found for this filter.</td></tr>`;
    return;
  }

  tbody.innerHTML = list.map(app => {
    let statusClass = 'status-pending';
    if (app.status === 'Reviewed') statusClass = 'status-reviewed';
    else if (app.status === 'Shortlisted') statusClass = 'status-shortlisted';
    else if (app.status === 'Interview Scheduled') statusClass = 'status-interview';
    else if (app.status === 'Rejected') statusClass = 'status-rejected';
    else if (app.status === 'Hired') statusClass = 'status-hired';

    return `
      <tr>
        <td>
          <div style="font-weight: 700; color: var(--navy-dark);">${app.candidateName}</div>
          <div style="font-size: 0.8rem; color: var(--navy-muted);">${app.candidateEmail}</div>
        </td>
        <td>
          <div style="font-weight: 600;">${app.jobTitle}</div>
        </td>
        <td>
          <div style="font-size: 0.85rem; max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
            ${app.candidateHeadline || 'Candidate'}
          </div>
          <div style="font-size: 0.75rem; color: var(--navy-muted);">
            ${(app.candidateSkills || []).slice(0, 3).join(', ')}
          </div>
        </td>
        <td>
          <span class="status-pill ${statusClass}">${app.status}</span>
        </td>
        <td>
          <button class="btn btn-outline btn-sm" onclick="downloadCandidateResume('${app.candidateName}', '${app.resume ? app.resume.fileName : 'Resume.pdf'}')">
            <i class="fa-solid fa-file-pdf" style="color: var(--danger);"></i> Resume
          </button>
        </td>
        <td>
          <div class="flex items-center gap-1">
            <button class="btn btn-success btn-sm" onclick="quickUpdateStatus(${app.id}, 'Shortlisted')" title="Quick Shortlist">
              <i class="fa-solid fa-check"></i>
            </button>
            <button class="btn btn-danger btn-sm" onclick="quickUpdateStatus(${app.id}, 'Rejected')" title="Quick Reject">
              <i class="fa-solid fa-xmark"></i>
            </button>
            <button class="btn btn-outline btn-sm" onclick="openStatusModal(${app.id}, '${app.status}')" title="More Options">
              <i class="fa-solid fa-ellipsis"></i>
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

function populateJobFilterDropdown() {
  const select = document.getElementById('applicant-job-filter');
  select.innerHTML = '<option value="all">All Job Vacancies</option>' + 
    recruiterJobs.map(j => `<option value="${j.id}">${j.title}</option>`).join('');
}

function filterApplicantsByJob() {
  const val = document.getElementById('applicant-job-filter').value;
  renderAllApplicantsTable(val);
}

// Job Form Submit (Create / Edit)
async function handleJobFormSubmit(e) {
  e.preventDefault();
  const user = Auth.getCurrentUser();
  const editId = document.getElementById('edit-job-id').value;
  const btn = document.getElementById('btn-submit-job');

  const payload = {
    recruiterId: user.recruiterId,
    companyId: user.companyId || (recruiterCompany ? recruiterCompany.id : 1),
    title: document.getElementById('form-job-title').value.trim(),
    location: document.getElementById('form-job-location').value.trim(),
    jobType: document.getElementById('form-job-type').value,
    experienceLevel: document.getElementById('form-job-experience').value,
    vacancies: Number(document.getElementById('form-job-vacancies').value),
    salaryMin: Number(document.getElementById('form-job-salary-min').value),
    salaryMax: Number(document.getElementById('form-job-salary-max').value),
    qualification: document.getElementById('form-job-qualification').value.trim(),
    deadline: document.getElementById('form-job-deadline').value,
    skillsRequired: document.getElementById('form-job-skills').value.trim(),
    description: document.getElementById('form-job-desc').value.trim()
  };

  btn.disabled = true;
  btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Saving...';

  try {
    if (editId) {
      await API.updateJob(editId, payload);
      showToast('Job vacancy updated successfully!', 'success');
    } else {
      await API.postJob(payload);
      showToast('New job vacancy published successfully!', 'success');
    }

    resetJobForm();
    await loadRecruiterDashboardData();
    switchRecruiterTab('my-jobs');
  } catch (err) {
    showToast(err.message || 'Failed to save job vacancy.', 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<i class="fa-solid fa-cloud-arrow-up"></i> Publish Job Vacancy';
  }
}

function editJob(jobId) {
  const job = recruiterJobs.find(j => j.id === jobId);
  if (!job) return;

  document.getElementById('edit-job-id').value = job.id;
  document.getElementById('form-job-title').value = job.title;
  document.getElementById('form-job-location').value = job.location;
  document.getElementById('form-job-type').value = job.jobType;
  document.getElementById('form-job-experience').value = job.experienceLevel;
  document.getElementById('form-job-vacancies').value = job.vacancies;
  document.getElementById('form-job-salary-min').value = job.salaryMin;
  document.getElementById('form-job-salary-max').value = job.salaryMax;
  document.getElementById('form-job-qualification').value = job.qualification;
  document.getElementById('form-job-deadline').value = job.deadline;
  document.getElementById('form-job-skills').value = Array.isArray(job.skillsRequired) ? job.skillsRequired.join(', ') : job.skillsRequired;
  document.getElementById('form-job-desc').value = job.description;

  document.getElementById('job-form-title').innerText = 'Edit Job Vacancy';
  document.getElementById('btn-submit-job').innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Update Job Vacancy';

  switchRecruiterTab('post-job');
}

async function deleteJob(jobId) {
  if (!confirm('Are you sure you want to delete this job vacancy? All associated applicant records will also be removed.')) return;

  try {
    await API.deleteJob(jobId);
    showToast('Job vacancy deleted.', 'info');
    await loadRecruiterDashboardData();
  } catch (err) {
    showToast('Failed to delete job', 'error');
  }
}

function resetJobForm() {
  document.getElementById('recruiter-job-form').reset();
  document.getElementById('edit-job-id').value = '';
  document.getElementById('form-job-company').value = recruiterCompany ? recruiterCompany.name : '';
  document.getElementById('job-form-title').innerText = 'Post a New Job Vacancy';
  document.getElementById('btn-submit-job').innerHTML = '<i class="fa-solid fa-cloud-arrow-up"></i> Publish Job Vacancy';
}

// Candidate Profile Modal for Recruiter
async function openCandidateModal(candidateId) {
  try {
    const profile = await API.getCandidateProfile(candidateId);
    if (!profile) return;

    document.getElementById('cand-modal-title').innerText = profile.fullName;
    const body = document.getElementById('cand-modal-body');

    const skills = (profile.skills || []).map(s => `<span class="badge badge-primary">${s}</span>`).join(' ');
    const edu = (profile.education || []).map(e => `
      <div style="margin-bottom: 0.5rem;">
        <div style="font-weight: 700;">${e.degree}</div>
        <div style="font-size: 0.85rem; color: var(--navy-muted);">${e.institution} (${e.year}) ${e.score ? '• ' + e.score : ''}</div>
      </div>
    `).join('') || '<p class="text-muted">None specified</p>';

    const exp = (profile.experience || []).map(x => `
      <div style="margin-bottom: 0.5rem;">
        <div style="font-weight: 700;">${x.title} @ ${x.company}</div>
        <div style="font-size: 0.85rem; color: var(--navy-muted);">${x.duration}</div>
        <div style="font-size: 0.85rem; margin-top: 2px;">${x.description || ''}</div>
      </div>
    `).join('') || '<p class="text-muted">None specified</p>';

    body.innerHTML = `
      <div class="flex items-center gap-4 mb-4">
        <img src="${profile.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}" style="width: 64px; height: 64px; border-radius: 50%; object-fit: cover; border: 2px solid var(--primary);" />
        <div>
          <h3 style="font-size: 1.25rem; color: var(--navy-dark);">${profile.fullName}</h3>
          <div style="font-size: 0.9rem; color: var(--primary); font-weight: 600;">${profile.headline || 'Candidate'}</div>
          <div style="font-size: 0.85rem; color: var(--navy-muted);"><i class="fa-solid fa-envelope"></i> ${profile.email} • <i class="fa-solid fa-phone"></i> ${profile.phone || 'N/A'}</div>
        </div>
      </div>

      <div class="card mb-4" style="background: var(--bg-alt);">
        <h5 style="margin-bottom: 0.35rem;">Professional Bio:</h5>
        <p style="font-size: 0.9rem; line-height: 1.6;">${profile.bio || 'No bio provided.'}</p>
      </div>

      <h5 style="margin-bottom: 0.5rem;">Technical Skills:</h5>
      <div class="flex items-center gap-2 flex-wrap mb-4">${skills}</div>

      <h5 style="margin-bottom: 0.5rem;">Work Experience:</h5>
      <div class="card mb-4" style="background: #ffffff;">${exp}</div>

      <h5 style="margin-bottom: 0.5rem;">Educational Qualifications:</h5>
      <div class="card mb-4" style="background: #ffffff;">${edu}</div>
    `;

    document.getElementById('candidate-view-modal').classList.add('active');
  } catch (err) {
    showToast('Failed to load candidate details', 'error');
  }
}

function closeCandidateModal() {
  document.getElementById('candidate-view-modal').classList.remove('active');
}

// Status Updates
function openStatusModal(appId, currentStatus) {
  document.getElementById('status-app-id').value = appId;
  document.getElementById('status-select').value = currentStatus || 'Reviewed';
  toggleInterviewDateField(currentStatus);
  document.getElementById('status-update-modal').classList.add('active');
}

function closeStatusModal() {
  document.getElementById('status-update-modal').classList.remove('active');
}

function toggleInterviewDateField(status) {
  const f = document.getElementById('interview-date-field');
  f.style.display = (status === 'Interview Scheduled') ? 'block' : 'none';
}

async function handleStatusUpdateSubmit(e) {
  e.preventDefault();
  const appId = document.getElementById('status-app-id').value;
  const status = document.getElementById('status-select').value;
  const feedback = document.getElementById('status-feedback').value.trim();
  const interviewDate = document.getElementById('status-interview-date').value || null;

  try {
    await API.updateApplicationStatus(appId, status, feedback, interviewDate);
    closeStatusModal();
    showToast(`Application marked as "${status}"!`, 'success');
    await loadRecruiterDashboardData();
  } catch (err) {
    showToast('Failed to update status', 'error');
  }
}

async function quickUpdateStatus(appId, status) {
  try {
    await API.updateApplicationStatus(appId, status, `Application moved to ${status} by hiring manager.`);
    showToast(`Candidate ${status}!`, 'success');
    await loadRecruiterDashboardData();
  } catch (err) {
    showToast('Failed to update status', 'error');
  }
}

// Download Resume
function downloadCandidateResume(candName, fileName) {
  const dummyResume = `Resume of ${candName}\nProvided for CareerConnect verified recruiter review.`;
  const blob = new Blob([dummyResume], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${candName.replace(/\s+/g, '_')}_Resume.pdf`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  showToast(`Downloaded resume for ${candName}`, 'success');
}

// Company Profile Save
async function handleSaveCompany(e) {
  e.preventDefault();
  const btn = document.getElementById('btn-save-comp');
  btn.disabled = true;

  const updates = {
    name: document.getElementById('comp-name').value.trim(),
    industry: document.getElementById('comp-industry').value.trim(),
    website: document.getElementById('comp-website').value.trim(),
    location: document.getElementById('comp-location').value.trim(),
    logoUrl: document.getElementById('comp-logo').value.trim(),
    description: document.getElementById('comp-desc').value.trim()
  };

  try {
    MockDB.update('companies', recruiterCompany.id, updates);
    recruiterCompany = { ...recruiterCompany, ...updates };
    document.getElementById('company-greeting-title').innerText = recruiterCompany.name;
    document.getElementById('form-job-company').value = recruiterCompany.name;
    showToast('Company details updated!', 'success');
  } catch (err) {
    showToast('Failed to update company', 'error');
  } finally {
    btn.disabled = false;
  }
}

