# =====================================================================
# CareerConnect Launcher (PowerShell)
# Starts Spring Boot Backend and Opens Frontend Simultaneously
# =====================================================================

$rootDir = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host "      Starting CareerConnect: Backend (Spring Boot) & Frontend       " -ForegroundColor Cyan
Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host ""

# 1. Start Backend in a new terminal window
Write-Host "[1/2] Launching Java Spring Boot Backend on http://localhost:8080..." -ForegroundColor Green
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$rootDir\backend'; .\mvnw.cmd spring-boot:run"

# Wait a brief moment
Start-Sleep -Seconds 3

# 2. Launch Frontend in default browser
Write-Host "[2/2] Launching Frontend in your default browser..." -ForegroundColor Green
Start-Process "$rootDir\frontend\index.html"

Write-Host ""
Write-Host "=====================================================================" -ForegroundColor Yellow
Write-Host " Both Backend & Frontend are now running!" -ForegroundColor Yellow
Write-Host " - Backend API:    http://localhost:8080/api" -ForegroundColor White
Write-Host " - Health Check:   http://localhost:8080/api/health" -ForegroundColor White
Write-Host " - H2 Console:     http://localhost:8080/h2-console" -ForegroundColor White
Write-Host " - Frontend:       Opened in default browser" -ForegroundColor White
Write-Host "=====================================================================" -ForegroundColor Yellow

