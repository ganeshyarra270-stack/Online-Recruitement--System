@echo off
title CareerConnect - Online Recruitment System Launcher
color 0B

echo =====================================================================
echo       Starting CareerConnect: Backend (Spring Boot) & Frontend       
echo =====================================================================
echo.

:: Get current folder path
set ROOT_DIR=%~dp0

:: Step 1: Launch Spring Boot Backend in a separate window
echo [1/2] Launching Java Spring Boot Backend (Port 8080)...
start "CareerConnect - Spring Boot Backend (Port 8080)" cmd /k "cd /d "%ROOT_DIR%backend" && mvnw.cmd spring-boot:run"

:: Wait 3 seconds for backend to start up
echo.
echo [2/2] Launching Frontend in your default browser...
timeout /t 3 /nobreak >nul

:: Step 2: Open Frontend index.html in the default web browser
start "" "%ROOT_DIR%frontend\index.html"

echo.
echo =====================================================================
echo  Both Backend and Frontend are launching!
echo  - Backend REST API:  http://localhost:8080/api
echo  - Backend Health:    http://localhost:8080/api/health
echo  - H2 Database:       http://localhost:8080/h2-console
echo  - Frontend App:      Opened in your web browser
echo =====================================================================
echo.
pause

