package com.careerconnect.recruitment.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JobDto {
    private Long id;
    private Long recruiterId;
    private Long companyId;
    private String companyName;
    private String companyLogo;
    private String title;
    private String description;
    private List<String> skillsRequired;
    private String qualification;
    private String experienceLevel;
    private BigDecimal salaryMin;
    private BigDecimal salaryMax;
    private String location;
    private String jobType;
    private Integer vacancies;
    private LocalDate deadline;
    private String status;
    private Boolean isFeatured;
    private Integer viewsCount;
}
