package com.careerconnect.recruitment.service;

import com.careerconnect.recruitment.dto.JobDto;
import com.careerconnect.recruitment.model.Company;
import com.careerconnect.recruitment.model.Job;
import com.careerconnect.recruitment.model.Recruiter;
import com.careerconnect.recruitment.repository.CompanyRepository;
import com.careerconnect.recruitment.repository.JobRepository;
import com.careerconnect.recruitment.repository.RecruiterRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class JobService {

    private final JobRepository jobRepository;
    private final RecruiterRepository recruiterRepository;
    private final CompanyRepository companyRepository;

    public List<JobDto> getAllJobs(String search, String location, String jobType, Long recruiterId, Long companyId) {
        List<Job> jobs;
        if (recruiterId != null) {
            jobs = jobRepository.findByRecruiterId(recruiterId);
        } else if (companyId != null) {
            jobs = jobRepository.findByCompanyId(companyId);
        } else if (search != null || location != null || jobType != null) {
            jobs = jobRepository.searchJobs(search, location, jobType, "ACTIVE");
        } else {
            jobs = jobRepository.findAll();
        }

        return jobs.stream().map(this::mapToDto).collect(Collectors.toList());
    }

    public JobDto getJobById(Long id) {
        Job job = jobRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Job not found with id: " + id));
        job.setViewsCount(job.getViewsCount() + 1);
        jobRepository.save(job);
        return mapToDto(job);
    }

    @Transactional
    public JobDto createJob(JobDto dto) {
        Recruiter recruiter = recruiterRepository.findById(dto.getRecruiterId())
                .orElseThrow(() -> new RuntimeException("Recruiter not found with id: " + dto.getRecruiterId()));
        Company company = recruiter.getCompany();

        Job job = Job.builder()
                .recruiter(recruiter)
                .company(company)
                .title(dto.getTitle())
                .description(dto.getDescription())
                .skillsRequired(String.join(", ", dto.getSkillsRequired()))
                .qualification(dto.getQualification())
                .experienceLevel(dto.getExperienceLevel())
                .salaryMin(dto.getSalaryMin())
                .salaryMax(dto.getSalaryMax())
                .location(dto.getLocation())
                .jobType(dto.getJobType())
                .vacancies(dto.getVacancies() != null ? dto.getVacancies() : 1)
                .deadline(dto.getDeadline())
                .status("ACTIVE")
                .isFeatured(false)
                .viewsCount(0)
                .build();

        job = jobRepository.save(job);
        return mapToDto(job);
    }

    @Transactional
    public JobDto updateJob(Long id, JobDto dto) {
        Job job = jobRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Job not found with id: " + id));

        if (dto.getTitle() != null) job.setTitle(dto.getTitle());
        if (dto.getDescription() != null) job.setDescription(dto.getDescription());
        if (dto.getSkillsRequired() != null) job.setSkillsRequired(String.join(", ", dto.getSkillsRequired()));
        if (dto.getQualification() != null) job.setQualification(dto.getQualification());
        if (dto.getExperienceLevel() != null) job.setExperienceLevel(dto.getExperienceLevel());
        if (dto.getSalaryMin() != null) job.setSalaryMin(dto.getSalaryMin());
        if (dto.getSalaryMax() != null) job.setSalaryMax(dto.getSalaryMax());
        if (dto.getLocation() != null) job.setLocation(dto.getLocation());
        if (dto.getJobType() != null) job.setJobType(dto.getJobType());
        if (dto.getVacancies() != null) job.setVacancies(dto.getVacancies());
        if (dto.getDeadline() != null) job.setDeadline(dto.getDeadline());
        if (dto.getStatus() != null) job.setStatus(dto.getStatus());

        return mapToDto(jobRepository.save(job));
    }

    @Transactional
    public void deleteJob(Long id) {
        jobRepository.deleteById(id);
    }

    private JobDto mapToDto(Job job) {
        List<String> skills = Arrays.stream(job.getSkillsRequired().split(","))
                .map(String::trim)
                .collect(Collectors.toList());

        return JobDto.builder()
                .id(job.getId())
                .recruiterId(job.getRecruiter().getId())
                .companyId(job.getCompany().getId())
                .companyName(job.getCompany().getName())
                .companyLogo(job.getCompany().getLogoUrl())
                .title(job.getTitle())
                .description(job.getDescription())
                .skillsRequired(skills)
                .qualification(job.getQualification())
                .experienceLevel(job.getExperienceLevel())
                .salaryMin(job.getSalaryMin())
                .salaryMax(job.getSalaryMax())
                .location(job.getLocation())
                .jobType(job.getJobType())
                .vacancies(job.getVacancies())
                .deadline(job.getDeadline())
                .status(job.getStatus())
                .isFeatured(job.getIsFeatured())
                .viewsCount(job.getViewsCount())
                .build();
    }
}

