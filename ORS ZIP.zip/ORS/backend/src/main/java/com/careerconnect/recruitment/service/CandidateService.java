package com.careerconnect.recruitment.service;

import com.careerconnect.recruitment.model.Candidate;
import com.careerconnect.recruitment.model.Resume;
import com.careerconnect.recruitment.model.User;
import com.careerconnect.recruitment.repository.CandidateRepository;
import com.careerconnect.recruitment.repository.ResumeRepository;
import com.careerconnect.recruitment.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class CandidateService {

    private final CandidateRepository candidateRepository;
    private final UserRepository userRepository;
    private final ResumeRepository resumeRepository;

    public Map<String, Object> getProfile(Long candidateId) {
        Candidate candidate = candidateRepository.findById(candidateId)
                .orElseThrow(() -> new RuntimeException("Candidate not found: " + candidateId));
        User user = candidate.getUser();
        List<Resume> resumes = resumeRepository.findByCandidateId(candidateId);

        Map<String, Object> map = new HashMap<>();
        map.put("id", candidate.getId());
        map.put("userId", user.getId());
        map.put("fullName", user.getFullName());
        map.put("email", user.getEmail());
        map.put("phone", user.getPhone());
        map.put("avatarUrl", user.getAvatarUrl());
        map.put("headline", candidate.getHeadline());
        map.put("bio", candidate.getBio());
        map.put("address", candidate.getAddress());
        map.put("educationJson", candidate.getEducationJson());
        map.put("experienceJson", candidate.getExperienceJson());
        map.put("skillsJson", candidate.getSkillsJson());
        map.put("profileCompletion", candidate.getProfileCompletion());
        map.put("resumes", resumes);
        return map;
    }

    @Transactional
    public Candidate updateProfile(Long candidateId, Map<String, Object> updates) {
        Candidate candidate = candidateRepository.findById(candidateId)
                .orElseThrow(() -> new RuntimeException("Candidate not found: " + candidateId));

        User user = candidate.getUser();
        if (updates.containsKey("fullName")) user.setFullName((String) updates.get("fullName"));
        if (updates.containsKey("phone")) user.setPhone((String) updates.get("phone"));
        userRepository.save(user);

        if (updates.containsKey("headline")) candidate.setHeadline((String) updates.get("headline"));
        if (updates.containsKey("bio")) candidate.setBio((String) updates.get("bio"));
        if (updates.containsKey("address")) candidate.setAddress((String) updates.get("address"));
        if (updates.containsKey("educationJson")) candidate.setEducationJson((String) updates.get("educationJson"));
        if (updates.containsKey("experienceJson")) candidate.setExperienceJson((String) updates.get("experienceJson"));
        if (updates.containsKey("skillsJson")) candidate.setSkillsJson((String) updates.get("skillsJson"));
        if (updates.containsKey("profileCompletion")) candidate.setProfileCompletion((Integer) updates.get("profileCompletion"));

        return candidateRepository.save(candidate);
    }
}

