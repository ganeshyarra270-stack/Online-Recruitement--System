package com.careerconnect.recruitment.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationDto {
    private Long id;
    private Long jobId;
    private String jobTitle;
    private String jobLocation;
    private String jobType;
    private String salaryRange;
    private String companyName;
    private String companyLogo;
    private Long candidateId;
    private String candidateName;
    private String candidateEmail;
    private String candidatePhone;
    private String candidateHeadline;
    private String coverNote;
    private String status;
    private String recruiterFeedback;
    private LocalDateTime interviewDate;
    private LocalDateTime appliedAt;
    private String resumeFileName;
    private String resumeUrl;
}
