package com.careerconnect.recruitment.repository;

import com.careerconnect.recruitment.model.JobApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ApplicationRepository extends JpaRepository<JobApplication, Long> {
    List<JobApplication> findByCandidateId(Long candidateId);
    List<JobApplication> findByJobId(Long jobId);
    Optional<JobApplication> findByCandidateIdAndJobId(Long candidateId, Long jobId);
    Boolean existsByCandidateIdAndJobId(Long candidateId, Long jobId);
}

