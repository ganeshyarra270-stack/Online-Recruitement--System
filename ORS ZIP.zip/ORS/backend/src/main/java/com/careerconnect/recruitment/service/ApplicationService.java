package com.careerconnect.recruitment.service;

import com.careerconnect.recruitment.dto.ApplicationDto;
import com.careerconnect.recruitment.model.*;
import com.careerconnect.recruitment.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ApplicationService {

    private final ApplicationRepository applicationRepository;
    private final CandidateRepository candidateRepository;
    private final JobRepository jobRepository;
    private final ResumeRepository resumeRepository;
    private final NotificationRepository notificationRepository;

    public List<ApplicationDto> getApplications(Long candidateId, Long recruiterId, Long jobId) {
        List<JobApplication> apps;
        if (candidateId != null) {
            apps = applicationRepository.findByCandidateId(candidateId);
        } else if (jobId != null) {
            apps = applicationRepository.findByJobId(jobId);
        } else if (recruiterId != null) {
            List<Long> jobIds = jobRepository.findByRecruiterId(recruiterId).stream().map(Job::getId).toList();
            apps = applicationRepository.findAll().stream().filter(a -> jobIds.contains(a.getJob().getId())).toList();
        } else {
            apps = applicationRepository.findAll();
        }

        return apps.stream().map(this::mapToDto).collect(Collectors.toList());
    }

    @Transactional
    public ApplicationDto apply(Long candidateId, Long jobId, String coverNote) {
        if (applicationRepository.existsByCandidateIdAndJobId(candidateId, jobId)) {
            throw new RuntimeException("Candidate has already submitted an application for this vacancy.");
        }

        Candidate candidate = candidateRepository.findById(candidateId)
                .orElseThrow(() -> new RuntimeException("Candidate not found: " + candidateId));
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new RuntimeException("Job not found: " + jobId));

        List<Resume> resumes = resumeRepository.findByCandidateId(candidateId);
        Resume resume = resumes.isEmpty() ? null : resumes.get(0);

        JobApplication app = JobApplication.builder()
                .candidate(candidate)
                .job(job)
                .resume(resume)
                .coverNote(coverNote)
                .status("Pending")
                .build();

        app = applicationRepository.save(app);

        // Notify Recruiter
        notificationRepository.save(Notification.builder()
                .user(job.getRecruiter().getUser())
                .title("New Candidate Application")
                .message(candidate.getUser().getFullName() + " applied for " + job.getTitle())
                .type("APPLICATION_STATUS")
                .linkUrl("recruiter-dashboard.html#applicants")
                .isRead(false)
                .build());

        return mapToDto(app);
    }

    @Transactional
    public ApplicationDto updateStatus(Long appId, String status, String feedback, LocalDateTime interviewDate) {
        JobApplication app = applicationRepository.findById(appId)
                .orElseThrow(() -> new RuntimeException("Application not found: " + appId));

        app.setStatus(status);
        if (feedback != null) app.setRecruiterFeedback(feedback);
        if (interviewDate != null) app.setInterviewDate(interviewDate);

        app = applicationRepository.save(app);

        // Notify Candidate
        notificationRepository.save(Notification.builder()
                .user(app.getCandidate().getUser())
                .title("Application " + status + "!")
                .message("Your application for " + app.getJob().getTitle() + " has been updated to: " + status)
                .type(status.equalsIgnoreCase("Interview Scheduled") ? "INTERVIEW" : "APPLICATION_STATUS")
                .linkUrl("candidate-dashboard.html#applications")
                .isRead(false)
                .build());

        return mapToDto(app);
    }

    private ApplicationDto mapToDto(JobApplication app) {
        Job job = app.getJob();
        Candidate cand = app.getCandidate();
        User user = cand.getUser();
        Resume res = app.getResume();

        return ApplicationDto.builder()
                .id(app.getId())
                .jobId(job.getId())
                .jobTitle(job.getTitle())
                .jobLocation(job.getLocation())
                .jobType(job.getJobType())
                .salaryRange("$" + job.getSalaryMin() + " - $" + job.getSalaryMax())
                .companyName(job.getCompany().getName())
                .companyLogo(job.getCompany().getLogoUrl())
                .candidateId(cand.getId())
                .candidateName(user.getFullName())
                .candidateEmail(user.getEmail())
                .candidatePhone(user.getPhone())
                .candidateHeadline(cand.getHeadline())
                .coverNote(app.getCoverNote())
                .status(app.getStatus())
                .recruiterFeedback(app.getRecruiterFeedback())
                .interviewDate(app.getInterviewDate())
                .appliedAt(app.getAppliedAt())
                .resumeFileName(res != null ? res.getFileName() : null)
                .resumeUrl(res != null ? res.getFileUrl() : null)
                .build();
    }
}

