package com.careerconnect.recruitment.config;

import com.careerconnect.recruitment.model.*;
import com.careerconnect.recruitment.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final CompanyRepository companyRepository;
    private final CandidateRepository candidateRepository;
    private final RecruiterRepository recruiterRepository;
    private final JobRepository jobRepository;
    private final ApplicationRepository applicationRepository;
    private final ResumeRepository resumeRepository;
    private final SavedJobRepository savedJobRepository;
    private final NotificationRepository notificationRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (userRepository.count() > 0) {
            return; // Data already exists
        }

        System.out.println(">>> Initializing default demo data for CareerConnect platform...");

        String encodedPass = passwordEncoder.encode("pass123");
        String encodedAdminPass = passwordEncoder.encode("admin123");

        // 1. Users
        User adminUser = userRepository.save(User.builder()
                .email("admin@careerconnect.com")
                .passwordHash(encodedAdminPass)
                .role(Role.ADMIN)
                .fullName("Master Admin")
                .phone("+1 (555) 019-2834")
                .avatarUrl("https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150")
                .status("ACTIVE")
                .build());

        User recUser1 = userRepository.save(User.builder()
                .email("recruiter@techcorp.com")
                .passwordHash(encodedPass)
                .role(Role.RECRUITER)
                .fullName("Marcus Vance")
                .phone("+1 (555) 432-8765")
                .avatarUrl("https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150")
                .status("ACTIVE")
                .build());

        User candUser1 = userRepository.save(User.builder()
                .email("candidate@careerconnect.com")
                .passwordHash(encodedPass)
                .role(Role.CANDIDATE)
                .fullName("Alex Morgan")
                .phone("+1 (555) 234-5678")
                .avatarUrl("https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150")
                .status("ACTIVE")
                .build());

        User candUser2 = userRepository.save(User.builder()
                .email("priya.sharma@example.com")
                .passwordHash(encodedPass)
                .role(Role.CANDIDATE)
                .fullName("Priya Sharma")
                .phone("+91 98112 34567")
                .avatarUrl("https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150")
                .status("ACTIVE")
                .build());

        // 2. Companies
        Company techCorp = companyRepository.save(Company.builder()
                .name("TechCorp Global")
                .logoUrl("https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120")
                .website("https://techcorp-example.com")
                .industry("Information Technology")
                .description("Leading enterprise cloud software provider.")
                .location("Bangalore, India & San Francisco, USA")
                .foundedYear(2012)
                .employeeCount("1000-5000")
                .verified(true)
                .build());

        Company innovaTech = companyRepository.save(Company.builder()
                .name("InnovaTech Labs")
                .logoUrl("https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=120")
                .website("https://innovatech-example.io")
                .industry("Artificial Intelligence")
                .description("Pioneering generative automation and enterprise AI.")
                .location("Hyderabad, India & New York, USA")
                .foundedYear(2018)
                .employeeCount("200-500")
                .verified(true)
                .build());

        // 3. Recruiter Affiliation
        Recruiter recruiter1 = recruiterRepository.save(Recruiter.builder()
                .user(recUser1)
                .company(techCorp)
                .designation("Senior Technical Recruiter")
                .department("Talent Acquisition")
                .contactNumber("+1 (555) 432-8765")
                .verified(true)
                .build());

        // 4. Candidate Profiles
        Candidate candidate1 = candidateRepository.save(Candidate.builder()
                .user(candUser1)
                .headline("Senior Full Stack Java & Cloud Engineer")
                .bio("Passionate software engineer with 4+ years building scalable microservices.")
                .address("Seattle, WA / Remote")
                .educationJson("[{\"degree\":\"B.Tech in Computer Science\",\"institution\":\"National Institute of Technology\",\"year\":\"2021\",\"score\":\"8.9 CGPA\"}]")
                .experienceJson("[{\"title\":\"Full Stack Developer\",\"company\":\"CloudVertex\",\"duration\":\"2022 - Present\",\"description\":\"Built microservices using Spring Boot & Redis.\"}]")
                .skillsJson("[\"Java\", \"Spring Boot\", \"MySQL\", \"React\", \"AWS\", \"Docker\"]")
                .profileCompletion(90)
                .build());

        Candidate candidate2 = candidateRepository.save(Candidate.builder()
                .user(candUser2)
                .headline("Frontend Specialist & UI/UX Developer")
                .bio("Dedicated to building performant web applications using React and TypeScript.")
                .address("Bengaluru, Karnataka, India")
                .skillsJson("[\"React\", \"JavaScript\", \"TypeScript\", \"Tailwind CSS\"]")
                .profileCompletion(85)
                .build());

        // 5. PDF Resumes
        Resume resume1 = resumeRepository.save(Resume.builder()
                .candidate(candidate1)
                .fileName("Alex_Morgan_FullStack_Resume.pdf")
                .fileSizeKb(380)
                .fileType("application/pdf")
                .fileUrl("#download-resume")
                .isDefault(true)
                .build());

        // 6. Job Postings
        Job job1 = jobRepository.save(Job.builder()
                .recruiter(recruiter1)
                .company(techCorp)
                .title("Senior Full Stack Java Engineer")
                .description("Design robust, secure RESTful APIs using Java 17+, Spring Boot, and React.")
                .skillsRequired("Java, Spring Boot, React, MySQL, Hibernate, AWS, Docker")
                .qualification("Bachelor or Master degree in Computer Science")
                .experienceLevel("Senior (3-5 yrs)")
                .salaryMin(new BigDecimal("120000.00"))
                .salaryMax(new BigDecimal("160000.00"))
                .location("Bangalore, India (Hybrid)")
                .jobType("Hybrid")
                .vacancies(3)
                .deadline(LocalDate.now().plusMonths(2))
                .status("ACTIVE")
                .isFeatured(true)
                .viewsCount(428)
                .build());

        Job job2 = jobRepository.save(Job.builder()
                .recruiter(recruiter1)
                .company(techCorp)
                .title("Cloud DevOps Architect")
                .description("Manage multi-region Kubernetes clusters on AWS EKS and write maintainable IaC.")
                .skillsRequired("AWS, Kubernetes, Docker, Terraform, CI/CD, Linux")
                .qualification("B.Tech / B.E. in Computer Science or IT")
                .experienceLevel("Lead / Principal (5+ yrs)")
                .salaryMin(new BigDecimal("140000.00"))
                .salaryMax(new BigDecimal("190000.00"))
                .location("Remote / Global")
                .jobType("Remote")
                .vacancies(2)
                .deadline(LocalDate.now().plusMonths(1))
                .status("ACTIVE")
                .isFeatured(true)
                .viewsCount(310)
                .build());

        // 7. Applications
        applicationRepository.save(JobApplication.builder()
                .job(job1)
                .candidate(candidate1)
                .resume(resume1)
                .coverNote("I have over 4 years experience with Spring Boot and React.")
                .status("Shortlisted")
                .recruiterFeedback("Strong technical background. Scheduled for technical interview.")
                .interviewDate(LocalDateTime.now().plusDays(7))
                .build());

        applicationRepository.save(JobApplication.builder()
                .job(job2)
                .candidate(candidate1)
                .resume(resume1)
                .coverNote("Passionate about Kubernetes and cloud resilience.")
                .status("Pending")
                .build());

        // 8. Saved Jobs
        savedJobRepository.save(SavedJob.builder()
                .candidate(candidate1)
                .job(job2)
                .build());

        // 9. Notifications
        notificationRepository.save(Notification.builder()
                .user(candUser1)
                .title("Application Shortlisted!")
                .message("TechCorp Global has shortlisted your application for Senior Full Stack Java Engineer.")
                .type("APPLICATION_STATUS")
                .linkUrl("candidate-dashboard.html#applications")
                .isRead(false)
                .build());

        System.out.println(">>> Demo data successfully seeded into database!");
    }
}

