package com.careerconnect.recruitment.controller;

import com.careerconnect.recruitment.dto.ApplicationDto;
import com.careerconnect.recruitment.service.ApplicationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/applications")
@RequiredArgsConstructor
public class ApplicationController {

    private final ApplicationService applicationService;

    @GetMapping
    public ResponseEntity<List<ApplicationDto>> getApplications(
            @RequestParam(required = false) Long candidateId,
            @RequestParam(required = false) Long recruiterId,
            @RequestParam(required = false) Long jobId) {
        return ResponseEntity.ok(applicationService.getApplications(candidateId, recruiterId, jobId));
    }

    @PostMapping
    public ResponseEntity<ApplicationDto> apply(@RequestBody Map<String, Object> body) {
        Long candidateId = Long.valueOf(body.get("candidateId").toString());
        Long jobId = Long.valueOf(body.get("jobId").toString());
        String coverNote = (String) body.get("coverNote");
        return ResponseEntity.ok(applicationService.apply(candidateId, jobId, coverNote));
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<ApplicationDto> updateStatus(
            @PathVariable Long id, 
            @RequestBody Map<String, Object> body) {
        String status = (String) body.get("status");
        String feedback = (String) body.get("recruiterFeedback");
        String interviewStr = (String) body.get("interviewDate");
        LocalDateTime interviewDate = interviewStr != null ? LocalDateTime.parse(interviewStr) : null;
        return ResponseEntity.ok(applicationService.updateStatus(id, status, feedback, interviewDate));
    }
}

