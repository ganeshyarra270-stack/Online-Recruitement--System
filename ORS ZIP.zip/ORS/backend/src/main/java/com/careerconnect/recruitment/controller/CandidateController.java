package com.careerconnect.recruitment.controller;

import com.careerconnect.recruitment.model.Candidate;
import com.careerconnect.recruitment.service.CandidateService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/candidates")
@RequiredArgsConstructor
public class CandidateController {

    private final CandidateService candidateService;

    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> getProfile(@PathVariable Long id) {
        return ResponseEntity.ok(candidateService.getProfile(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Candidate> updateProfile(
            @PathVariable Long id, 
            @RequestBody Map<String, Object> updates) {
        return ResponseEntity.ok(candidateService.updateProfile(id, updates));
    }
}

