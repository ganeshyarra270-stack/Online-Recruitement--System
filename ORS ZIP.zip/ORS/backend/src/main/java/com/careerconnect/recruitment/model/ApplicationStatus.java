package com.careerconnect.recruitment.model;

public enum ApplicationStatus {
    Pending,
    Reviewed,
    Shortlisted,
    Interview_Scheduled,
    Rejected,
    Hired
}

