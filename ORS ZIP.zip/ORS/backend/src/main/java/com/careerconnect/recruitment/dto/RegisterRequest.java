package com.careerconnect.recruitment.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegisterRequest {
    private String email;
    private String password;
    private String role;
    private String fullName;
    private String phone;
    private String avatarUrl;

    // Recruiter-specific fields
    private String companyName;
    private String industry;
    private String designation;

    // Candidate-specific fields
    private String headline;
    private String skills;
    private String address;
}
