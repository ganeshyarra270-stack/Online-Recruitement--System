package com.careerconnect.recruitment.model;

public enum Role {
    CANDIDATE,
    RECRUITER,
    ADMIN
}

