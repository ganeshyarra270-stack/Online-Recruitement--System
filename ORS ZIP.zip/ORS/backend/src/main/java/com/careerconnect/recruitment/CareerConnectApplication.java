package com.careerconnect.recruitment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CareerConnectApplication {

    public static void main(String[] args) {
        SpringApplication.run(CareerConnectApplication.class, args);
        System.out.println("=============================================================");
        System.out.println("  CareerConnect - Online Recruitment System Backend Started  ");
        System.out.println("  REST APIs available at: http://localhost:8080/api          ");
        System.out.println("=============================================================");
    }
}

