package com.careerconnect.recruitment.service;

import com.careerconnect.recruitment.dto.StatsDto;
import com.careerconnect.recruitment.model.Role;
import com.careerconnect.recruitment.model.User;
import com.careerconnect.recruitment.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AdminService {

    private final UserRepository userRepository;
    private final CompanyRepository companyRepository;
    private final JobRepository jobRepository;
    private final ApplicationRepository applicationRepository;

    public StatsDto getPlatformStats() {
        long candidates = userRepository.findByRole(Role.CANDIDATE).size();
        long recruiters = userRepository.findByRole(Role.RECRUITER).size();
        long companies = companyRepository.count();
        long jobs = jobRepository.count();
        long apps = applicationRepository.count();
        long activeJobs = jobRepository.findByStatus("ACTIVE").size();

        return StatsDto.builder()
                .totalCandidates(candidates)
                .totalRecruiters(recruiters)
                .totalCompanies(companies)
                .totalJobs(jobs)
                .totalApplications(apps)
                .activeJobs(activeJobs)
                .build();
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Transactional
    public User updateUserStatus(Long userId, String status) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));
        user.setStatus(status);
        return userRepository.save(user);
    }
}

