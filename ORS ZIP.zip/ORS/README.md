# CareerConnect – Online Recruitment System

A modern, responsive, and professional full-stack web application connecting job seekers, corporate recruiters, and administrators. Built with a **Java Spring Boot** backend, **MySQL** database, clean **REST APIs**, and an **ultra-sleek frontend** styled in a premium White and Dark Navy Blue theme.

---

## 🌟 Key Highlights

- **Complete 3-Role Ecosystem**: Dedicated workflows for **Candidates**, **Recruiters**, and **Super Admins**.
- **Instant Out-of-the-Box Demo**: Features an intelligent dual-mode architecture. You can run the application immediately in standalone demo mode directly in any browser (no server or database installation required), or run it connected to the live **Java Spring Boot** and **MySQL** backend!
- **State Machine Application Tracker**: Visual status stepper showing real-time candidate progression (`Applied` → `Reviewed` → `Shortlisted` → `Interview Scheduled` → `Hired` or `Rejected`).
- **PDF Resume Management**: Drag-and-drop PDF resume upload, file size validation, preview, and recruiter download.
- **Dynamic Job Filtering**: Filter by job title, location, company, experience level, salary range, qualification, and job types.
- **Enterprise Security**: Role-Based Access Control (RBAC), BCrypt password hashing, and JWT authorization tokens.
- **10-Table Relational Database**: Production-ready MySQL schema with foreign keys, cascading constraints, unique indexes to prevent duplicate applications, and comprehensive sample data.

---

## 🛠️ Technology Stack

| Layer | Technologies Used |
|:---|:---|
| **Frontend** | HTML5, Modern CSS3 (CSS Variables, Flexbox, Grid), Modular JavaScript (ES6+), FontAwesome 6.5, Google Fonts (Plus Jakarta Sans, Inter) |
| **Backend** | Java 17+, Spring Boot 3.2.x, Spring Data JPA, Spring Security, Hibernate ORM, JJWT, Lombok |
| **Database** | MySQL 8.0+ (`online_recruitment`), Relational Schema with Foreign Keys & Constraints |
| **API** | RESTful JSON API with CORS support |
| **Architecture** | Model-View-Controller (MVC) + Service Repository Pattern |

---

## 🚀 Quick Start: Running the Project

### Option 1: Instant Standalone / Demo Mode (Recommended for Quick Review)
The frontend has a built-in client-side database persistence engine (`MockDB` in `localStorage`). You can test **100% of all features, logins, job postings, filters, resume uploads, and application tracking** immediately without installing Java or MySQL!

1. Open folder `frontend/` in your file explorer.
2. Double-click `index.html` to open it in Chrome, Edge, Firefox, or Safari.
3. *(Alternative)* If you have Python or VS Code Live Server:
   ```bash
   cd frontend
   python -m http.server 3000
   ```
   Open `http://localhost:3000` in your browser.

#### ⚡ 1-Click Demo Credentials
On `auth.html`, click any of the **Quick Demo Login** buttons:

| Role | Email | Password | Pre-configured Data |
|:---|:---|:---|:---|
| **Candidate** | `candidate@careerconnect.com` | `pass123` | Alex Morgan (4 applications, uploaded PDF resume, bookmarks) |
| **Recruiter** | `recruiter@techcorp.com` | `pass123` | Marcus Vance @ TechCorp Global (Posted jobs, candidate pipeline) |
| **Admin** | `admin@careerconnect.com` | `admin123` | Master Admin (Full moderation, user accounts, platform metrics) |

---

### Option 2: Full-Stack Mode (Spring Boot + MySQL)

#### Step 1: Configure the MySQL Database
1. Open MySQL Command Line or MySQL Workbench:
   ```sql
   CREATE DATABASE online_recruitment;
   ```
2. Import the schema and initial seed data:
   ```bash
   mysql -u root -p online_recruitment < database/schema.sql
   mysql -u root -p online_recruitment < database/data.sql
   ```

#### Step 2: Configure Backend Connection
Open `backend/src/main/resources/application.properties` and verify your MySQL credentials:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/online_recruitment?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
spring.datasource.username=root
spring.datasource.password=your_mysql_password
```

#### Step 3: Run Spring Boot Backend
Navigate to `backend/` and run using Maven:
```bash
cd backend
mvn clean spring-boot:run
```
The backend starts at `http://localhost:8080`.  
Verify backend health: `http://localhost:8080/api/health`

#### Step 4: Open the Frontend
Open `frontend/index.html`. The indicator pill in the navbar will automatically detect the backend and turn green:
> **● Live Backend (Spring Boot)**

---

## 📁 Project Folder Structure

```
ORS/
│
├── frontend/                        # Responsive Web Frontend
│   ├── index.html                   # Landing page (Hero, stats, featured jobs, top companies)
│   ├── jobs.html                    # Advanced job search & multi-filter engine
│   ├── companies.html               # Corporate directory & verified employer profiles
│   ├── about.html                   # About Us, mission, values
│   ├── contact.html                 # Contact support form & FAQs
│   ├── privacy.html                 # Privacy policy & terms of service
│   ├── auth.html                    # Unified login / registration / forgot password
│   ├── candidate-dashboard.html     # Candidate portal (Stats, profile, resume, tracker)
│   ├── recruiter-dashboard.html     # Recruiter portal (Job postings, applicant pipeline)
│   ├── admin-dashboard.html         # Super Admin portal (Moderation, stats, user control)
│   ├── css/
│   │   ├── styles.css               # Navy & white palette, typography, buttons, modals
│   │   ├── components.css           # Navbar, hero, job cards, company cards, footer
│   │   └── dashboard.css            # Sidebar, topbar, metrics, tables, status steppers
│   └── js/
│       ├── api.js                   # Dual-mode API client (Spring Boot REST + Local DB fallback)
│       ├── auth.js                  # Authentication, session manager, role guards
│       ├── db-mock.js               # Client-side relational database & initial seeds
│       ├── main.js                  # Homepage controller & job details modal
│       ├── jobs.js                  # Advanced filter engine, salary slider, sorting
│       ├── candidate.js             # Candidate dashboard logic, profile, resume upload
│       ├── recruiter.js             # Recruiter dashboard logic, job posting, status updater
│       ├── admin.js                 # Admin dashboard logic, user suspension, moderation
│       └── notifications.js         # Interactive toast notification alerts
│
├── backend/                         # Java Spring Boot 3.2.x REST Application
│   ├── pom.xml                      # Maven dependencies (Web, Data JPA, Security, MySQL, JWT)
│   └── src/main/
│       ├── java/com/careerconnect/recruitment/
│       │   ├── CareerConnectApplication.java
│       │   ├── config/              # SecurityConfig, JwtAuthFilter, WebConfig (CORS)
│       │   ├── controller/          # Auth, Job, Application, Candidate, Recruiter, Admin
│       │   ├── dto/                 # Request & Response Data Transfer Objects
│       │   ├── model/               # JPA Entities: User, Candidate, Recruiter, Company, Job, etc.
│       │   ├── repository/          # Spring Data JPA Repositories
│       │   ├── service/             # Business Logic & Validation Services
│       │   └── util/                # JwtUtil (Token generation, claims parsing)
│       └── resources/
│           └── application.properties # Server port, MySQL connection, JPA properties
│
├── database/                        # Database Assets
│   ├── schema.sql                   # MySQL DDL for all 10 tables with FKs and indexes
│   └── data.sql                     # Production-grade sample data across all roles
│
├── docs/                            # Technical Documentation
│   ├── API_DOCUMENTATION.md         # Full REST API endpoint reference
│   ├── DATABASE_DESIGN.md           # ER diagram and table schemas
│   └── SYSTEM_ARCHITECTURE.md       # Architecture diagrams and security models
│
└── README.md                        # Master Project Documentation
```

---

## 📊 Modules & Functional Capabilities

### 1. Candidate Module
- **Registration & Role Guard**: Candidates register with career headline and skills.
- **Profile Strength Indicator**: Calculates dynamic completion percentage (30% to 100%) based on education, experience, technical skills, and resume upload.
- **PDF Resume Upload & Download**: Upload PDF resume (< 5MB limit). Recruiters can download the document directly.
- **Applied Jobs & Status Tracker**: Interactive visual stepper tracking application states: `Application Submitted` → `Under Review` → `Candidate Shortlisted` → `Interview Scheduled` → `Hired` (or `Rejected` with custom hiring feedback).
- **Duplicate Application Prevention**: Candidates cannot submit multiple applications for the same opening.
- **Job Bookmarking**: Save vacancies with a single click; accessible in the "Saved Jobs" tab.

### 2. Recruiter Module
- **Company Profile Setup**: Manage company logo, name, website, industry, description, and location.
- **Job Vacancy Posting**: Comprehensive form containing Title, Company, Description, Required Skills, Qualification, Experience, Salary Range, Location, Job Type, Vacancies, and Application Deadline.
- **Manage Posted Jobs**: Edit active postings, update specifications, or delete listings.
- **Applicant Screening Pipeline**: Filter applicants by job vacancy, review candidate profiles, download resumes, and make decisions.
- **Decision Engine**: 1-Click Shortlist, 1-Click Reject, or open the detailed modal to set interview dates and custom candidate feedback.

### 3. Administrator Module
- **Platform Analytics**: Total Candidates, Total Recruiters, Total Companies, Total Jobs, and Total Applications.
- **User Account Moderation**: Activate or Suspend candidates and recruiters.
- **Job Moderation**: Approve pending jobs, close postings, or remove inappropriate listings.
- **Company Verification**: Monitor and verify corporate employer records.

---

## 🗄️ Database Schema Summary (10 Tables)

1. `users` – Base authentication, BCrypt password hashes, and roles (`CANDIDATE`, `RECRUITER`, `ADMIN`).
2. `candidates` – Professional headline, bio, address, education, work experience, skills, and profile score.
3. `recruiters` – Recruiter identity, department, designation, and company affiliation.
4. `companies` – Corporate name, logo URL, industry, website, location, employee count, and verification.
5. `jobs` – Vacancies with salary range, job type, experience level, qualification, deadline, and status.
6. `applications` – Candidate applications, cover notes, status state machine, recruiter feedback, interview timestamps. Enforces `UNIQUE KEY (candidate_id, job_id)`.
7. `resumes` – PDF documents linked to candidates.
8. `saved_jobs` – Bookmarked jobs for candidates.
9. `notifications` – System, status update, and interview alert messages.
10. `admin` – Administrative account privileges and audit log.

---

## 🎓 College B.Tech Viva Questions & Answers

**Q1: Why did you choose Spring Boot for the backend?**  
*Answer:* Spring Boot provides enterprise-grade reliability, out-of-the-box REST API support, and seamless integration with Spring Data JPA for Hibernate ORM and Spring Security for Role-Based Access Control (RBAC).

**Q2: How is password security managed in this application?**  
*Answer:* Passwords are never stored in plain text. They are hashed using BCrypt (`BCryptPasswordEncoder`), a salted one-way hashing function that defends against rainbow table and brute-force attacks.

**Q3: How do you prevent candidates from applying multiple times for the same job?**  
*Answer:* At the database level, a composite unique constraint `UNIQUE KEY uk_candidate_job (candidate_id, job_id)` is defined on the `applications` table. At the application layer, the controller and service check if a record already exists before saving, returning an error message if duplicate.

**Q4: How does the frontend communicate with the backend?**  
*Answer:* The frontend uses a unified asynchronous API client (`frontend/js/api.js`) utilizing the standard JavaScript `fetch` API. It features dual-mode intelligence: if Spring Boot is running on port 8080, it communicates via JSON REST endpoints; if the backend is offline, it gracefully falls back to an in-browser persistent relational engine.

---

## 📄 License
This project was developed for educational and academic demonstration purposes as a full-stack **Online Recruitment System**.

