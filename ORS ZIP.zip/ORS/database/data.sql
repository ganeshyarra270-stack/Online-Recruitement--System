-- ===================================================================
-- CareerConnect - Online Recruitment System
-- Initial Sample Seed Data (MySQL 8.0+)
-- Database: online_recruitment
-- ===================================================================

USE `online_recruitment`;

SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE `notifications`;
TRUNCATE TABLE `saved_jobs`;
TRUNCATE TABLE `applications`;
TRUNCATE TABLE `jobs`;
TRUNCATE TABLE `resumes`;
TRUNCATE TABLE `admin`;
TRUNCATE TABLE `recruiters`;
TRUNCATE TABLE `candidates`;
TRUNCATE TABLE `companies`;
TRUNCATE TABLE `users`;
SET FOREIGN_KEY_CHECKS = 1;

-- -------------------------------------------------------------------
-- 1. Insert Users (BCrypt hashes for 'pass123' and 'admin123')
-- Default test password for all test users: 'pass123' 
-- Admin password: 'admin123'
-- Hash $2a$10$7Zf9qE5iM4s3h/rYp... or standard test representation
-- -------------------------------------------------------------------
INSERT INTO `users` (`id`, `email`, `password_hash`, `role`, `full_name`, `phone`, `avatar_url`, `status`) VALUES
(1, 'admin@careerconnect.com', '$2a$10$wE9J9mQG25mS2a3ZcR6.bOpX5lYcE4vA7Bv2pTq8C5lS9b5N3BvO2', 'ADMIN', 'Master Admin', '+1 (555) 019-2834', 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150', 'ACTIVE'),
(2, 'recruiter@techcorp.com', '$2a$10$wE9J9mQG25mS2a3ZcR6.bOpX5lYcE4vA7Bv2pTq8C5lS9b5N3BvO2', 'RECRUITER', 'Marcus Vance', '+1 (555) 432-8765', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', 'ACTIVE'),
(3, 'sarah@innovatech.io', '$2a$10$wE9J9mQG25mS2a3ZcR6.bOpX5lYcE4vA7Bv2pTq8C5lS9b5N3BvO2', 'RECRUITER', 'Sarah Jenkins', '+1 (555) 876-5432', 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150', 'ACTIVE'),
(4, 'rajesh@cloudscale.net', '$2a$10$wE9J9mQG25mS2a3ZcR6.bOpX5lYcE4vA7Bv2pTq8C5lS9b5N3BvO2', 'RECRUITER', 'Rajesh Kothari', '+91 98765 43210', 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150', 'ACTIVE'),
(5, 'candidate@careerconnect.com', '$2a$10$wE9J9mQG25mS2a3ZcR6.bOpX5lYcE4vA7Bv2pTq8C5lS9b5N3BvO2', 'CANDIDATE', 'Alex Morgan', '+1 (555) 234-5678', 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', 'ACTIVE'),
(6, 'priya.sharma@example.com', '$2a$10$wE9J9mQG25mS2a3ZcR6.bOpX5lYcE4vA7Bv2pTq8C5lS9b5N3BvO2', 'CANDIDATE', 'Priya Sharma', '+91 98112 34567', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', 'ACTIVE'),
(7, 'david.miller@example.com', '$2a$10$wE9J9mQG25mS2a3ZcR6.bOpX5lYcE4vA7Bv2pTq8C5lS9b5N3BvO2', 'CANDIDATE', 'David Miller', '+1 (555) 987-6543', 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150', 'ACTIVE'),
(8, 'emily.watson@example.com', '$2a$10$wE9J9mQG25mS2a3ZcR6.bOpX5lYcE4vA7Bv2pTq8C5lS9b5N3BvO2', 'CANDIDATE', 'Emily Watson', '+44 20 7946 0958', 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150', 'ACTIVE');

-- -------------------------------------------------------------------
-- 2. Insert Companies
-- -------------------------------------------------------------------
INSERT INTO `companies` (`id`, `name`, `logo_url`, `website`, `industry`, `description`, `location`, `founded_year`, `employee_count`, `verified`) VALUES
(1, 'TechCorp Global', 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120', 'https://techcorp-example.com', 'Information Technology', 'TechCorp is a leading enterprise software provider delivering cloud-native platforms, AI solutions, and infrastructure tools to Fortune 500 enterprises.', 'Bangalore, India & San Francisco, USA', 2012, '1000-5000', TRUE),
(2, 'InnovaTech Labs', 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=120', 'https://innovatech-example.io', 'Artificial Intelligence', 'Pioneering frontier deep learning architectures, intelligent analytics, and generative automation engines for modern industries.', 'Hyderabad, India & New York, USA', 2018, '200-500', TRUE),
(3, 'CloudScale Solutions', 'https://images.unsplash.com/photo-1572021335469-31706a17aaef?w=120', 'https://cloudscale-example.net', 'Fintech & Cloud Systems', 'Building high-throughput, fault-tolerant financial settlement and low-latency cloud infrastructure across 14 global regions.', 'Pune, India & London, UK', 2015, '500-1000', TRUE),
(4, 'NexGen Media Studio', 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=120', 'https://nexgenmedia-example.com', 'Digital Design & Media', 'Award-winning interactive design studio crafting seamless customer experiences, 3D brand assets, and mobile design systems.', 'Mumbai, India', 2020, '50-150', TRUE),
(5, 'CyberShield Defense', 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=120', 'https://cybershield-example.org', 'Cybersecurity', 'Next-generation threat detection, zero-trust network architectures, and automated cloud incident response systems.', 'Austin, Texas & Singapore', 2016, '500-1000', TRUE);

-- -------------------------------------------------------------------
-- 3. Insert Candidates
-- -------------------------------------------------------------------
INSERT INTO `candidates` (`id`, `user_id`, `headline`, `bio`, `address`, `education_json`, `experience_json`, `skills_json`, `profile_completion`) VALUES
(1, 5, 'Senior Full Stack Java & Cloud Engineer', 
'Passionate software engineer with 4+ years of hands-on experience building scalable microservices with Java Spring Boot, React, AWS, and MySQL. Certified AWS Solutions Architect with a proven track record of optimizing high-throughput APIs.',
'Seattle, WA / Remote',
'[{"degree":"B.Tech in Computer Science & Engineering","institution":"National Institute of Technology","year":"2021","score":"8.9 CGPA"},{"degree":"Higher Secondary Certificate (Science)","institution":"St. Xavier High School","year":"2017","score":"92.4%"}]',
'[{"title":"Full Stack Developer","company":"CloudVertex Technologies","duration":"2022 - Present","description":"Architected microservices using Spring Boot & Redis, cutting latency by 35%. Built responsive React dashboards for analytics."},{"title":"Junior Java Developer","company":"AlphaTech Systems","duration":"2021 - 2022","description":"Developed RESTful web services, implemented Hibernate ORM queries, and managed unit test coverage with JUnit and Mockito."}]',
'["Java", "Spring Boot", "MySQL", "Hibernate", "React", "JavaScript", "Docker", "AWS", "REST APIs", "Git"]',
90),
(2, 6, 'Frontend Specialist & UI/UX Developer',
'Frontend engineer dedicated to building pixel-perfect, accessible, and high-performance web applications using modern JavaScript, React, Tailwind CSS, and TypeScript.',
'Bengaluru, Karnataka, India',
'[{"degree":"B.E. in Information Technology","institution":"Visvesvaraya Technological University","year":"2022","score":"8.6 CGPA"}]',
'[{"title":"Frontend Software Engineer","company":"PixelForge Digital","duration":"2022 - Present","description":"Led frontend migration to React 18, improved Lighthouse accessibility score to 98."}]',
'["React", "JavaScript", "TypeScript", "Tailwind CSS", "HTML5/CSS3", "Next.js", "Redux", "Figma"]',
85),
(3, 7, 'Machine Learning & Data Infrastructure Engineer',
'AI researcher and ML engineer specializing in NLP models, LLM fine-tuning, automated training pipelines, and Python backend systems with FastAPI and PyTorch.',
'Chicago, IL, USA',
'[{"degree":"M.S. in Data Science","institution":"University of Illinois Urbana-Champaign","year":"2023","score":"3.9 GPA"}]',
'[{"title":"ML Engineer Intern","company":"DeepMind Collaborators","duration":"2023 - 2024","description":"Trained BERT and transformer classifiers for automated document parsing."}]',
'["Python", "PyTorch", "TensorFlow", "FastAPI", "PostgreSQL", "Docker", "Scikit-Learn", "NLP"]',
80),
(4, 8, 'DevOps & Site Reliability Engineer',
'Infrastructure engineer focused on Kubernetes orchestration, Terraform IaC, multi-cloud CI/CD pipelines, and high availability systems.',
'London, UK',
'[{"degree":"B.Sc. in Computing","institution":"King\'s College London","year":"2020","score":"First Class"}]',
'[{"title":"SRE Engineer","company":"Vanguard Cloud","duration":"2021 - Present","description":"Automated deployment pipelines using GitHub Actions and Helm; achieved 99.99% uptime."}]',
'["Kubernetes", "Docker", "Terraform", "AWS", "Linux", "CI/CD", "Prometheus", "Grafana"]',
85);

-- -------------------------------------------------------------------
-- 4. Insert Recruiters
-- -------------------------------------------------------------------
INSERT INTO `recruiters` (`id`, `user_id`, `company_id`, `designation`, `department`, `contact_number`, `verified`) VALUES
(1, 2, 1, 'Senior Technical Recruiter', 'Talent Acquisition', '+1 (555) 432-8765', TRUE),
(2, 3, 2, 'Head of People & Culture', 'Human Resources', '+1 (555) 876-5432', TRUE),
(3, 4, 3, 'Lead Technical Talent Partner', 'Engineering Hiring', '+91 98765 43210', TRUE);

-- -------------------------------------------------------------------
-- 5. Insert Admin
-- -------------------------------------------------------------------
INSERT INTO `admin` (`id`, `user_id`, `permission_level`, `last_login`) VALUES
(1, 1, 'SUPER_ADMIN', CURRENT_TIMESTAMP);

-- -------------------------------------------------------------------
-- 6. Insert Resumes
-- -------------------------------------------------------------------
INSERT INTO `resumes` (`id`, `candidate_id`, `file_name`, `file_size_kb`, `file_type`, `file_url`, `is_default`) VALUES
(1, 1, 'Alex_Morgan_FullStack_Resume.pdf', 380, 'application/pdf', 'uploads/resumes/Alex_Morgan_Resume.pdf', TRUE),
(2, 2, 'Priya_Sharma_Frontend_Resume.pdf', 412, 'application/pdf', 'uploads/resumes/Priya_Sharma_Resume.pdf', TRUE),
(3, 3, 'David_Miller_MLEngineer_Resume.pdf', 290, 'application/pdf', 'uploads/resumes/David_Miller_Resume.pdf', TRUE);

-- -------------------------------------------------------------------
-- 7. Insert Jobs
-- -------------------------------------------------------------------
INSERT INTO `jobs` (`id`, `recruiter_id`, `company_id`, `title`, `description`, `skills_required`, `qualification`, `experience_level`, `salary_min`, `salary_max`, `location`, `job_type`, `vacancies`, `deadline`, `status`, `is_featured`, `views_count`) VALUES
(1, 1, 1, 'Senior Full Stack Java Engineer', 
'TechCorp Global is searching for an experienced Senior Full Stack Java Engineer to architect and scale our cloud enterprise applications.\n\nKey Responsibilities:\n• Design robust, secure RESTful APIs using Java 17+, Spring Boot, Spring Security, and Hibernate.\n• Develop reactive, high-performance user interfaces with React, TypeScript, and modern state management.\n• Optimize MySQL database schemas, complex queries, indexing strategies, and connection pooling.\n• Collaborate with DevOps teams to deploy microservices on AWS (ECS, RDS, S3).\n• Mentor junior developers and participate in code reviews.',
'Java, Spring Boot, React, MySQL, Hibernate, AWS, REST API, Docker',
'Bachelor or Master degree in Computer Science, Software Engineering or equivalent',
'Senior (3-5 yrs)', 120000.00, 160000.00, 'Bangalore, India (Hybrid)', 'Hybrid', 3, '2026-12-31', 'ACTIVE', TRUE, 428),

(2, 1, 1, 'Cloud DevOps Architect',
'We are seeking a seasoned Cloud DevOps Architect to champion our container orchestration, CI/CD automation, and infrastructure resilience.\n\nKey Responsibilities:\n• Manage multi-region Kubernetes clusters on AWS EKS.\n• Write maintainable Infrastructure as Code (IaC) utilizing Terraform and CloudFormation.\n• Construct automated continuous delivery pipelines with GitHub Actions.\n• Implement observability using Prometheus, Grafana, and ELK stack.',
'AWS, Kubernetes, Docker, Terraform, CI/CD, Linux, Python, Monitoring',
'B.Tech / B.E. in Computer Science, IT, or equivalent professional experience',
'Lead / Principal (5+ yrs)', 140000.00, 190000.00, 'Remote / San Francisco', 'Remote', 2, '2026-11-30', 'ACTIVE', TRUE, 310),

(3, 2, 2, 'Machine Learning Engineer (NLP & LLMs)',
'Join InnovaTech Labs at the cutting edge of generative AI and enterprise NLP systems.\n\nKey Responsibilities:\n• Fine-tune large language models and build retrieval-augmented generation (RAG) pipelines.\n• Deploy scalable ML inference microservices using FastAPI, Triton, and Docker.\n• Evaluate model latency, accuracy, hallucination rates, and drift in production environments.\n• Work closely with data annotators and backend software teams.',
'Python, PyTorch, LLMs, NLP, FastAPI, Docker, Vector Databases, HuggingFace',
'M.S. or B.Tech in Artificial Intelligence, Computer Science, or Mathematics',
'Mid-Level (1-3 yrs)', 95000.00, 135000.00, 'Hyderabad, India', 'Full-time', 4, '2026-12-15', 'ACTIVE', TRUE, 512),

(4, 2, 2, 'Senior Frontend Engineer (React & TypeScript)',
'InnovaTech Labs is looking for a talented Senior Frontend Engineer to build world-class user interfaces for our AI copilots.\n\nKey Responsibilities:\n• Develop responsive, modular web applications in React 18, TypeScript, and Next.js.\n• Implement real-time WebSocket interfaces for streaming AI output.\n• Ensure cross-browser compatibility, WCAG 2.1 AA accessibility, and lightning-fast load times.\n• Maintain comprehensive testing suites using Vitest, Jest, and Playwright.',
'React, TypeScript, Next.js, Tailwind CSS, WebSockets, HTML5, State Management',
'Bachelor Degree in Computer Science, Engineering or related technical field',
'Senior (3-5 yrs)', 105000.00, 145000.00, 'Hyderabad, India (Hybrid)', 'Hybrid', 2, '2026-12-20', 'ACTIVE', FALSE, 240),

(5, 3, 3, 'Backend Java Developer (Fintech Platform)',
'CloudScale Solutions is seeking an enthusiastic Backend Java Developer to join our core transactions settlement team.\n\nKey Responsibilities:\n• Build distributed, ACID-compliant ledger services handling thousands of transactions per second.\n• Implement event-driven architectures with Apache Kafka, Spring Boot, and Redis.\n• Ensure rigorous security standards conforming to PCI-DSS regulations.\n• Write clean, test-driven Java code with thorough unit and integration test suites.',
'Java, Spring Boot, Kafka, MySQL, Redis, Microservices, JUnit, Git',
'Bachelor Degree in CS / IT / Engineering',
'Mid-Level (1-3 yrs)', 85000.00, 115000.00, 'Pune, India', 'Full-time', 5, '2026-12-28', 'ACTIVE', TRUE, 380),

(6, 3, 3, 'Junior Cloud & Database Administrator',
'Great opportunity for a passionate engineer to launch their career in enterprise database operations and cloud reliability engineering.\n\nKey Responsibilities:\n• Monitor MySQL and PostgreSQL database performance, replication lags, and backups.\n• Assist with schema migrations, queries optimization, and index health checks.\n• Configure AWS CloudWatch alerts and assist with incident triaging.',
'MySQL, Linux, AWS, SQL, Bash Scripting, Backup & Recovery',
'Bachelor Degree in Computer Science, MCA, or BCA',
'Fresher / Entry', 50000.00, 75000.00, 'Pune, India', 'Full-time', 2, '2026-11-25', 'ACTIVE', FALSE, 195),

(7, 1, 1, 'UI/UX Product Designer',
'TechCorp Global is looking for a visionary Product Designer to shape the next era of enterprise developer tooling.\n\nKey Responsibilities:\n• Conduct user interviews, build journey maps, and wireframe innovative interaction models.\n• Design high-fidelity responsive component libraries in Figma.\n• Collaborate seamlessly with frontend engineering teams for rapid implementation.',
'Figma, UI/UX Design, Prototyping, Wireframing, User Research, Design Systems',
'Degree in Design, Human-Computer Interaction, or equivalent portfolio',
'Mid-Level (1-3 yrs)', 80000.00, 110000.00, 'Remote / Global', 'Remote', 1, '2026-12-10', 'ACTIVE', FALSE, 280),

(8, 2, 2, 'Cybersecurity Operations Analyst',
'Defend critical cloud infrastructure against evolving cyber threats and ensure compliance.\n\nKey Responsibilities:\n• Analyze SIEM telemetry, investigate alerts, and execute incident containment procedures.\n• Conduct periodic vulnerability assessments and penetration testing reviews.\n• Audit cloud IAM roles and least-privilege policies.',
'Cybersecurity, SIEM, Network Security, Linux, Incident Response, Compliance',
'B.Tech in Cyber Security or Computer Science, CEH or CompTIA Security+ preferred',
'Mid-Level (1-3 yrs)', 90000.00, 125000.00, 'Hyderabad, India', 'Full-time', 2, '2026-12-05', 'ACTIVE', FALSE, 175);

-- -------------------------------------------------------------------
-- 8. Insert Applications
-- -------------------------------------------------------------------
INSERT INTO `applications` (`id`, `job_id`, `candidate_id`, `resume_id`, `cover_note`, `status`, `recruiter_feedback`, `interview_date`, `applied_at`) VALUES
(1, 1, 1, 1, 
'Dear Hiring Manager, I have over 4 years of hands-on experience building distributed enterprise applications with Spring Boot, MySQL, and React. Having scaled APIs to handle millions of requests, I am confident I would be a great fit for TechCorp Global.',
'Shortlisted', 'Strong technical background with Spring Boot and AWS. Scheduled for Round 1 technical interview.', '2026-11-12 14:00:00', '2026-11-01 10:30:00'),

(2, 2, 1, 1, 
'Hello Team, I am deeply passionate about Kubernetes orchestration and automated IaC. I look forward to contributing to your cloud resilience.',
'Pending', NULL, NULL, '2026-11-03 15:45:00'),

(3, 7, 1, 1, 
'I have designed multiple B2B dashboards and have a strong foundation in modern design systems and user journey optimization.',
'Reviewed', 'Resume and portfolio under internal review with Lead Designer.', NULL, '2026-11-02 09:15:00'),

(4, 4, 2, 2, 
'Hi InnovaTech Team, I specialize in React 18, TypeScript, and micro-frontend development. I would love to build performant UI for your AI tools.',
'Interview Scheduled', 'Selected for Live Technical Screen & System Design.', '2026-11-14 11:30:00', '2026-11-02 11:20:00'),

(5, 3, 3, 3, 
'Dear Recruiter, My recent master thesis focused on fine-tuning LLMs with PEFT/LoRA. I am excited to apply my research skills to production RAG systems.',
'Shortlisted', 'Impressive academic background and PyTorch skills.', '2026-11-15 16:00:00', '2026-11-03 14:00:00'),

(6, 5, 2, 2, 
'Applying for backend position to expand my full stack domain knowledge.',
'Rejected', 'Role requires senior-level backend transaction concurrency experience.', NULL, '2026-11-01 18:00:00');

-- -------------------------------------------------------------------
-- 9. Insert Saved Jobs
-- -------------------------------------------------------------------
INSERT INTO `saved_jobs` (`id`, `candidate_id`, `job_id`, `saved_at`) VALUES
(1, 1, 3, '2026-11-02 12:00:00'),
(2, 1, 5, '2026-11-03 08:30:00'),
(3, 1, 8, '2026-11-04 19:20:00'),
(4, 2, 1, '2026-11-02 14:00:00');

-- -------------------------------------------------------------------
-- 10. Insert Notifications
-- -------------------------------------------------------------------
INSERT INTO `notifications` (`id`, `user_id`, `title`, `message`, `type`, `is_read`, `link_url`, `created_at`) VALUES
(1, 5, 'Application Shortlisted!', 'Congratulations! TechCorp Global has shortlisted your application for Senior Full Stack Java Engineer.', 'APPLICATION_STATUS', FALSE, 'candidate-dashboard.html#applications', '2026-11-04 11:00:00'),
(2, 5, 'Technical Interview Scheduled', 'Your interview for Senior Full Stack Java Engineer is scheduled for Nov 12, 2026 at 02:00 PM.', 'INTERVIEW', FALSE, 'candidate-dashboard.html#applications', '2026-11-04 11:15:00'),
(3, 5, 'Application Status Update', 'Your application for UI/UX Product Designer has been marked as Under Review.', 'APPLICATION_STATUS', TRUE, 'candidate-dashboard.html#applications', '2026-11-03 16:00:00'),
(4, 2, 'New Candidate Application', 'Alex Morgan has submitted an application for Senior Full Stack Java Engineer.', 'APPLICATION_STATUS', FALSE, 'recruiter-dashboard.html#applicants', '2026-11-01 10:30:00'),
(5, 1, 'Platform Milestone Reached', 'CareerConnect platform has crossed 500+ active job openings and 85,000 candidates!', 'SYSTEM', FALSE, 'admin-dashboard.html', '2026-11-01 09:00:00');

