-- ===================================================================
-- CareerConnect - Online Recruitment System
-- Database Schema Definition (MySQL 8.0+)
-- Database: online_recruitment
-- ===================================================================

CREATE DATABASE IF NOT EXISTS `online_recruitment` 
  CHARACTER SET utf8mb4 
  COLLATE utf8mb4_unicode_ci;

USE `online_recruitment`;

-- Disable foreign key checks during schema creation
SET FOREIGN_KEY_CHECKS = 0;

-- -------------------------------------------------------------------
-- 1. Table: users (Base authentication & credentials for all roles)
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('CANDIDATE', 'RECRUITER', 'ADMIN') NOT NULL DEFAULT 'CANDIDATE',
  `full_name` VARCHAR(120) NOT NULL,
  `phone` VARCHAR(25) NULL,
  `avatar_url` VARCHAR(500) NULL DEFAULT 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
  `status` ENUM('ACTIVE', 'INACTIVE', 'SUSPENDED') NOT NULL DEFAULT 'ACTIVE',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_user_email` (`email`),
  INDEX `idx_user_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- 2. Table: companies (Company profile & details)
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `companies`;
CREATE TABLE `companies` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(180) NOT NULL,
  `logo_url` VARCHAR(500) NULL,
  `website` VARCHAR(255) NULL,
  `industry` VARCHAR(100) NOT NULL,
  `description` TEXT NULL,
  `location` VARCHAR(150) NOT NULL,
  `founded_year` INT NULL,
  `employee_count` VARCHAR(50) DEFAULT '50-200',
  `verified` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_company_name` (`name`),
  INDEX `idx_company_industry` (`industry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- 3. Table: candidates (Candidate profile details)
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `candidates`;
CREATE TABLE `candidates` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT NOT NULL UNIQUE,
  `headline` VARCHAR(255) NULL DEFAULT 'Passionate Software Engineer',
  `bio` TEXT NULL,
  `address` VARCHAR(255) NULL,
  `education_json` JSON NULL COMMENT 'Array of educational qualifications',
  `experience_json` JSON NULL COMMENT 'Array of work experiences',
  `skills_json` JSON NULL COMMENT 'Array of technical skills and tags',
  `profile_completion` INT DEFAULT 75,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_candidate_user` FOREIGN KEY (`user_id`) 
    REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- 4. Table: recruiters (Recruiter identity and company affiliation)
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `recruiters`;
CREATE TABLE `recruiters` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT NOT NULL UNIQUE,
  `company_id` BIGINT NOT NULL,
  `designation` VARCHAR(120) NOT NULL DEFAULT 'Talent Acquisition Specialist',
  `department` VARCHAR(100) DEFAULT 'Human Resources',
  `contact_number` VARCHAR(30) NULL,
  `verified` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_recruiter_user` FOREIGN KEY (`user_id`) 
    REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_recruiter_company` FOREIGN KEY (`company_id`) 
    REFERENCES `companies` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- 5. Table: admin (Administrative account privileges)
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT NOT NULL UNIQUE,
  `permission_level` VARCHAR(50) DEFAULT 'SUPER_ADMIN',
  `last_login` TIMESTAMP NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_admin_user` FOREIGN KEY (`user_id`) 
    REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- 6. Table: resumes (PDF resumes uploaded by candidates)
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `resumes`;
CREATE TABLE `resumes` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `candidate_id` BIGINT NOT NULL,
  `file_name` VARCHAR(255) NOT NULL,
  `file_size_kb` INT NOT NULL,
  `file_type` VARCHAR(50) DEFAULT 'application/pdf',
  `file_url` VARCHAR(500) NOT NULL,
  `is_default` BOOLEAN DEFAULT TRUE,
  `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_resume_candidate` FOREIGN KEY (`candidate_id`) 
    REFERENCES `candidates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- 7. Table: jobs (Job vacancies posted by recruiters)
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `recruiter_id` BIGINT NOT NULL,
  `company_id` BIGINT NOT NULL,
  `title` VARCHAR(200) NOT NULL,
  `description` LONGTEXT NOT NULL,
  `skills_required` VARCHAR(500) NOT NULL COMMENT 'Comma-separated skill keywords',
  `qualification` VARCHAR(150) NOT NULL DEFAULT 'Bachelor Degree in Computer Science or related field',
  `experience_level` ENUM('Fresher / Entry', 'Mid-Level (1-3 yrs)', 'Senior (3-5 yrs)', 'Lead / Principal (5+ yrs)') NOT NULL,
  `salary_min` DECIMAL(12, 2) NOT NULL,
  `salary_max` DECIMAL(12, 2) NOT NULL,
  `location` VARCHAR(150) NOT NULL,
  `job_type` ENUM('Full-time', 'Part-time', 'Remote', 'Hybrid', 'Contract', 'Internship') NOT NULL DEFAULT 'Full-time',
  `vacancies` INT NOT NULL DEFAULT 1,
  `deadline` DATE NOT NULL,
  `status` ENUM('ACTIVE', 'PENDING_APPROVAL', 'REJECTED', 'CLOSED') NOT NULL DEFAULT 'ACTIVE',
  `is_featured` BOOLEAN DEFAULT FALSE,
  `views_count` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_job_title` (`title`),
  INDEX `idx_job_location` (`location`),
  INDEX `idx_job_status` (`status`),
  CONSTRAINT `fk_job_recruiter` FOREIGN KEY (`recruiter_id`) 
    REFERENCES `recruiters` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_job_company` FOREIGN KEY (`company_id`) 
    REFERENCES `companies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- 8. Table: applications (Job applications submitted by candidates)
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `applications`;
CREATE TABLE `applications` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `job_id` BIGINT NOT NULL,
  `candidate_id` BIGINT NOT NULL,
  `resume_id` BIGINT NULL,
  `cover_note` TEXT NULL,
  `status` ENUM('Pending', 'Reviewed', 'Shortlisted', 'Interview Scheduled', 'Rejected', 'Hired') NOT NULL DEFAULT 'Pending',
  `recruiter_feedback` TEXT NULL,
  `interview_date` DATETIME NULL,
  `applied_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_candidate_job` (`candidate_id`, `job_id`),
  CONSTRAINT `fk_app_job` FOREIGN KEY (`job_id`) 
    REFERENCES `jobs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_app_candidate` FOREIGN KEY (`candidate_id`) 
    REFERENCES `candidates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_app_resume` FOREIGN KEY (`resume_id`) 
    REFERENCES `resumes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- 9. Table: saved_jobs (Candidate bookmarked vacancies)
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `saved_jobs`;
CREATE TABLE `saved_jobs` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `candidate_id` BIGINT NOT NULL,
  `job_id` BIGINT NOT NULL,
  `saved_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_saved_candidate_job` (`candidate_id`, `job_id`),
  CONSTRAINT `fk_saved_candidate` FOREIGN KEY (`candidate_id`) 
    REFERENCES `candidates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_saved_job` FOREIGN KEY (`job_id`) 
    REFERENCES `jobs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------
-- 10. Table: notifications (System and status alerts for users)
-- -------------------------------------------------------------------
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `user_id` BIGINT NOT NULL,
  `title` VARCHAR(200) NOT NULL,
  `message` TEXT NOT NULL,
  `type` ENUM('APPLICATION_STATUS', 'JOB_ALERT', 'SYSTEM', 'INTERVIEW') NOT NULL DEFAULT 'SYSTEM',
  `is_read` BOOLEAN DEFAULT FALSE,
  `link_url` VARCHAR(255) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_notif_user` (`user_id`, `is_read`),
  CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) 
    REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

